# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ag-d1-telemetry"
cd "$HOME/robot-academy/ag-d1-telemetry"
cat > telemetry.cpp <<'ACADEMY_FILE_0'
#include "d1_transport.hpp"
#include <chrono>
#include <cmath>
#include <csignal>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <thread>
using Clock=std::chrono::steady_clock;
static volatile std::sig_atomic_t running=1;
void stop(int){running=0;}
void check_vector(const std::vector<float>& v,std::size_t n){
    if(v.size()!=n)throw std::runtime_error("Unexpected vector length");
    for(float x:v)if(!std::isfinite(x))throw std::runtime_error("Nonfinite telemetry");
}
int main(int argc,char** argv){
    try{
        std::string local,robot,output="d1-telemetry.csv";double seconds=5;int port=43988;bool ack=false;
        for(int i=1;i<argc;++i){std::string k=argv[i];
            if(k=="--ack-sdk-ownership"){ack=true;continue;}
            if(i+1>=argc)throw std::runtime_error("Missing value for "+k);
            std::string v=argv[++i];
            if(k=="--local-ip")local=v;else if(k=="--robot-ip")robot=v;
            else if(k=="--output")output=v;else if(k=="--seconds")seconds=std::stod(v);
            else if(k=="--local-port")port=std::stoi(v);else throw std::runtime_error("Unknown option "+k);
        }
        if(!(seconds>0&&seconds<=300)||port<1024||port>65535)throw std::runtime_error("Invalid duration or port");
#ifdef D1_MOCK
        local="127.0.0.1";robot="127.0.0.1";std::cerr<<"SYNTHETIC SDK MOCK; no hardware\n";(void)ack;
#else
        if(local.empty()||robot.empty()||!ack)throw std::runtime_error("Provide --local-ip, --robot-ip and --ack-sdk-ownership after reviewing the D1 ownership procedure");
#endif
        std::ofstream csv(output);if(!csv)throw std::runtime_error("Cannot open output");
        csv<<"host_elapsed_s,battery_percent,last_ctrl_mode,qw,qx,qy,qz,gx,gy,gz,ax,ay,az,body_vx,body_vy,body_vz,FR_abad,FL_abad,RR_abad,RL_abad,FR_hip,FL_hip,RR_hip,RL_hip,FR_knee,FL_knee,RR_knee,RL_knee\n";
        csv<<std::setprecision(9);std::signal(SIGINT,stop);std::signal(SIGTERM,stop);
        mc_sdk::zsl_1::HighLevel sdk;sdk.initRobot(local,port,robot);
        const auto start=Clock::now();auto tick=start;unsigned count=0;
        while(running&&std::chrono::duration<double>(Clock::now()-start).count()<seconds){
            if(!sdk.checkConnect())throw std::runtime_error("SDK connection lost");
            const auto q=sdk.getQuaternion(),g=sdk.getBodyGyro(),a=sdk.getBodyAcc(),v=sdk.getBodyVelocity();
            const auto abad=sdk.getLegAbadJoint(),hip=sdk.getLegHipJoint(),knee=sdk.getLegKneeJoint();
            check_vector(q,4);for(const auto* x:{&g,&a,&v})check_vector(*x,3);for(const auto* x:{&abad,&hip,&knee})check_vector(*x,4);
            csv<<std::chrono::duration<double>(Clock::now()-start).count()<<','<<sdk.getBatteryPower()<<','<<sdk.getCurrentCtrlmode();
            for(const auto* x:{&q,&g,&a,&v,&abad,&hip,&knee})for(float value:*x)csv<<','<<value;
            csv<<'\n';++count;tick+=std::chrono::milliseconds(20);std::this_thread::sleep_until(tick);
        }
        std::cout<<"Saved "<<count<<" rows to "<<output<<". Timestamps are host acquisition times, not guaranteed sensor times.\n";
        return count?0:2;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
ACADEMY_FILE_0
cat > d1_transport.hpp <<'ACADEMY_FILE_1'
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#ifdef D1_MOCK
#include <cstdlib>
#include <iostream>
namespace mc_sdk { namespace zsl_1 {
class HighLevel {
    unsigned checks_=0;
public:
    void initRobot(const std::string&,int,const std::string&) {}
    bool checkConnect() { ++checks_;const char* n=std::getenv("D1_MOCK_FAIL_AFTER");return !n || checks_<static_cast<unsigned>(std::stoul(n)); }
    std::vector<float> getQuaternion(){return {1,0,0,0};}
    std::vector<float> getRPY(){return {0,0,0};}
    std::vector<float> getBodyAcc(){return {0,0,9.81f};}
    std::vector<float> getBodyGyro(){return {0,0,0};}
    std::vector<float> getBodyVelocity(){return {0,0,0};}
    std::vector<float> getLegAbadJoint(){return {.01f,.02f,.03f,.04f};}
    std::vector<float> getLegHipJoint(){return {.11f,.12f,.13f,.14f};}
    std::vector<float> getLegKneeJoint(){return {.21f,.22f,.23f,.24f};}
    uint32_t getBatteryPower(){return 80;}
    uint32_t getCurrentCtrlmode(){return 1;}
    uint32_t move(float x,float y,float yaw){std::cerr<<"MOCK move "<<x<<" "<<y<<" "<<yaw<<"\n";return 0;}
};
}}
#else
#include <zsl-1/highlevel.h>
#endif
ACADEMY_FILE_1
cat > build.sh <<'ACADEMY_FILE_2'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
case "${1:-mock}" in
mock) c++ -std=c++17 -O2 -Wall -Wextra -pthread -DD1_MOCK telemetry.cpp -o d1_reader_mock ;;
hardware)
  : "${D1_SDK_DIR:?Set D1_SDK_DIR to the pinned official SDK checkout}"
  arch=$(uname -m)
  case "$arch" in x86_64|aarch64) ;; *) printf 'Unsupported Linux architecture: %s\n' "$arch" >&2;exit 2;; esac
  test "$(uname -s)" = Linux || { echo 'Hardware build requires Linux' >&2;exit 2; }
  libdir="$D1_SDK_DIR/lib/zsl-1/$arch"
  c++ -std=c++17 -O2 -Wall -Wextra -pthread telemetry.cpp -I"$D1_SDK_DIR/include" \
    "$libdir/libmc_sdk_zsl_1_${arch}.so" -Wl,-rpath,"$libdir" -o d1_reader_hardware
  ;;
*) echo 'Usage: bash build.sh mock|hardware' >&2;exit 2;;
esac
ACADEMY_FILE_2
cat > prepare_sdk.sh <<'ACADEMY_FILE_3'
#!/usr/bin/env bash
# Download the pinned headers/libraries only. Does not connect to the robot.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d agibot_D1_Edu-Ultra ]; then
  git clone https://github.com/AgibotTech/agibot_D1_Edu-Ultra.git agibot_D1_Edu-Ultra
  git -C agibot_D1_Edu-Ultra checkout --detach b5fe0a86094507238944ad118721376a98615ac0
fi
test "$(git -C agibot_D1_Edu-Ultra rev-parse HEAD)" = b5fe0a86094507238944ad118721376a98615ac0 || { echo 'Existing SDK differs from course pin.' >&2;exit 2; }
export D1_SDK_DIR="$PWD/agibot_D1_Edu-Ultra"
bash build.sh hardware
ACADEMY_FILE_3
printf '%s\n' 'Created 4 file(s) in ~/robot-academy/ag-d1-telemetry'
)
