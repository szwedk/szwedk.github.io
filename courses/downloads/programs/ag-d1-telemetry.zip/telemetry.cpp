#include "d1_transport.hpp"
#include <chrono>
#include <cmath>
#include <csignal>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <thread>
using Clock=std::chrono::steady_clock;
static volatile std::sig_atomic_t running=1;
void stop(int){running=0;}
void check_vector(const std::vector<float>& v,std::size_t n){
    if(v.size()!=n)throw std::runtime_error("Unexpected vector length");
    for(float x:v)if(!std::isfinite(x))throw std::runtime_error("Nonfinite telemetry");
}
int main(int argc,char** argv){
    try{
        std::string local,robot,output="d1-telemetry.csv";double seconds=5;int port=43988;bool ack=false;
        for(int i=1;i<argc;++i){std::string k=argv[i];
            if(k=="--ack-sdk-ownership"){ack=true;continue;}
            if(i+1>=argc)throw std::runtime_error("Missing value for "+k);
            std::string v=argv[++i];
            if(k=="--local-ip")local=v;else if(k=="--robot-ip")robot=v;
            else if(k=="--output")output=v;else if(k=="--seconds")seconds=std::stod(v);
            else if(k=="--local-port")port=std::stoi(v);else throw std::runtime_error("Unknown option "+k);
        }
        if(!(seconds>0&&seconds<=300)||port<1024||port>65535)throw std::runtime_error("Invalid duration or port");
#ifdef D1_MOCK
        local="127.0.0.1";robot="127.0.0.1";std::cerr<<"SYNTHETIC SDK MOCK; no hardware\n";(void)ack;
#else
        if(local.empty()||robot.empty()||!ack)throw std::runtime_error("Provide --local-ip, --robot-ip and --ack-sdk-ownership after reviewing the D1 ownership procedure");
#endif
        std::ofstream csv(output);if(!csv)throw std::runtime_error("Cannot open output");
        csv<<"host_elapsed_s,battery_percent,last_ctrl_mode,qw,qx,qy,qz,gx,gy,gz,ax,ay,az,body_vx,body_vy,body_vz,FR_abad,FL_abad,RR_abad,RL_abad,FR_hip,FL_hip,RR_hip,RL_hip,FR_knee,FL_knee,RR_knee,RL_knee\n";
        csv<<std::setprecision(9);std::signal(SIGINT,stop);std::signal(SIGTERM,stop);
        mc_sdk::zsl_1::HighLevel sdk;sdk.initRobot(local,port,robot);
        const auto start=Clock::now();auto tick=start;unsigned count=0;
        while(running&&std::chrono::duration<double>(Clock::now()-start).count()<seconds){
            if(!sdk.checkConnect())throw std::runtime_error("SDK connection lost");
            const auto q=sdk.getQuaternion(),g=sdk.getBodyGyro(),a=sdk.getBodyAcc(),v=sdk.getBodyVelocity();
            const auto abad=sdk.getLegAbadJoint(),hip=sdk.getLegHipJoint(),knee=sdk.getLegKneeJoint();
            check_vector(q,4);for(const auto* x:{&g,&a,&v})check_vector(*x,3);for(const auto* x:{&abad,&hip,&knee})check_vector(*x,4);
            csv<<std::chrono::duration<double>(Clock::now()-start).count()<<','<<sdk.getBatteryPower()<<','<<sdk.getCurrentCtrlmode();
            for(const auto* x:{&q,&g,&a,&v,&abad,&hip,&knee})for(float value:*x)csv<<','<<value;
            csv<<'\n';++count;tick+=std::chrono::milliseconds(20);std::this_thread::sleep_until(tick);
        }
        std::cout<<"Saved "<<count<<" rows to "<<output<<". Timestamps are host acquisition times, not guaranteed sensor times.\n";
        return count?0:2;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
