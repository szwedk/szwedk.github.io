Log D1 Ultra telemetry through the native C++ SDK

Compile a standalone reader for quaternion, IMU, body velocity, battery and twelve leg joint positions. Select a synthetic transport first, then the pinned Linux shared library.

PLATFORM: AGIBOT D1 Ultra

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

C++17 mock compiled; 5 telemetry rows, 28 columns, quaternion order validated. C++ syntax checked against pinned vendor header without D1_MOCK; Linux native shared-library link/runtime untested Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: a C++17 compiler and bash

Device: Linux x86_64 or aarch64 with the pinned D1 SDK shared library

Correct local interface IP, robot IP, free UDP port and reviewed SDK ownership procedure

CONFIGURATION

D1_LOCAL_IP = The IP assigned to your robot-facing Linux interface
Inspect your interface configuration; do not copy a guessed address.

D1_ROBOT_IP = The address configured for your D1 Ultra
Pass explicitly to initRobot.

--local-port = 43988
Local UDP port; avoid a conflicting SDK process.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-d1-telemetry. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-d1-telemetry"
cd "$HOME/robot-academy/ag-d1-telemetry"
command -v c++ >/dev/null
bash build.sh mock
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-d1-telemetry"
./d1_reader_mock --seconds 1 --output d1-mock.csv

# Optional Linux SDK download/build; it never connects by itself:
# bash prepare_sdk.sh
# After checking actual interface addresses and SDK control ownership:
# ./d1_reader_hardware --local-ip "$D1_LOCAL_IP" --robot-ip "$D1_ROBOT_IP" --local-port 43988 --seconds 10 --output d1-device.csv --ack-sdk-ownership
)

EXPECTED RESULT

Offline creates approximately 50 rows per second with 28 columns.

Device reader uses checkConnect(), matching the actual header, and emits no movement commands.

Invalid vector lengths, nonfinite values or connection loss end the run with an error.

Headers are the build contract

The pinned highlevel.h exposes checkConnect(), while some prose documentation uses checkConnection(). This program compiles against the header spelling and links the architecture-specific shared library. A compile-time D1_MOCK adapter offers the same methods with deterministic telemetry; it is not the vendor simulator. The hardware binary has no implicit IP addresses and requires an acknowledgment because creating a D1 SDK session may affect control ownership even when this program only calls getters.



Interpreting the CSV

The quaternion is w,x,y,z, unlike the common ROS message order. Leg arrays use front-right, front-left, rear-right, rear-left, grouped by abduction, hip and knee. The mode column represents the SDK reported last executed state; it is not a measured balance estimate. A steady host clock timestamps each acquisition. Getters may expose cached data, so a 50 Hz host loop does not establish a 50 Hz independent sensor update rate. The duration limit covers the sampling loop; a native SDK initialization/getter that blocks cannot be preempted by this simple C++ wrapper.



TROUBLESHOOTING

Compiler cannot find highlevel.h
Run the optional prepare_sdk.sh on Linux, or set D1_SDK_DIR to the pinned checkout and run bash build.sh hardware.

Shared library cannot load
Match x86_64/aarch64 and inspect the installed library dependencies with ldd. The build sets an rpath to this recipe’s SDK checkout.

Connection gate fails
Confirm IP assignments, routes and UDP port ownership. Do not replace checkConnect with the documentation-only checkConnection spelling.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-d1-interface-audit

https://kamilszwed.com/courses/#/lesson/ag-d1-network

https://kamilszwed.com/courses/#/lesson/ag-d1-telemetry

SOURCES

D1 EDU/Ultra SDK overview
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/README.md
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 ZSL-1 C++ high-level header
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/include/zsl-1/highlevel.h
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 ZSL-1 API documentation
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/docs/api_zsl-1.md
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 deployment guide
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/docs/deploy.md
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 SDK known failure modes
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/docs/faq.md
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z
