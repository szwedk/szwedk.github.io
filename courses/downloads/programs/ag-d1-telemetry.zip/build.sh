#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
case "${1:-mock}" in
mock) c++ -std=c++17 -O2 -Wall -Wextra -pthread -DD1_MOCK telemetry.cpp -o d1_reader_mock ;;
hardware)
  : "${D1_SDK_DIR:?Set D1_SDK_DIR to the pinned official SDK checkout}"
  arch=$(uname -m)
  case "$arch" in x86_64|aarch64) ;; *) printf 'Unsupported Linux architecture: %s\n' "$arch" >&2;exit 2;; esac
  test "$(uname -s)" = Linux || { echo 'Hardware build requires Linux' >&2;exit 2; }
  libdir="$D1_SDK_DIR/lib/zsl-1/$arch"
  c++ -std=c++17 -O2 -Wall -Wextra -pthread telemetry.cpp -I"$D1_SDK_DIR/include" \
    "$libdir/libmc_sdk_zsl_1_${arch}.so" -Wl,-rpath,"$libdir" -o d1_reader_hardware
  ;;
*) echo 'Usage: bash build.sh mock|hardware' >&2;exit 2;;
esac
