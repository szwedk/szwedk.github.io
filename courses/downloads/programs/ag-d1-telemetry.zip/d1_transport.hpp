#pragma once
#include <cstdint>
#include <string>
#include <vector>
#ifdef D1_MOCK
#include <cstdlib>
#include <iostream>
namespace mc_sdk { namespace zsl_1 {
class HighLevel {
    unsigned checks_=0;
public:
    void initRobot(const std::string&,int,const std::string&) {}
    bool checkConnect() { ++checks_;const char* n=std::getenv("D1_MOCK_FAIL_AFTER");return !n || checks_<static_cast<unsigned>(std::stoul(n)); }
    std::vector<float> getQuaternion(){return {1,0,0,0};}
    std::vector<float> getRPY(){return {0,0,0};}
    std::vector<float> getBodyAcc(){return {0,0,9.81f};}
    std::vector<float> getBodyGyro(){return {0,0,0};}
    std::vector<float> getBodyVelocity(){return {0,0,0};}
    std::vector<float> getLegAbadJoint(){return {.01f,.02f,.03f,.04f};}
    std::vector<float> getLegHipJoint(){return {.11f,.12f,.13f,.14f};}
    std::vector<float> getLegKneeJoint(){return {.21f,.22f,.23f,.24f};}
    uint32_t getBatteryPower(){return 80;}
    uint32_t getCurrentCtrlmode(){return 1;}
    uint32_t move(float x,float y,float yaw){std::cerr<<"MOCK move "<<x<<" "<<y<<" "<<yaw<<"\n";return 0;}
};
}}
#else
#include <zsl-1/highlevel.h>
#endif
