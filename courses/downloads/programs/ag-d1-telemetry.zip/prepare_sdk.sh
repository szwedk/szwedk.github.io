#!/usr/bin/env bash
# Download the pinned headers/libraries only. Does not connect to the robot.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d agibot_D1_Edu-Ultra ]; then
  git clone https://github.com/AgibotTech/agibot_D1_Edu-Ultra.git agibot_D1_Edu-Ultra
  git -C agibot_D1_Edu-Ultra checkout --detach b5fe0a86094507238944ad118721376a98615ac0
fi
test "$(git -C agibot_D1_Edu-Ultra rev-parse HEAD)" = b5fe0a86094507238944ad118721376a98615ac0 || { echo 'Existing SDK differs from course pin.' >&2;exit 2; }
export D1_SDK_DIR="$PWD/agibot_D1_Edu-Ultra"
bash build.sh hardware
