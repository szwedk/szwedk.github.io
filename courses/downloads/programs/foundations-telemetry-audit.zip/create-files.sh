# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/foundations-telemetry-audit"
cd "$HOME/robot-academy/foundations-telemetry-audit"
cat > analyze_telemetry.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Audit a CSV contract: stamp_s,value,unit,frame_id. Uses no third-party packages."""
import argparse
import csv
import json
import math
from pathlib import Path
import statistics
import sys


def audit(rows, expected_unit="C", expected_frame="lab_sensor", max_gap_s=0.2):
    if not math.isfinite(max_gap_s) or max_gap_s <= 0:
        raise ValueError("max_gap_s must be finite and positive")
    accepted, rejected, gaps = [], [], []
    previous = None
    for line, row in enumerate(rows, start=2):
        try:
            stamp, value = float(row["stamp_s"]), float(row["value"])
            if not (math.isfinite(stamp) and math.isfinite(value)):
                raise ValueError("non-finite timestamp or value")
            if stamp < 0:
                raise ValueError("negative timestamp")
            if row["unit"] != expected_unit:
                raise ValueError("unit mismatch")
            if row["frame_id"] != expected_frame:
                raise ValueError("frame mismatch")
            if previous is not None and stamp <= previous:
                raise ValueError("timestamp is duplicate or out of order")
        except (KeyError, TypeError, ValueError) as error:
            rejected.append({"csv_line": line, "reason": str(error)})
            continue
        if previous is not None and stamp - previous > max_gap_s + 1e-12:
            gaps.append({"csv_line": line, "gap_s": round(stamp - previous, 9)})
        accepted.append({"stamp_s": stamp, "value": value, "unit": row["unit"], "frame_id": row["frame_id"]})
        previous = stamp
    intervals = [b["stamp_s"]-a["stamp_s"] for a, b in zip(accepted, accepted[1:])]
    values = [row["value"] for row in accepted]
    median_period = statistics.median(intervals) if intervals else None
    report = {"accepted_rows": len(accepted), "rejected_rows": len(rejected),
              "rejections": rejected, "gaps": gaps, "max_allowed_gap_s": max_gap_s,
              "median_period_s": median_period,
              "median_rate_hz": 1.0/median_period if median_period else None,
              "value_min": min(values) if values else None,
              "value_max": max(values) if values else None,
              "unit": expected_unit, "frame_id": expected_frame,
              "scope": "CSV content and timestamp order only; no physical sensor or clock synchronization is verified."}
    return report, accepted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--unit", default="C")
    parser.add_argument("--frame", default="lab_sensor")
    parser.add_argument("--max-gap", type=float, default=0.2, help="Seconds; finite and positive")
    parser.add_argument("--output", type=Path, default=Path("reports/analysis.json"))
    parser.add_argument("--clean-output", type=Path, default=Path("reports/accepted.csv"))
    parser.add_argument("--strict", action="store_true", help="Exit 2 when rows are rejected, gaps exist, or no rows are accepted.")
    args = parser.parse_args()
    if not math.isfinite(args.max_gap) or args.max_gap <= 0:
        parser.error("--max-gap must be finite and positive")
    with args.input.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        required = {"stamp_s", "value", "unit", "frame_id"}
        if not required.issubset(reader.fieldnames or []):
            parser.error("CSV requires header: stamp_s,value,unit,frame_id")
        report, accepted = audit(reader, args.unit, args.frame, args.max_gap)
    for path in (args.output, args.clean_output):
        path.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with args.clean_output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["stamp_s", "value", "unit", "frame_id"])
        writer.writeheader()
        writer.writerows(accepted)
    print(json.dumps(report, indent=2))
    failed_quality = report["rejected_rows"] or report["gaps"] or not accepted
    return 2 if args.strict and failed_quality else 0


if __name__ == "__main__":
    sys.exit(main())
ACADEMY_FILE_0
cat > test_analyze.py <<'ACADEMY_FILE_1'
import unittest
from analyze_telemetry import audit


def row(t, value=20, unit="C", frame="lab_sensor"):
    return {"stamp_s": str(t), "value": str(value), "unit": unit, "frame_id": frame}


class AuditTests(unittest.TestCase):
    def test_rate(self):
        report, _ = audit([row(0), row(.1), row(.2)])
        self.assertAlmostEqual(report["median_rate_hz"], 10)
    def test_duplicate(self):
        report, _ = audit([row(0), row(0)])
        self.assertEqual(report["rejected_rows"], 1)
    def test_invalid_value(self):
        report, _ = audit([row(0, float("nan"))])
        self.assertEqual(report["accepted_rows"], 0)
    def test_unit_and_frame(self):
        report, _ = audit([row(0, unit="K"), row(.1, frame="other")])
        self.assertEqual(report["rejected_rows"], 2)
    def test_gap(self):
        report, _ = audit([row(0), row(.5)])
        self.assertEqual(report["gaps"][0]["gap_s"], .5)
    def test_exact_boundary(self):
        report, _ = audit([row(0), row(.2), row(.4)])
        self.assertEqual(report["gaps"], [])


if __name__ == "__main__":
    unittest.main()
ACADEMY_FILE_1
cat > sample.csv <<'ACADEMY_FILE_2'
stamp_s,value,unit,frame_id
0.0,20.0,C,lab_sensor
0.1,20.2,C,lab_sensor
0.2,20.1,C,lab_sensor
0.2,20.3,C,lab_sensor
0.3,nan,C,lab_sensor
0.6,20.4,C,lab_sensor
0.7,293.6,K,lab_sensor
0.8,20.5,C,other_sensor
0.9,20.6,C,lab_sensor
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/foundations-telemetry-audit'
)
