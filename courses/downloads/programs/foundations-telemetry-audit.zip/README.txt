Audit a telemetry CSV and keep rejected rows explainable

Parse a real CSV contract, reject bad values and mismatched units/frames, identify timestamp gaps, and export both an analysis report and accepted rows. Includes a deliberately flawed fixture and six tests.

PLATFORM: Linux & Python

ENVIRONMENT: Offline

VALIDATION

Locally tested

All six unit tests passed. The complete fixture produced 5 accepted/4 rejected rows and two expected gaps; JSON and accepted CSV were inspected. Strict-mode failure is verified in QA.

REQUIREMENTS

Python 3.10+; standard library only

Python 3.10+; no pip packages

CONFIGURATION

input = sample.csv
Input file with the documented four-column header.

--unit = C
Exact expected unit label; no automatic conversion occurs.

--frame = lab_sensor
Exact expected frame/location identifier.

--max-gap = 0.2
Maximum accepted interval in seconds before a gap is reported.

--strict = --strict
Exit 2 when the quality gate fails.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/foundations-telemetry-audit. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/foundations-telemetry-audit"
  python3 -m py_compile analyze_telemetry.py test_analyze.py
  python3 -m unittest -v test_analyze.py
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/foundations-telemetry-audit"
  python3 analyze_telemetry.py sample.csv --unit C --frame lab_sensor --max-gap 0.2
  python3 -m json.tool reports/analysis.json
)

EXPECTED RESULT

The supplied fixture yields 5 accepted rows and 4 rejected rows.

Duplicate timestamp, NaN value, wrong unit, and wrong frame each have a line-numbered reason.

Two accepted-sample gaps are reported: 0.4 s and 0.3 s.

Median accepted-sample period is 0.2 s; its reciprocal is 5 Hz.

Strict mode exits 2 on this intentionally flawed fixture.

The input contract

Each row represents a value at stamp_s, in the stated unit and frame/location identifier. The program checks finite numbers, nonnegative and strictly increasing timestamps, and exact unit/frame agreement. It preserves the original input file and writes a separate accepted-data file, so rejected observations remain available for investigation.



Why a gap may follow rejection

Intervals are calculated between accepted samples. If an intervening row is unusable, the next accepted sample is farther from the previous accepted sample. The reported gap describes the usable stream, not necessarily a dropped network packet. Temperature messages and this CSV fixture do not provide enough evidence to infer every transport loss.



Use status for automation

A normal run returns zero when the analysis operation completes, even if the report contains data-quality problems. Add --strict when a build or data pipeline should fail on rejected rows, excessive gaps, or an empty accepted stream. This separates successful execution of the auditor from acceptance of the dataset.



TROUBLESHOOTING

Required header error
Use stamp_s,value,unit,frame_id as the first CSV row. A timestamp unit must be seconds, and values must use the declared unit.

Apparent rate differs from source rate
The reported rate is based on accepted samples, including their gaps. It is not a claim about the publisher’s configured rate.

Wrong-unit rows are rejected
Convert units explicitly upstream or supply the correct expected unit. Renaming a unit label without converting values is not a conversion.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/linux-shell-data

https://kamilszwed.com/courses/#/lesson/ros-python-numeric

https://kamilszwed.com/courses/#/lesson/ros-bags-evidence

SOURCES

REP 103: standard units and coordinate conventions
https://raw.githubusercontent.com/ros-infrastructure/rep/master/rep-0103.rst
Current primary documentation retrieved 2026-09-29

Python CSV reader and writer
https://docs.python.org/3/library/csv.html
Primary documentation retrieved 2026-09-29
