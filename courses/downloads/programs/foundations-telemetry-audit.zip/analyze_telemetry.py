#!/usr/bin/env python3
"""Audit a CSV contract: stamp_s,value,unit,frame_id. Uses no third-party packages."""
import argparse
import csv
import json
import math
from pathlib import Path
import statistics
import sys


def audit(rows, expected_unit="C", expected_frame="lab_sensor", max_gap_s=0.2):
    if not math.isfinite(max_gap_s) or max_gap_s <= 0:
        raise ValueError("max_gap_s must be finite and positive")
    accepted, rejected, gaps = [], [], []
    previous = None
    for line, row in enumerate(rows, start=2):
        try:
            stamp, value = float(row["stamp_s"]), float(row["value"])
            if not (math.isfinite(stamp) and math.isfinite(value)):
                raise ValueError("non-finite timestamp or value")
            if stamp < 0:
                raise ValueError("negative timestamp")
            if row["unit"] != expected_unit:
                raise ValueError("unit mismatch")
            if row["frame_id"] != expected_frame:
                raise ValueError("frame mismatch")
            if previous is not None and stamp <= previous:
                raise ValueError("timestamp is duplicate or out of order")
        except (KeyError, TypeError, ValueError) as error:
            rejected.append({"csv_line": line, "reason": str(error)})
            continue
        if previous is not None and stamp - previous > max_gap_s + 1e-12:
            gaps.append({"csv_line": line, "gap_s": round(stamp - previous, 9)})
        accepted.append({"stamp_s": stamp, "value": value, "unit": row["unit"], "frame_id": row["frame_id"]})
        previous = stamp
    intervals = [b["stamp_s"]-a["stamp_s"] for a, b in zip(accepted, accepted[1:])]
    values = [row["value"] for row in accepted]
    median_period = statistics.median(intervals) if intervals else None
    report = {"accepted_rows": len(accepted), "rejected_rows": len(rejected),
              "rejections": rejected, "gaps": gaps, "max_allowed_gap_s": max_gap_s,
              "median_period_s": median_period,
              "median_rate_hz": 1.0/median_period if median_period else None,
              "value_min": min(values) if values else None,
              "value_max": max(values) if values else None,
              "unit": expected_unit, "frame_id": expected_frame,
              "scope": "CSV content and timestamp order only; no physical sensor or clock synchronization is verified."}
    return report, accepted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--unit", default="C")
    parser.add_argument("--frame", default="lab_sensor")
    parser.add_argument("--max-gap", type=float, default=0.2, help="Seconds; finite and positive")
    parser.add_argument("--output", type=Path, default=Path("reports/analysis.json"))
    parser.add_argument("--clean-output", type=Path, default=Path("reports/accepted.csv"))
    parser.add_argument("--strict", action="store_true", help="Exit 2 when rows are rejected, gaps exist, or no rows are accepted.")
    args = parser.parse_args()
    if not math.isfinite(args.max_gap) or args.max_gap <= 0:
        parser.error("--max-gap must be finite and positive")
    with args.input.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        required = {"stamp_s", "value", "unit", "frame_id"}
        if not required.issubset(reader.fieldnames or []):
            parser.error("CSV requires header: stamp_s,value,unit,frame_id")
        report, accepted = audit(reader, args.unit, args.frame, args.max_gap)
    for path in (args.output, args.clean_output):
        path.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    with args.clean_output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["stamp_s", "value", "unit", "frame_id"])
        writer.writeheader()
        writer.writerows(accepted)
    print(json.dumps(report, indent=2))
    failed_quality = report["rejected_rows"] or report["gaps"] or not accepted
    return 2 if args.strict and failed_quality else 0


if __name__ == "__main__":
    sys.exit(main())
