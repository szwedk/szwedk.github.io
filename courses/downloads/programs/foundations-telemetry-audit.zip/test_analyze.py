import unittest
from analyze_telemetry import audit


def row(t, value=20, unit="C", frame="lab_sensor"):
    return {"stamp_s": str(t), "value": str(value), "unit": unit, "frame_id": frame}


class AuditTests(unittest.TestCase):
    def test_rate(self):
        report, _ = audit([row(0), row(.1), row(.2)])
        self.assertAlmostEqual(report["median_rate_hz"], 10)
    def test_duplicate(self):
        report, _ = audit([row(0), row(0)])
        self.assertEqual(report["rejected_rows"], 1)
    def test_invalid_value(self):
        report, _ = audit([row(0, float("nan"))])
        self.assertEqual(report["accepted_rows"], 0)
    def test_unit_and_frame(self):
        report, _ = audit([row(0, unit="K"), row(.1, frame="other")])
        self.assertEqual(report["rejected_rows"], 2)
    def test_gap(self):
        report, _ = audit([row(0), row(.5)])
        self.assertEqual(report["gaps"][0]["gap_s"], .5)
    def test_exact_boundary(self):
        report, _ = audit([row(0), row(.2), row(.4)])
        self.assertEqual(report["gaps"], [])


if __name__ == "__main__":
    unittest.main()
