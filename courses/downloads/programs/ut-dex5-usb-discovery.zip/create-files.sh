# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-dex5-usb-discovery"
cd "$HOME/robot-academy/ut-dex5-usb-discovery"
cat > dex5_usb.py <<'ACADEMY_FILE_0'
"""Read Linux USB descriptors and compare snapshots; no vendor protocol guessed."""
import argparse
import json
from pathlib import Path


def inventory(root):
    devices=[]
    for node in sorted(root.iterdir()):
        if not (node/'idVendor').exists():continue
        def read(name):
            try:return (node/name).read_text().strip()
            except (OSError,UnicodeError):return None
        devices.append(dict(path=node.name,vendor_id=read('idVendor'),product_id=read('idProduct'),
                            manufacturer=read('manufacturer'),product=read('product'),
                            bus=read('busnum'),address=read('devnum')))
    return devices


def difference(before,after):
    key=lambda x:(x['path'],x['vendor_id'],x['product_id'])
    old={key(x) for x in before};new={key(x) for x in after}
    return dict(added=[x for x in after if key(x) not in old],removed=[x for x in before if key(x) not in new])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--live',action='store_true');p.add_argument('--mock',action='store_true')
    p.add_argument('--before');p.add_argument('--output',default='usb-snapshot.json')
    p.add_argument('--self-test',action='store_true');a=p.parse_args()
    fake=[dict(path='fixture-1',vendor_id='ffff',product_id='0010',manufacturer='SYNTHETIC',product='Test device',bus='0',address='1')]
    if a.self_test:
        assert difference([],fake)['added']==fake and difference(fake,[])['removed']==fake
        assert difference(fake,fake)==dict(added=[],removed=[])
        print('PASS: added, removed and unchanged USB snapshots');return
    if a.live:
        root=Path('/sys/bus/usb/devices')
        if not root.is_dir():p.error('Live inventory requires Linux USB sysfs; use --mock elsewhere')
        devices=inventory(root)
    else:devices=fake
    result=dict(source='linux-sysfs' if a.live else 'synthetic',devices=devices,
                note='An added USB device is a candidate, not verified Dex5 identity. No control transfer or motor command was sent.')
    if a.before:result['difference']=difference(json.loads(Path(a.before).read_text())['devices'],devices)
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ut-dex5-usb-discovery'
)
