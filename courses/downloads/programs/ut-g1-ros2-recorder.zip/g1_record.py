"""Record G1 HG state to CSV + JSONL. No commands or motion-mode changes."""
import argparse
import csv
import json
import math
from pathlib import Path
from reader_common import add_reader_args, fixture, stream

G1_29_PR = ['left_hip_pitch','left_hip_roll','left_hip_yaw','left_knee',
 'left_ankle_pitch','left_ankle_roll','right_hip_pitch','right_hip_roll','right_hip_yaw',
 'right_knee','right_ankle_pitch','right_ankle_roll','waist_yaw','waist_roll','waist_pitch',
 'left_shoulder_pitch','left_shoulder_roll','left_shoulder_yaw','left_elbow','left_wrist_roll',
 'left_wrist_pitch','left_wrist_yaw','right_shoulder_pitch','right_shoulder_roll',
 'right_shoulder_yaw','right_elbow','right_wrist_roll','right_wrist_pitch','right_wrist_yaw']


def record(message, received_s, mapping='raw'):
    if mapping == 'g1-29-pr' and int(message.mode_pr) != 0:
        raise ValueError('Named PR map cannot label a sample in AB coordinate mode')
    motors = []
    for index, motor in enumerate(message.motor_state):
        name = G1_29_PR[index] if mapping == 'g1-29-pr' and index < 29 else 'slot_'+str(index)
        motors.append(dict(index=index, name=name, q=float(motor.q), dq=float(motor.dq),
                           tau_est=float(motor.tau_est), temperature=list(motor.temperature),
                           voltage=float(motor.vol), status=int(motor.motorstate)))
    return dict(received_s=received_s, tick=int(message.tick), mode_pr=int(message.mode_pr),
                mode_machine=int(message.mode_machine), quaternion=list(message.imu_state.quaternion),
                gyroscope=list(message.imu_state.gyroscope), motors=motors)


def self_test():
    row = record(fixture('g1', 0), 0.0, 'g1-29-pr')
    assert len(row['motors']) == 35 and row['motors'][25]['name'] == 'right_elbow'
    bad = fixture('g1', 0); bad.mode_pr = 1
    try: record(bad, 0.0, 'g1-29-pr')
    except ValueError: pass
    else: raise AssertionError('AB mode accepted as PR')
    print('PASS: 35 raw slots retained; 29-joint labels checked; wrong coordinate mode rejected')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    add_reader_args(p, 'rt/lowstate')
    p.add_argument('--map', choices=['raw','g1-29-pr'], default='raw')
    p.add_argument('--output', default='g1-state')
    args = p.parse_args()
    if args.self_test: self_test(); return 0
    prefix = Path(args.output); prefix.parent.mkdir(parents=True, exist_ok=True)
    stats = {}; written = rejected = 0
    try:
        with prefix.with_suffix('.jsonl').open('w') as jf, prefix.with_suffix('.csv').open('w', newline='') as cf:
            writer = csv.writer(cf)
            writer.writerow(['received_s','tick','mode_pr','mode_machine','index','joint','q_rad',
                             'dq_rad_s','tau_est','temperature_0','temperature_1','voltage','status'])
            try:
                for received, message in stream('g1', args, stats):
                    try:
                        row = record(message, received, args.map)
                        encoded = json.dumps(row, allow_nan=False)
                    except (ValueError, TypeError, AttributeError) as error:
                        rejected += 1
                        print('Rejected sample:', error)
                        continue
                    jf.write(encoded+'\n')
                    for m in row['motors']:
                        writer.writerow([received,row['tick'],row['mode_pr'],row['mode_machine'],
                                         m['index'],m['name'],m['q'],m['dq'],m['tau_est'],
                                         *m['temperature'],m['voltage'],m['status']])
                    written += 1
            except KeyboardInterrupt:
                print('Interrupted; closing files and subscriber.')
    finally:
        summary = dict(stats, written=written, rejected=rejected, mapping=args.map)
        prefix.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary))
    return 0 if written else 2

if __name__ == '__main__':
    raise SystemExit(main())
