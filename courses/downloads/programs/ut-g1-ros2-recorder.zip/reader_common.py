"""Shared receive-only SDK2 utilities; importing this module never opens DDS."""
import argparse
import math
import queue
import struct
import time
from types import SimpleNamespace as NS


def add_reader_args(parser, default_topic):
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--live', action='store_true', help='Subscribe to a configured DDS endpoint')
    group.add_argument('--mock', action='store_true', help='Use synthetic data (default)')
    parser.add_argument('--interface', default='lo')
    parser.add_argument('--domain', type=int, default=1)
    parser.add_argument('--topic', default=default_topic)
    parser.add_argument('--seconds', type=float, default=10.0)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--self-test', action='store_true')


def check_args(args):
    if not 0 < args.seconds <= 3600 or not 1 <= args.samples <= 1_000_000:
        raise ValueError('Use 0 < seconds <= 3600 and 1 <= samples <= 1000000')
    if args.domain < 0:
        raise ValueError('Domain must be nonnegative')


def motor_fixture(index, t):
    return NS(mode=1, q=0.02*math.sin(t+index/10), dq=0.02*math.cos(t+index/10),
              ddq=0.0, tau_est=0.1, temperature=[30+index%3, 31+index%3],
              vol=52.0, sensor=[0, 0], motorstate=0, reserve=[0]*4)


def fixture(kind, i):
    t = i*0.02
    imu = NS(quaternion=[1.0, 0.0, 0.0, 0.0], gyroscope=[0.0]*3,
             accelerometer=[0.0, 0.0, 9.81], rpy=[0.0]*3, temperature=30)
    if kind == 'g1':
        remote = bytearray(40)
        remote[2] = 1 if i%20 < 10 else 0  # R1
        remote[3] = 1 if i%30 < 15 else 0  # A
        struct.pack_into('<fffff', remote, 4, 0.1*math.sin(t), 0.0, 0.0, 0.0, -0.2)
        return NS(version=[1, 0], mode_pr=0, mode_machine=0, tick=i*20,
                  motor_state=[motor_fixture(j, t) for j in range(35)],
                  imu_state=imu, wireless_remote=list(remote), reserve=[0]*4, crc=0)
    if kind == 'dex3':
        sensors = [NS(pressure=[float(j+k) for k in range(12)], temperature=[25.0]*12,
                      lost=0, reserve=0) for j in range(2)]
        return NS(motor_state=[motor_fixture(j, t) for j in range(7)],
                  press_sensor_state=sensors, imu_state=imu,
                  power_v=48.0, power_a=0.15, system_v=5.0, device_v=3.3,
                  error=[0, 0], reserve=[0, 0])
    raise ValueError('Unknown fixture kind: '+kind)


def stream(kind, args, stats):
    """Yield receive-time/message pairs; callback queue is bounded and counted."""
    check_args(args)
    stats.update(source='live' if args.live else 'synthetic', received=0, dropped=0)
    if not args.live:
        for i in range(args.samples):
            stats['received'] += 1
            yield i*0.02, fixture(kind, i)
        return
    # These are the exact audited vendor imports. No publisher is imported.
    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
    from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_, HandState_
    ChannelFactoryInitialize(args.domain, args.interface)
    inbox = queue.Queue(maxsize=256)
    started = time.monotonic()
    def receive(message):
        stats['received'] += 1
        try:
            inbox.put_nowait((time.monotonic()-started, message))
        except queue.Full:
            stats['dropped'] += 1
    subscriber = ChannelSubscriber(args.topic, LowState_ if kind == 'g1' else HandState_)
    subscriber.Init(receive, 0)  # Our own bounded queue retains receive timestamps.
    try:
        while time.monotonic()-started < args.seconds:
            try:
                yield inbox.get(timeout=min(0.2, max(0.001, args.seconds-(time.monotonic()-started))))
            except queue.Empty:
                pass
    finally:
        subscriber.Close()
