Record G1 HG state through ROS 2

Build the pinned HG message package and subscribe with sensor-data QoS, while keeping a dependency-free mock path for testing the file contract.

PLATFORM: Unitree G1

ENVIRONMENT: Synthetic data; optional ROS 2 subscription

VALIDATION

Offline and shell checks passed

Mock serialization, Python syntax, installer plan and shell syntax passed. Source package dependencies were inspected. The Humble build, ROS discovery and physical hardware subscription were not executed on this host.

REQUIREMENTS

Offline: Python 3.10 or 3.11; no ROS dependency is imported.

Optional live path: Ubuntu 22.04 with an existing official ROS 2 Humble installation. This is a separate environment from a Jazzy foundations workspace.

unitree_ros2 pinned to 668d1ec5a05d1c38d3306bdca7d59f2ba3581a88. The installer builds only unitree_hg; it never builds or starts motion examples.

Verify actual G1 HG message fields, /lowstate endpoint, network interface, DDS domain and development access.

CONFIGURATION

--topic = /lowstate
ROS topic name, not the literal native SDK rt/ prefix.

--interface = enp3s0
Used to construct CycloneDDS interface selection before rclpy initialization.

--domain = 0
Must match the source endpoint; the offline-friendly program default is 1.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-g1-ros2-recorder. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-g1-ros2-recorder"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-g1-ros2-recorder"
  bash install_ros2_messages.sh --self-test
  bash install_ros2_messages.sh --plan
  .venv/bin/python g1_ros_record.py --self-test
  .venv/bin/python g1_ros_record.py --mock --samples 100 --output g1-ros.jsonl
  head -n 1 g1-ros.jsonl
)

# OPTIONAL ROS 2 LIVE READ: uncomment the whole block after confirming
# the exact HG topic, hardware interface and development prerequisites.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-g1-ros2-recorder"
#   bash install_ros2_messages.sh --install
#   source /opt/ros/humble/setup.bash
#   source vendor/unitree_ros2/cyclonedds_ws/install/setup.bash
#   ROBOT_INTERFACE=enp3s0
#   python3 g1_ros_record.py --live --interface "$ROBOT_INTERFACE" --domain 0 --topic /lowstate --seconds 10 --output g1-ros-live.jsonl
# )

EXPECTED RESULT

The offline run writes 100 JSONL frames using the same record function as the DDS SDK2 recorder.

The live branch selects rmw_cyclonedds_cpp and an explicit interface before rclpy initialization; it creates one subscriber and no publishers or services.

ROS node shutdown is attempted on normal duration expiry and Ctrl+C. A zero-frame run exits with status 2.

ROS topic versus native DDS name

The native SDK uses rt/lowstate; the ROS-side example uses /lowstate and generated unitree_hg messages. The ROS message package includes the vendor DDS IDL generation step. Substituting a generic sensor_msgs/JointState type would not make it subscribe to the vendor endpoint.



Why use sensor-data QoS

The standard sensor-data profile uses best-effort delivery with a bounded history, a useful starting point for transient telemetry. Compatibility still depends on the endpoint’s actual offered policy. The callback stamps receipt and queues frames; serialization runs in the spin loop. A queue overflow is counted and shown in the final summary.



TROUBLESHOOTING

unitree_hg cannot be imported.
Run the included message-only installer in Humble, then source both Humble and the built workspace from a clean shell. Use system python3 for the live ROS path; the offline .venv is not the ROS interpreter.

The node exists but receives nothing.
Inspect ros2 topic info /lowstate -v in the same environment. Compare exact message type and offered QoS, then confirm DDS domain and physical interface. Matching a topic name alone is insufficient.

The workspace is Jazzy on Ubuntu 24.04.
Keep it for the foundations course. This audited Unitree adapter recipe follows the repository’s Ubuntu 22.04/Humble support path; a Jazzy port requires its own build and interface validation.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-dds

https://kamilszwed.com/courses/#/lesson/ut-g1-state

https://kamilszwed.com/courses/#/lesson/ut-g1-build

SOURCES

Official ROS 2 integration
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/README.md
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

G1 LowState wire schema
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/msg/LowState.msg
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

Unitree HG ROS 2 CMake message generation
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/CMakeLists.txt
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88
