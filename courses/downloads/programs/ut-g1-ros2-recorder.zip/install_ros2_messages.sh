#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
ROS2_REV=668d1ec5a05d1c38d3306bdca7d59f2ba3581a88
if [[ "${1:---plan}" == --self-test ]]; then
  [[ ${#ROS2_REV} == 40 ]]
  echo 'PASS: ROS 2 source revision is pinned; no installation performed.'
  exit 0
fi
if [[ "${1:---plan}" != --install ]]; then
  echo 'Plan: use an existing Ubuntu 22.04 ROS 2 Humble installation; build only unitree_hg message definitions.'
  echo 'Run bash install_ros2_messages.sh --install when that environment is ready.'
  exit 0
fi
[[ $(uname -s) == Linux ]] || { echo 'Humble setup requires Ubuntu Linux'; exit 2; }
source /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 22.04 ]] || { echo 'This build recipe is for Ubuntu 22.04'; exit 2; }
[[ -f /opt/ros/humble/setup.bash ]] || { echo 'Install ROS 2 Humble from its official Ubuntu instructions first.'; exit 2; }
sudo apt-get update
sudo apt-get install -y git build-essential cmake python3-colcon-common-extensions ros-humble-rmw-cyclonedds-cpp ros-humble-rosidl-generator-dds-idl ros-humble-geometry-msgs ros-humble-rosidl-default-generators
mkdir -p vendor
if [[ ! -d vendor/unitree_ros2/.git ]]; then
  git clone https://github.com/unitreerobotics/unitree_ros2.git vendor/unitree_ros2
fi
[[ -z $(git -C vendor/unitree_ros2 status --porcelain --untracked-files=no) ]] || { echo 'Refusing to replace modified Unitree ROS sources'; exit 2; }
git -C vendor/unitree_ros2 checkout --detach "$ROS2_REV"
[[ $(git -C vendor/unitree_ros2 rev-parse HEAD) == "$ROS2_REV" ]]
# ROS setup scripts can reference unset variables, so do not enable nounset here.
source /opt/ros/humble/setup.bash
(
  cd vendor/unitree_ros2/cyclonedds_ws
  colcon build --packages-select unitree_hg --cmake-args -DBUILD_TESTING=OFF
)
source vendor/unitree_ros2/cyclonedds_ws/install/setup.bash
python3 -c 'from unitree_hg.msg import LowState; print("HG messages imported; no ROS node created")'
echo 'Built message definitions only. No robot example was launched.'
