"""G1 HG ROS 2 subscriber with a mock path and no publishers/services."""
import argparse
import json
import os
import queue
import re
import time
from pathlib import Path
from reader_common import fixture
from g1_record import record


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--live',action='store_true');p.add_argument('--mock',action='store_true')
    p.add_argument('--self-test',action='store_true');p.add_argument('--topic',default='/lowstate')
    p.add_argument('--interface',default='lo');p.add_argument('--domain',type=int,default=1)
    p.add_argument('--seconds',type=float,default=10);p.add_argument('--samples',type=int,default=100)
    p.add_argument('--output',default='g1-ros.jsonl');a=p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_.:-]+',a.interface):p.error('Invalid interface name')
    if not 0<a.seconds<=3600 or not 1<=a.samples<=1000000:p.error('Invalid duration/sample count')
    if a.self_test:
        assert record(fixture('g1',0),0)['motors'][0]['index']==0
        print('PASS: fixture serialization; ROS runtime is not imported in this test');return 0
    count=0;dropped=0
    with Path(a.output).open('w') as handle:
        if not a.live:
            for i in range(a.samples):handle.write(json.dumps(record(fixture('g1',i),i*0.02),allow_nan=False)+'\n');count+=1
        else:
            os.environ['ROS_DOMAIN_ID']=str(a.domain)
            os.environ['RMW_IMPLEMENTATION']='rmw_cyclonedds_cpp'
            os.environ['CYCLONEDDS_URI']=f'<CycloneDDS><Domain><General><Interfaces><NetworkInterface name="{a.interface}"/></Interfaces></General></Domain></CycloneDDS>'
            import rclpy
            from rclpy.qos import qos_profile_sensor_data
            from unitree_hg.msg import LowState
            rclpy.init();node=rclpy.create_node('academy_g1_state_recorder')
            inbox=queue.Queue(maxsize=256);start=time.monotonic()
            def receive(message):
                nonlocal dropped
                try:inbox.put_nowait((time.monotonic()-start,message))
                except queue.Full:dropped+=1
            subscription=node.create_subscription(LowState,a.topic,receive,qos_profile_sensor_data)
            try:
                while rclpy.ok() and time.monotonic()-start<a.seconds:
                    rclpy.spin_once(node,timeout_sec=0.05)
                    while not inbox.empty():
                        received,message=inbox.get_nowait()
                        handle.write(json.dumps(record(message,received),allow_nan=False)+'\n');count+=1
            except KeyboardInterrupt:print('Interrupted; closing ROS node.')
            finally:
                node.destroy_node()
                if rclpy.ok():rclpy.shutdown()
    print(json.dumps(dict(source='ROS2' if a.live else 'synthetic',records=count,dropped=dropped,topic=a.topic)))
    return 0 if count else 2
if __name__=='__main__':raise SystemExit(main())
