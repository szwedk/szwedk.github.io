#!/usr/bin/env bash
# Builds an isolated Humble workspace. Does not launch a driver.
set -eo pipefail
cd "$(dirname "$0")"
test -f /opt/ros/humble/setup.bash || { echo 'Install ROS 2 Humble on Ubuntu 22.04 first.' >&2;exit 2; }
source /opt/ros/humble/setup.bash
sudo apt-get update
sudo apt-get install -y python3-colcon-common-extensions python3-rosdep python3-vcstool git
mkdir -p ros_ws/src
if [ ! -d ros_ws/src/brainco_hand_ros2 ]; then
  git clone https://github.com/BrainCoTech/brainco_hand_ros2.git ros_ws/src/brainco_hand_ros2
  git -C ros_ws/src/brainco_hand_ros2 checkout --detach e98dd933bcc85da86f6993910ffe64e8b981160b
fi
test "$(git -C ros_ws/src/brainco_hand_ros2 rev-parse HEAD)" = e98dd933bcc85da86f6993910ffe64e8b981160b || { echo 'Existing checkout differs from the course pin.' >&2;exit 2; }
cd ros_ws/src/brainco_hand_ros2
vcs import . < brainco_hand.repos --recursive --skip-existing
vcs export --exact . > ../../imported-dependencies.repos
cd ../..
if [ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]; then sudo rosdep init; fi
rosdep update
rosdep install --from-paths src --ignore-src --rosdistro humble -y
colcon build --symlink-install --packages-ignore stark_ethercat_interface stark_ethercat_driver brainco_hand_ethercat_driver
echo 'Workspace built; no driver launched. imported-dependencies.repos records the separately imported repository revisions.'
