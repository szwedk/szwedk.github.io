# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/bc-revo-fake-trajectory"
cd "$HOME/robot-academy/bc-revo-fake-trajectory"
cat > fake_trajectory.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Revo2 FakeSystem-only action client; default writes a trajectory plan offline."""
import argparse
import json
import math
import os
from pathlib import Path
import time
NAMES=['right_thumb_proximal_joint','right_thumb_metacarpal_joint','right_index_proximal_joint',
       'right_middle_proximal_joint','right_ring_proximal_joint','right_pinky_proximal_joint']
POSE=[.2,.05,.3,.3,.3,.3]

def ensure_fake(components):
    if not components:raise ValueError('No hardware components discovered')
    for component in components:
        plugin=component.get('class_type','')
        if plugin not in ('mock_components/GenericSystem','fake_components/GenericSystem'):
            raise ValueError('Refusing non-FakeSystem component: '+plugin)

def main():
    p=argparse.ArgumentParser();p.add_argument('--sim',action='store_true')
    p.add_argument('--manager',default='/controller_manager');p.add_argument('--joint-topic',default='/joint_states')
    p.add_argument('--action',default='/right_revo2_hand_controller/follow_joint_trajectory')
    a=p.parse_args()
    if not a.sim:
        ensure_fake([{'class_type':'mock_components/GenericSystem'}])
        try:ensure_fake([{'class_type':'brainco_hand_driver/BrainCoHandHardware'}])
        except ValueError:pass
        else:raise AssertionError('Real driver was accepted')
        Path('revo2-plan.json').write_text(json.dumps({'mock':True,'joint_names':NAMES,'partial_pose':POSE,'return_pose':[0.]*6},indent=2))
        print('Wrote revo2-plan.json; non-FakeSystem rejection test passed');return
    if os.environ.get('ROS_DOMAIN_ID')!='78' or os.environ.get('ROS_LOCALHOST_ONLY')!='1':
        raise SystemExit('Refusing: set domain 78 and ROS_LOCALHOST_ONLY=1 on this client and FakeSystem launch')
    import rclpy
    from rclpy.node import Node
    from rclpy.action import ActionClient
    from rclpy.qos import qos_profile_sensor_data
    from controller_manager_msgs.srv import ListHardwareComponents
    from control_msgs.action import FollowJointTrajectory
    from trajectory_msgs.msg import JointTrajectoryPoint
    from sensor_msgs.msg import JointState
    rclpy.init();node=Node('course_revo_fake_trajectory');goal_handle=None;finished=False
    def wait(future,seconds):
        rclpy.spin_until_future_complete(node,future,timeout_sec=seconds)
        if not future.done():raise TimeoutError('ROS operation timed out')
        value=future.result()
        if value is None:raise RuntimeError(str(future.exception()))
        return value
    try:
        service=node.create_client(ListHardwareComponents,a.manager.rstrip('/')+'/list_hardware_components')
        if not service.wait_for_service(timeout_sec=5):raise TimeoutError('Controller manager unavailable')
        response=wait(service.call_async(ListHardwareComponents.Request()),5)
        ensure_fake([{'class_type':c.class_type} for c in response.component])
        states={}
        def receive(m):
            if len(m.name)==len(m.position):states.update(zip(m.name,m.position))
        node.create_subscription(JointState,a.joint_topic,receive,qos_profile_sensor_data)
        end=time.monotonic()+5
        while not all(n in states for n in NAMES) and time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.1)
        if not all(n in states for n in NAMES):raise RuntimeError('Required right-hand joints not observed')
        if not all(math.isfinite(states[n]) for n in NAMES):raise RuntimeError('Nonfinite simulated joint state')
        client=ActionClient(node,FollowJointTrajectory,a.action)
        if not client.wait_for_server(timeout_sec=5):raise TimeoutError('Trajectory action unavailable')
        goal=FollowJointTrajectory.Goal();goal.trajectory.joint_names=NAMES
        for seconds,positions in ((1,[states[n] for n in NAMES]),(3,POSE),(5,[0.]*6)):
            pt=JointTrajectoryPoint();pt.positions=positions;pt.time_from_start.sec=seconds;goal.trajectory.points.append(pt)
        goal_handle=wait(client.send_goal_async(goal),5)
        if not goal_handle.accepted:raise RuntimeError('Trajectory rejected')
        result=wait(goal_handle.get_result_async(),12);finished=True
        if result.result.error_code!=0:raise RuntimeError('Controller error: '+str(result.result.error_code)+' '+result.result.error_string)
        Path('revo2-execution.json').write_text(json.dumps({'simulation_only':True,'action_status':result.status,'controller_error_code':result.result.error_code,'joint_names':NAMES},indent=2))
        print('FakeSystem trajectory completed; wrote revo2-execution.json')
    finally:
        if goal_handle is not None and goal_handle.accepted and not finished:
            try:wait(goal_handle.cancel_goal_async(),2)
            except Exception as error:print('Simulation cancellation failed:',error)
        node.destroy_node();rclpy.try_shutdown()
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:raise SystemExit(130)
ACADEMY_FILE_0
cat > prepare_ros.sh <<'ACADEMY_FILE_1'
#!/usr/bin/env bash
# Builds an isolated Humble workspace. Does not launch a driver.
set -eo pipefail
cd "$(dirname "$0")"
test -f /opt/ros/humble/setup.bash || { echo 'Install ROS 2 Humble on Ubuntu 22.04 first.' >&2;exit 2; }
source /opt/ros/humble/setup.bash
sudo apt-get update
sudo apt-get install -y python3-colcon-common-extensions python3-rosdep python3-vcstool git
mkdir -p ros_ws/src
if [ ! -d ros_ws/src/brainco_hand_ros2 ]; then
  git clone https://github.com/BrainCoTech/brainco_hand_ros2.git ros_ws/src/brainco_hand_ros2
  git -C ros_ws/src/brainco_hand_ros2 checkout --detach e98dd933bcc85da86f6993910ffe64e8b981160b
fi
test "$(git -C ros_ws/src/brainco_hand_ros2 rev-parse HEAD)" = e98dd933bcc85da86f6993910ffe64e8b981160b || { echo 'Existing checkout differs from the course pin.' >&2;exit 2; }
cd ros_ws/src/brainco_hand_ros2
vcs import . < brainco_hand.repos --recursive --skip-existing
vcs export --exact . > ../../imported-dependencies.repos
cd ../..
if [ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]; then sudo rosdep init; fi
rosdep update
rosdep install --from-paths src --ignore-src --rosdistro humble -y
colcon build --symlink-install --packages-ignore stark_ethercat_interface stark_ethercat_driver brainco_hand_ethercat_driver
echo 'Workspace built; no driver launched. imported-dependencies.repos records the separately imported repository revisions.'
ACADEMY_FILE_1
printf '%s\n' 'Created 2 file(s) in ~/robot-academy/bc-revo-fake-trajectory'
)
