Send and verify a Revo2 simulated hand trajectory

Build the pinned ROS workspace, launch its FakeSystem, and use a standard action client to partially close six named joints and return them to zero.

PLATFORM: BrainCo Revo

ENVIRONMENT: Simulation

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Simulation: Ubuntu 22.04, ROS 2 Humble, ros2_control and MoveIt installed via the included preparation script

All launch/client processes isolated on ROS_DOMAIN_ID=78 and ROS_LOCALHOST_ONLY=1

The client checks the controller manager’s loaded plugin and refuses physical hardware

CONFIGURATION

REVO_RUN_FAKE = 1
Enables the local simulation action client after preparing and launching FakeSystem.

--manager = /controller_manager
Controller manager namespace that must report only accepted mock components.

--action = /right_revo2_hand_controller/follow_joint_trajectory
Action endpoint from the pinned right-hand MoveIt/controller configuration.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/bc-revo-fake-trajectory. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/bc-revo-fake-trajectory"
cd "$HOME/robot-academy/bc-revo-fake-trajectory"
python3 --version
python3 -m py_compile fake_trajectory.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/bc-revo-fake-trajectory"
python3 fake_trajectory.py

# Optional one-time workspace preparation (installs dependencies, no driver launch):
# bash prepare_ros.sh
# Terminal A, after preparation, explicitly launch the FakeSystem:
# source /opt/ros/humble/setup.bash
# source "$HOME/robot-academy/bc-revo-fake-trajectory/ros_ws/install/setup.bash"
# export ROS_DOMAIN_ID=78 ROS_LOCALHOST_ONLY=1
# ros2 launch brainco_moveit_config revo2_right_moveit.launch.py

# Terminal B: set REVO_RUN_FAKE=1 before copying this block to execute the client.
if [ "${REVO_RUN_FAKE:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
source "$HOME/robot-academy/bc-revo-fake-trajectory/ros_ws/install/setup.bash"
export ROS_DOMAIN_ID=78 ROS_LOCALHOST_ONLY=1
python3 fake_trajectory.py --sim
fi
)

EXPECTED RESULT

Offline creates a joint-name/pose plan and verifies that a physical driver plugin is rejected.

Simulation client requires six finite named joint states before sending an action.

The five-second trajectory visits current state, partial closure and zero; success writes revo2-execution.json.

Timeout or interruption attempts action cancellation and cleans up the node.

Why controller discovery comes first

The Humble ListHardwareComponents response uses the field component, and each entry exposes class_type. The script checks those actual interface fields and accepts only GenericSystem mock/fake plugins. A different or empty plugin fails closed. It then reads all required right-hand names rather than trusting the array order. The action goals carry names, positions and increasing time_from_start values, allowing the trajectory controller to match coordinates explicitly.



A simulation of the interface, not contact physics

BrainCo’s FakeSystem mirrors commanded joint state through ros2_control. It is useful for testing names, action acceptance, timing and application cleanup. It does not prove tendon behavior, current limits, object contact or real hand calibration. The partial pose values are modest simulated joint targets, not a validated grasp. The included preparation script pins the main repository and exports exact revisions of separately imported description dependencies so the build can be recorded.



TROUBLESHOOTING

Non-FakeSystem component rejected
Use the documented FakeSystem launch. The client intentionally has no override for a real hardware plugin.

Trajectory action unavailable
Check the loaded controller name, its active state and matching ROS domain. An RViz model on screen does not establish a running trajectory controller.

rosdep/build fails
Review the failing package and Ubuntu/Humble prerequisites. EtherCAT packages are excluded in this default build; do not mix another ROS distribution into the workspace.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/bc-revo-ros-control

SOURCES

BrainCo Revo2 ROS 2 packages
https://github.com/BrainCoTech/brainco_hand_ros2/blob/e98dd933bcc85da86f6993910ffe64e8b981160b/README.md
e98dd933bcc85da86f6993910ffe64e8b981160b; 2026-08-20T02:04:48Z

Revo2 MoveIt configuration
https://github.com/BrainCoTech/brainco_hand_ros2/blob/e98dd933bcc85da86f6993910ffe64e8b981160b/brainco_moveit_config/README_CN.md
e98dd933bcc85da86f6993910ffe64e8b981160b; 2026-08-20T02:04:48Z

ros2_control hardware inspection service
https://github.com/ros-controls/ros2_control/blob/humble/controller_manager_msgs/srv/ListHardwareComponents.srv
Humble branch; reviewed 2026-09-29

Revo2 right-hand FakeSystem configuration
https://github.com/BrainCoTech/brainco_hand_ros2/blob/e98dd933bcc85da86f6993910ffe64e8b981160b/brainco_moveit_config/config/revo2_right.ros2_control.xacro
e98dd933bcc85da86f6993910ffe64e8b981160b
