#!/usr/bin/env bash
# The ready file is written only after this exact local listener owns its port.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p reports
run_dir=$(mktemp -d reports/listener.XXXXXX)
server_pid=''
cleanup() {
  if [[ -n "$server_pid" ]] && kill -0 "$server_pid" 2>/dev/null; then
    kill "$server_pid"
    wait "$server_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 local_listener.py --ready-file "$run_dir/port.txt" >"$run_dir/listener.log" 2>&1 &
server_pid=$!
for _attempt in 1 2 3 4 5 6 7 8 9 10; do
  if ! kill -0 "$server_pid" 2>/dev/null; then
    printf 'The local listener exited; inspect %s/listener.log\n' "$run_dir" >&2
    exit 1
  fi
  if [[ -s "$run_dir/port.txt" ]]; then
    break
  fi
  sleep 0.2
done
if [[ ! -s "$run_dir/port.txt" ]]; then
  printf '%s\n' 'No listener readiness file appeared within the bounded startup window.' >&2
  exit 1
fi
read -r listener_port < "$run_dir/port.txt"
python3 network_probe.py --host 127.0.0.1 --port "$listener_port" --output reports/network.json
