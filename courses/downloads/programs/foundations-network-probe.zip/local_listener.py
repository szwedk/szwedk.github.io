#!/usr/bin/env python3
"""Disposable loopback TCP listener; the OS chooses an unused port."""
import argparse
from pathlib import Path
import socketserver


class CloseImmediately(socketserver.BaseRequestHandler):
    def handle(self):
        pass


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ready-file", type=Path, required=True)
    args = parser.parse_args()
    with socketserver.TCPServer(("127.0.0.1", 0), CloseImmediately) as server:
        args.ready_file.write_text(str(server.server_address[1]) + "\n", encoding="utf-8")
        server.serve_forever()
