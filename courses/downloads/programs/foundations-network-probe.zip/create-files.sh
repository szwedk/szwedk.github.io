# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/foundations-network-probe"
cd "$HOME/robot-academy/foundations-network-probe"
cat > network_probe.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Probe one explicitly selected TCP endpoint; no subnet or port scanning."""
import argparse
from datetime import datetime, timezone
import ipaddress
import json
from pathlib import Path
import platform
import socket
import subprocess
import sys
import time


def check_port(value):
    value = int(value)
    if not 1 <= value <= 65535:
        raise argparse.ArgumentTypeError("port must be between 1 and 65535")
    return value


def check_timeout(value):
    value = float(value)
    if not 0 < value <= 10:
        raise argparse.ArgumentTypeError("timeout must be greater than 0 and at most 10 seconds")
    return value


def probe(host, port, timeout):
    # Accept a numeric address so DNS cannot introduce an unbounded resolver wait.
    address = ipaddress.ip_address(host)
    family = socket.AF_INET6 if address.version == 6 else socket.AF_INET
    started = time.monotonic()
    try:
        with socket.socket(family, socket.SOCK_STREAM) as client:
            client.settimeout(timeout)
            client.connect((str(address), port))
        return {"connected": True, "elapsed_ms": round((time.monotonic()-started)*1000, 3)}
    except OSError as error:
        return {"connected": False, "elapsed_ms": round((time.monotonic()-started)*1000, 3),
                "error_type": type(error).__name__, "error": str(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1", help="One numeric IPv4 or IPv6 address you own or may test.")
    parser.add_argument("--port", type=check_port, default=8765)
    parser.add_argument("--timeout", type=check_timeout, default=1.0)
    parser.add_argument("--ping", action="store_true", help="Also send three ICMP requests on Linux.")
    parser.add_argument("--output", type=Path, default=Path("reports/network.json"))
    args = parser.parse_args()
    try:
        ipaddress.ip_address(args.host)
    except ValueError:
        parser.error("--host must be one numeric IP address, not a hostname or range")
    report = {"generated_utc": datetime.now(timezone.utc).isoformat(),
              "host": args.host, "port": args.port, "tcp": probe(args.host, args.port, args.timeout),
              "meaning": "TCP connection only; no ROS, SDK, authentication, or application task is verified."}
    if args.ping:
        if platform.system() != "Linux":
            report["ping"] = {"status": "not-run", "reason": "This optional command uses Linux iputils flags."}
        else:
            try:
                result = subprocess.run(["ping", "-n", "-c", "3", "-W", "1", args.host],
                                        capture_output=True, text=True, timeout=6, check=False)
                report["ping"] = {"exit_code": result.returncode,
                                  "stdout": result.stdout[:5000], "stderr": result.stderr[:1000]}
            except (OSError, subprocess.TimeoutExpired) as error:
                report["ping"] = {"status": "failed", "error": str(error)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["tcp"]["connected"] else 2


if __name__ == "__main__":
    sys.exit(main())
ACADEMY_FILE_0
cat > local_listener.py <<'ACADEMY_FILE_1'
#!/usr/bin/env python3
"""Disposable loopback TCP listener; the OS chooses an unused port."""
import argparse
from pathlib import Path
import socketserver


class CloseImmediately(socketserver.BaseRequestHandler):
    def handle(self):
        pass


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ready-file", type=Path, required=True)
    args = parser.parse_args()
    with socketserver.TCPServer(("127.0.0.1", 0), CloseImmediately) as server:
        args.ready_file.write_text(str(server.server_address[1]) + "\n", encoding="utf-8")
        server.serve_forever()
ACADEMY_FILE_1
cat > run_local_probe.sh <<'ACADEMY_FILE_2'
#!/usr/bin/env bash
# The ready file is written only after this exact local listener owns its port.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p reports
run_dir=$(mktemp -d reports/listener.XXXXXX)
server_pid=''
cleanup() {
  if [[ -n "$server_pid" ]] && kill -0 "$server_pid" 2>/dev/null; then
    kill "$server_pid"
    wait "$server_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 local_listener.py --ready-file "$run_dir/port.txt" >"$run_dir/listener.log" 2>&1 &
server_pid=$!
for _attempt in 1 2 3 4 5 6 7 8 9 10; do
  if ! kill -0 "$server_pid" 2>/dev/null; then
    printf 'The local listener exited; inspect %s/listener.log\n' "$run_dir" >&2
    exit 1
  fi
  if [[ -s "$run_dir/port.txt" ]]; then
    break
  fi
  sleep 0.2
done
if [[ ! -s "$run_dir/port.txt" ]]; then
  printf '%s\n' 'No listener readiness file appeared within the bounded startup window.' >&2
  exit 1
fi
read -r listener_port < "$run_dir/port.txt"
python3 network_probe.py --host 127.0.0.1 --port "$listener_port" --output reports/network.json
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/foundations-network-probe'
)
