Prove one TCP endpoint with a local fixture

Start a disposable loopback listener, learn its allocated port, connect to that exact endpoint, and clean up the process you created. Then adapt the single-target probe to an authorized known host.

PLATFORM: Linux & Python

ENVIRONMENT: Offline

VALIDATION

Locally tested

Successful loopback connection with a disposable listener and refused-connection case executed. Bash syntax and ShellCheck passed. Linux-only optional ping branch is documented but not runtime-tested here.

REQUIREMENTS

Python 3.10+ and Bash; optional ICMP probe on Linux

Python 3.10+ and Bash

No external packages; default exercise is localhost only

CONFIGURATION

--host = 127.0.0.1
One numeric address, never a subnet or hostname.

--port = 8765
One TCP port from 1 through 65535; the local wrapper supplies its allocated port.

--timeout = 1.0
Connection timeout in seconds; greater than zero and no more than 10.

--ping = --ping
Optional Linux-only three-packet ICMP observation.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/foundations-network-probe. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/foundations-network-probe"
  python3 -m py_compile network_probe.py local_listener.py
  bash -n run_local_probe.sh
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/foundations-network-probe"
  bash run_local_probe.sh
  python3 -m json.tool reports/network.json
)

EXPECTED RESULT

tcp.connected is true for the temporary localhost listener.

The port is chosen by the operating system and appears in the report.

The EXIT trap stops only the captured listener process.

A refused endpoint returns process exit status 2 and preserves the failure reason.

Follow the lifecycle

The wrapper starts a local listener using port zero, which asks the operating system to allocate an unused port. The listener writes a readiness file only after it owns that port. The wrapper then probes exactly that endpoint and uses a saved PID for cleanup. This avoids confusing a pre-existing service with the fixture you intended to test.



Interpret the result narrowly

A successful TCP connect proves that this connection could be established at that time. It does not prove a ROS domain is correct, a DDS topic is compatible, an SSH login is authorized, or a vendor command API works. The elapsed value is connection-establishment time observed on the host; it is not robot control latency.



Adapt it without scanning

After the localhost exercise, run network_probe.py with --host followed by one numeric address you own or are authorized to test, and --port followed by the documented service port. Do not invent robot IP addresses or credentials. The optional --ping branch sends three requests using Linux iputils; ICMP and TCP outcomes can differ because they exercise different mechanisms.



TROUBLESHOOTING

Invalid IP address error
Use one numeric IPv4 or IPv6 address. This program intentionally does not resolve hostnames or accept ranges.

Connection refused
The address was reached but that TCP connection was refused; check whether the expected service is listening on the exact port.

Timeout
Check route, host availability, firewall policy, and the stated timeout. A timeout alone does not identify which component caused it.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/linux-networking

https://kamilszwed.com/courses/#/lesson/linux-permissions-processes

SOURCES

iputils ping manual
https://raw.githubusercontent.com/iputils/iputils/master/doc/ping.xml
Primary documentation retrieved 2026-09-29

Python socket interface
https://docs.python.org/3/library/socket.html
Primary documentation retrieved 2026-09-29

Python subprocess
https://docs.python.org/3/library/subprocess.html
Primary documentation retrieved 2026-09-29
