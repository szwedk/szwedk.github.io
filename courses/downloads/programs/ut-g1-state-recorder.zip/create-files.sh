# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-g1-state-recorder"
cd "$HOME/robot-academy/ut-g1-state-recorder"
cat > reader_common.py <<'ACADEMY_FILE_0'
"""Shared receive-only SDK2 utilities; importing this module never opens DDS."""
import argparse
import math
import queue
import struct
import time
from types import SimpleNamespace as NS


def add_reader_args(parser, default_topic):
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--live', action='store_true', help='Subscribe to a configured DDS endpoint')
    group.add_argument('--mock', action='store_true', help='Use synthetic data (default)')
    parser.add_argument('--interface', default='lo')
    parser.add_argument('--domain', type=int, default=1)
    parser.add_argument('--topic', default=default_topic)
    parser.add_argument('--seconds', type=float, default=10.0)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--self-test', action='store_true')


def check_args(args):
    if not 0 < args.seconds <= 3600 or not 1 <= args.samples <= 1_000_000:
        raise ValueError('Use 0 < seconds <= 3600 and 1 <= samples <= 1000000')
    if args.domain < 0:
        raise ValueError('Domain must be nonnegative')


def motor_fixture(index, t):
    return NS(mode=1, q=0.02*math.sin(t+index/10), dq=0.02*math.cos(t+index/10),
              ddq=0.0, tau_est=0.1, temperature=[30+index%3, 31+index%3],
              vol=52.0, sensor=[0, 0], motorstate=0, reserve=[0]*4)


def fixture(kind, i):
    t = i*0.02
    imu = NS(quaternion=[1.0, 0.0, 0.0, 0.0], gyroscope=[0.0]*3,
             accelerometer=[0.0, 0.0, 9.81], rpy=[0.0]*3, temperature=30)
    if kind == 'g1':
        remote = bytearray(40)
        remote[2] = 1 if i%20 < 10 else 0  # R1
        remote[3] = 1 if i%30 < 15 else 0  # A
        struct.pack_into('<fffff', remote, 4, 0.1*math.sin(t), 0.0, 0.0, 0.0, -0.2)
        return NS(version=[1, 0], mode_pr=0, mode_machine=0, tick=i*20,
                  motor_state=[motor_fixture(j, t) for j in range(35)],
                  imu_state=imu, wireless_remote=list(remote), reserve=[0]*4, crc=0)
    if kind == 'dex3':
        sensors = [NS(pressure=[float(j+k) for k in range(12)], temperature=[25.0]*12,
                      lost=0, reserve=0) for j in range(2)]
        return NS(motor_state=[motor_fixture(j, t) for j in range(7)],
                  press_sensor_state=sensors, imu_state=imu,
                  power_v=48.0, power_a=0.15, system_v=5.0, device_v=3.3,
                  error=[0, 0], reserve=[0, 0])
    raise ValueError('Unknown fixture kind: '+kind)


def stream(kind, args, stats):
    """Yield receive-time/message pairs; callback queue is bounded and counted."""
    check_args(args)
    stats.update(source='live' if args.live else 'synthetic', received=0, dropped=0)
    if not args.live:
        for i in range(args.samples):
            stats['received'] += 1
            yield i*0.02, fixture(kind, i)
        return
    # These are the exact audited vendor imports. No publisher is imported.
    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
    from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_, HandState_
    ChannelFactoryInitialize(args.domain, args.interface)
    inbox = queue.Queue(maxsize=256)
    started = time.monotonic()
    def receive(message):
        stats['received'] += 1
        try:
            inbox.put_nowait((time.monotonic()-started, message))
        except queue.Full:
            stats['dropped'] += 1
    subscriber = ChannelSubscriber(args.topic, LowState_ if kind == 'g1' else HandState_)
    subscriber.Init(receive, 0)  # Our own bounded queue retains receive timestamps.
    try:
        while time.monotonic()-started < args.seconds:
            try:
                yield inbox.get(timeout=min(0.2, max(0.001, args.seconds-(time.monotonic()-started))))
            except queue.Empty:
                pass
    finally:
        subscriber.Close()
ACADEMY_FILE_0
cat > g1_record.py <<'ACADEMY_FILE_1'
"""Record G1 HG state to CSV + JSONL. No commands or motion-mode changes."""
import argparse
import csv
import json
import math
from pathlib import Path
from reader_common import add_reader_args, fixture, stream

G1_29_PR = ['left_hip_pitch','left_hip_roll','left_hip_yaw','left_knee',
 'left_ankle_pitch','left_ankle_roll','right_hip_pitch','right_hip_roll','right_hip_yaw',
 'right_knee','right_ankle_pitch','right_ankle_roll','waist_yaw','waist_roll','waist_pitch',
 'left_shoulder_pitch','left_shoulder_roll','left_shoulder_yaw','left_elbow','left_wrist_roll',
 'left_wrist_pitch','left_wrist_yaw','right_shoulder_pitch','right_shoulder_roll',
 'right_shoulder_yaw','right_elbow','right_wrist_roll','right_wrist_pitch','right_wrist_yaw']


def record(message, received_s, mapping='raw'):
    if mapping == 'g1-29-pr' and int(message.mode_pr) != 0:
        raise ValueError('Named PR map cannot label a sample in AB coordinate mode')
    motors = []
    for index, motor in enumerate(message.motor_state):
        name = G1_29_PR[index] if mapping == 'g1-29-pr' and index < 29 else 'slot_'+str(index)
        motors.append(dict(index=index, name=name, q=float(motor.q), dq=float(motor.dq),
                           tau_est=float(motor.tau_est), temperature=list(motor.temperature),
                           voltage=float(motor.vol), status=int(motor.motorstate)))
    return dict(received_s=received_s, tick=int(message.tick), mode_pr=int(message.mode_pr),
                mode_machine=int(message.mode_machine), quaternion=list(message.imu_state.quaternion),
                gyroscope=list(message.imu_state.gyroscope), motors=motors)


def self_test():
    row = record(fixture('g1', 0), 0.0, 'g1-29-pr')
    assert len(row['motors']) == 35 and row['motors'][25]['name'] == 'right_elbow'
    bad = fixture('g1', 0); bad.mode_pr = 1
    try: record(bad, 0.0, 'g1-29-pr')
    except ValueError: pass
    else: raise AssertionError('AB mode accepted as PR')
    print('PASS: 35 raw slots retained; 29-joint labels checked; wrong coordinate mode rejected')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    add_reader_args(p, 'rt/lowstate')
    p.add_argument('--map', choices=['raw','g1-29-pr'], default='raw')
    p.add_argument('--output', default='g1-state')
    args = p.parse_args()
    if args.self_test: self_test(); return 0
    prefix = Path(args.output); prefix.parent.mkdir(parents=True, exist_ok=True)
    stats = {}; written = rejected = 0
    try:
        with prefix.with_suffix('.jsonl').open('w') as jf, prefix.with_suffix('.csv').open('w', newline='') as cf:
            writer = csv.writer(cf)
            writer.writerow(['received_s','tick','mode_pr','mode_machine','index','joint','q_rad',
                             'dq_rad_s','tau_est','temperature_0','temperature_1','voltage','status'])
            try:
                for received, message in stream('g1', args, stats):
                    try:
                        row = record(message, received, args.map)
                        encoded = json.dumps(row, allow_nan=False)
                    except (ValueError, TypeError, AttributeError) as error:
                        rejected += 1
                        print('Rejected sample:', error)
                        continue
                    jf.write(encoded+'\n')
                    for m in row['motors']:
                        writer.writerow([received,row['tick'],row['mode_pr'],row['mode_machine'],
                                         m['index'],m['name'],m['q'],m['dq'],m['tau_est'],
                                         *m['temperature'],m['voltage'],m['status']])
                    written += 1
            except KeyboardInterrupt:
                print('Interrupted; closing files and subscriber.')
    finally:
        summary = dict(stats, written=written, rejected=rejected, mapping=args.map)
        prefix.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary))
    return 0 if written else 2

if __name__ == '__main__':
    raise SystemExit(main())
ACADEMY_FILE_1
cat > install_sdk2.sh <<'ACADEMY_FILE_2'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK2_REV=63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36
PYTHON_REV=814556d15970dd2ecf1c9984e845ca02ab07e206
CYCLONE_REV=9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd
if [[ "${1:---plan}" == --self-test ]]; then
  [[ ${#SDK2_REV} == 40 && ${#PYTHON_REV} == 40 && ${#CYCLONE_REV} == 40 ]]
  echo 'PASS: pinned revisions are defined; installer did not run.'
  exit 0
fi
if [[ "${1:---plan}" != --install ]]; then
  echo 'Plan: install Ubuntu build prerequisites; build CycloneDDS 0.10.2 and SDK2; create a local Python environment.'
  echo 'No robot program will be launched. Run: bash install_sdk2.sh --install'
  exit 0
fi
[[ $(uname -s) == Linux ]] || { echo 'Live SDK environment requires Linux; mock programs run without this installer.'; exit 2; }
source /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 22.04 ]] || { echo 'This recipe targets Ubuntu 22.04. Keep another distribution in a separate tested environment.'; exit 2; }
case $(uname -m) in x86_64|aarch64) ;; *) echo 'Unsupported architecture for this recipe'; exit 2;; esac
sudo apt-get update
sudo apt-get install -y git cmake build-essential python3-venv python3-dev libssl-dev
mkdir -p vendor
checkout() {
  local url=$1 directory=$2 revision=$3
  if [[ ! -d "$directory/.git" ]]; then git clone "$url" "$directory"; fi
  [[ -z $(git -C "$directory" status --porcelain --untracked-files=no) ]] || { echo "Refusing to change modified source: $directory"; return 2; }
  git -C "$directory" checkout --detach "$revision"
  [[ $(git -C "$directory" rev-parse HEAD) == "$revision" ]]
}
checkout https://github.com/eclipse-cyclonedds/cyclonedds.git vendor/cyclonedds "$CYCLONE_REV"
cmake -S vendor/cyclonedds -B vendor/cyclonedds-build -DCMAKE_INSTALL_PREFIX="$PWD/vendor/cyclonedds-install" -DBUILD_EXAMPLES=OFF
cmake --build vendor/cyclonedds-build --parallel 2
cmake --install vendor/cyclonedds-build
checkout https://github.com/unitreerobotics/unitree_sdk2.git vendor/unitree_sdk2 "$SDK2_REV"
cmake -S vendor/unitree_sdk2 -B vendor/sdk2-build -DCMAKE_INSTALL_PREFIX="$PWD/vendor/sdk2-install" -DBUILD_EXAMPLES=OFF
cmake --build vendor/sdk2-build --parallel 2
cmake --install vendor/sdk2-build
checkout https://github.com/unitreerobotics/unitree_sdk2_python.git vendor/unitree_sdk2_python "$PYTHON_REV"
python3 -m venv .venv
export CYCLONEDDS_HOME="$PWD/vendor/cyclonedds-install"
export LD_LIBRARY_PATH="$CYCLONEDDS_HOME/lib:${LD_LIBRARY_PATH:-}"
.venv/bin/python -m pip install 'numpy==1.26.4' 'opencv-python==4.10.0.84' 'cyclonedds==0.10.2'
.venv/bin/python -m pip install --no-deps -e vendor/unitree_sdk2_python
cat > activate-sdk.sh <<'ACTIVATE'
# Source this file from this recipe directory before live reads.
export CYCLONEDDS_HOME="$PWD/vendor/cyclonedds-install"
export LD_LIBRARY_PATH="$CYCLONEDDS_HOME/lib:${LD_LIBRARY_PATH:-}"
source .venv/bin/activate
ACTIVATE
.venv/bin/python -c 'from unitree_sdk2py.core.channel import ChannelSubscriber; print("SDK2 import passed; no DDS participant opened")'
.venv/bin/python -m pip freeze > environment-freeze.txt
printf 'SDK2=%s\nSDK2_PYTHON=%s\nCYCLONEDDS=%s\n' "$SDK2_REV" "$PYTHON_REV" "$CYCLONE_REV" > revisions.txt
echo 'Build complete. No robot example was executed.'
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/ut-g1-state-recorder'
)
