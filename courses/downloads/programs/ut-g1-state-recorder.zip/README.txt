Record G1 joint state to CSV and JSONL

A complete receive-only HG LowState recorder with raw slot preservation, monotonic arrival timestamps, a bounded queue, and explicit optional 29-joint PR labels.

PLATFORM: Unitree G1

ENVIRONMENT: Synthetic data; optional DDS subscription

VALIDATION

Offline tests passed

Python syntax, embedded self-test and synthetic run passed on macOS arm64 with Python 3.11. Live transport and physical robot behavior were not tested.

REQUIREMENTS

Offline path: Python 3.10 or 3.11 and a terminal. No SDK, ROS, robot or network is needed for synthetic data.

Optional SDK path: Ubuntu 22.04 x86_64/aarch64, Python 3.10, administrative access for build packages, an Ethernet interface, and the exact robot edition with supported development access.

Pinned SDK2 C++ 63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36; SDK2 Python 814556d15970dd2ecf1c9984e845ca02ab07e206; CycloneDDS 0.10.2 at 9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd.

Live: confirm rt/lowstate and unitree_hg LowState for the exact G1 firmware. Raw is the default mapping; use g1-29-pr only for a verified 29-DOF PR configuration.

CONFIGURATION

--map = raw
Default raw indexing is valid for capture without assuming all 35 slots are active. g1-29-pr explicitly opts into the documented 29-DOF PR name table.

--topic = rt/lowstate
DDS topic name. Verify against the actual vendor state publisher.

--interface = enp3s0
Live Ethernet interface; replace with the name reported by ip -brief address. The program default lo is suitable only for loopback endpoints.

--domain = 0
Hardware domain must match the endpoint. Default 1 is deliberately isolated for local simulator setups.

--seconds = 10
Bounds a live recording; --samples controls only synthetic record count.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-g1-state-recorder. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-g1-state-recorder"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-g1-state-recorder"
  .venv/bin/python g1_record.py --self-test
  .venv/bin/python g1_record.py --mock --samples 100 --output g1-state
  head -n 4 g1-state.csv
  cat g1-state.summary.json
)

# OPTIONAL LIVE READ: first verify the exact robot, network interface,
# DDS domain and vendor development access. Uncomment the whole block.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-g1-state-recorder"
#   bash install_sdk2.sh --install
#   source activate-sdk.sh
#   ROBOT_INTERFACE=enp3s0
#   python g1_record.py --live --interface "$ROBOT_INTERFACE" --domain 0 --seconds 10 --output g1-live
# )

EXPECTED RESULT

The mock run writes 100 JSONL frames and 3,500 motor rows plus the CSV header. All 35 HG storage slots remain visible.

The summary identifies synthetic versus live source, callback receive count, queue drop count, records written and rejected samples.

A finite live run subscribes only. Ctrl+C closes the subscriber and files; no command publisher or locomotion client is created.

Capture timing and pressure on the callback

The DDS callback stamps each arrival with time.monotonic and places it in a 256-item queue. CSV serialization runs outside that callback so disk work does not directly stall the middleware listener. When the queue is full, the new frame is dropped and counted. The count is local overload evidence; it cannot measure packets that never reached the host.



Reading the files

JSONL stores one complete frame per line, including mode_pr, mode_machine, raw tick, quaternion, angular rate and all motor states. CSV normalizes motor frames into rows with index, optional name, q, dq, estimated torque, two temperature values, voltage and raw motor status. The raw tick is preserved without subtracting it from the host clock. JSON serialization rejects nonfinite values, and the summary reports rejected frames.



Choosing joint names deliberately

The optional g1-29-pr map uses the audited current SDK joint order and rejects mode_pr=1. It does not identify the physical edition automatically. A 23-DOF body or modified wrist layout can expose the same message capacity; select names only after the platform identity lesson and vendor configuration inspection.



TROUBLESHOOTING

The live reader records zero samples.
Confirm the interface exists, the DDS domain matches, the exact HG type and topic are published, and the robot edition supports this interface. The reader exits after the requested duration; it never changes a controller mode to make state appear.

Importing cyclonedds fails or the native library cannot be found.
Run the included installer only on its supported Ubuntu version, then source activate-sdk.sh from this recipe directory. Do not mix the system ROS Python environment with this private SDK virtual environment.

The CSV contains slot_29 through slot_34.
These are retained schema slots, not a claim that the robot has 35 actuated joints. Filter a confirmed configuration when analyzing; keep the original capture intact.

Named mapping rejects AB coordinate mode.
Use raw capture to preserve the evidence. PR and AB encode different ankle/wrist coordinates; changing labels is not a coordinate transform.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-state

https://kamilszwed.com/courses/#/lesson/ut-g1-dds

https://kamilszwed.com/courses/#/lesson/ut-g1-timing

SOURCES

SDK2 Python installation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/README.md
814556d15970dd2ecf1c9984e845ca02ab07e206

G1 LowState wire schema
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/msg/LowState.msg
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

G1 ROS 2 state example
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/example/src/src/read_low_state_hg.cpp
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

SDK2 Python subscriber lifecycle and queue implementation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/core/channel.py
814556d15970dd2ecf1c9984e845ca02ab07e206

HG Python MotorState generated fields
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/idl/unitree_hg/msg/dds_/_MotorState_.py
814556d15970dd2ecf1c9984e845ca02ab07e206
