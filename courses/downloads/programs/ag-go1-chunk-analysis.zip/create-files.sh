# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ag-go1-chunk-analysis"
cd "$HOME/robot-academy/ag-go1-chunk-analysis"
cat > analyze_chunk.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Analyze an action NPY and optional aligned reference; creates CSV+SVG, never commands."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np


def analyze(actions,hz):
    if actions.ndim!=2 or min(actions.shape)<1 or not np.isfinite(actions).all():raise ValueError('Expected finite [time,action] array')
    if not np.isfinite(hz) or hz<=0:raise ValueError('Positive finite Hz required')
    differences=np.diff(actions,axis=0)
    return {'steps':int(actions.shape[0]),'dimensions':int(actions.shape[1]),'horizon_s':actions.shape[0]/hz,
       'minimum':actions.min(axis=0).tolist(),'maximum':actions.max(axis=0).tolist(),
       'max_adjacent_change':np.max(np.abs(differences),axis=0).tolist() if len(differences) else [0.]*actions.shape[1]}


def plot_svg(actions,hz,out):
    width,height=960,340;left,right,top,bottom=60,920,35,280
    selected=actions[:,:min(6,actions.shape[1])];lo,hi=float(selected.min()),float(selected.max())
    if hi==lo:lo-=.5;hi+=.5
    colors=['#157f9f','#cc5a34','#668c36','#9559a8','#c18d23','#365cb1']
    pieces=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
      '<rect width="100%" height="100%" fill="white"/>',
      '<text x="60" y="22" font-family="sans-serif" font-size="16">Action chunk: first six dimensions (checkpoint units)</text>',
      f'<path d="M{left},{top}V{bottom}H{right}" fill="none" stroke="#777"/>']
    for j in range(selected.shape[1]):
        points=' '.join(f'{left+(right-left)*i/max(1,len(actions)-1):.2f},{bottom-(bottom-top)*(v-lo)/(hi-lo):.2f}' for i,v in enumerate(selected[:,j]))
        pieces.append(f'<polyline points="{points}" fill="none" stroke="{colors[j]}" stroke-width="2"/>')
        pieces.append(f'<text x="{60+j*140}" y="315" font-family="sans-serif" font-size="13" fill="{colors[j]}">dimension {j}</text>')
    pieces.append(f'<text x="780" y="300" font-family="sans-serif" font-size="12">last sample {(len(actions)-1)/hz:.3f}s</text></svg>')
    out.write_text('\n'.join(pieces))


def main():
    p=argparse.ArgumentParser();p.add_argument('--demo',action='store_true');p.add_argument('--actions',type=Path)
    p.add_argument('--reference',type=Path);p.add_argument('--hz',type=float,default=30);p.add_argument('--prefix',type=Path,default=Path('chunk-analysis'));a=p.parse_args()
    if a.demo:
        t=np.arange(30)/30;actions=np.stack([.1*np.sin(t+j*.2) for j in range(16)],axis=1)
        actions[15,0]+=.2;np.save('synthetic-actions.npy',actions)
    elif a.actions is not None:actions=np.load(a.actions,allow_pickle=False)
    else:p.error('Choose --demo or --actions')
    report=analyze(actions,a.hz);report['demo']=a.demo
    if a.reference is not None:
        ref=np.load(a.reference,allow_pickle=False)
        if ref.shape!=actions.shape or not np.isfinite(ref).all():raise ValueError('Reference must be finite and identically aligned/shaped')
        report['per_dimension_rmse']=np.sqrt(np.mean((actions-ref)**2,axis=0)).tolist()
        report['comparison_note']='Assumes identical units, frames and alignment; open-loop diagnostic, not task success.'
    with Path(str(a.prefix)+'.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['elapsed_s']+[f'action_{i}' for i in range(actions.shape[1])])
        for i,row in enumerate(actions):w.writerow([i/a.hz,*row])
    Path(str(a.prefix)+'.json').write_text(json.dumps(report,indent=2));plot_svg(actions,a.hz,Path(str(a.prefix)+'.svg'))
    print(json.dumps(report,indent=2))
    if a.demo:
        assert report['max_adjacent_change'][0]>.19 and report['horizon_s']==1
        try:analyze(np.array([[np.nan]]),30)
        except ValueError:pass
        else:raise AssertionError('NaN accepted')
if __name__=='__main__':main()
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ag-go1-chunk-analysis'
)
