Plot and inspect a GO-1 action chunk

Turn a predicted action array into a time-indexed CSV, a standalone SVG plot and per-coordinate range/step-change metrics; optionally compare an aligned reference.

PLATFORM: AGIBOT G1 / GO-1

ENVIRONMENT: Offline

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Python 3.10+ and NumPy

An NPY action array shaped [time,action], such as output from the inference recipe

The control frequency and coordinate/normalization contract belonging to that array

CONFIGURATION

--hz = 30
Control rate from the observation/executor contract, not a value inferred from NPY dimensions.

--reference = aligned-reference.npy
Optional same-shape reference after independently verifying time alignment and units.

--prefix = saved-chunk
Common filename prefix for CSV, JSON and SVG outputs.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-go1-chunk-analysis. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-go1-chunk-analysis"
cd "$HOME/robot-academy/ag-go1-chunk-analysis"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install "numpy>=1.24,<3"
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-go1-chunk-analysis"
source .venv/bin/activate
python analyze_chunk.py --demo
# Inspect predictions from the previous recipe after they exist:
if [ -f "$HOME/robot-academy/ag-go1-inference-file/go1-actions.npy" ]; then
  python analyze_chunk.py --actions "$HOME/robot-academy/ag-go1-inference-file/go1-actions.npy" --hz 30 --prefix saved-chunk
fi
# Optional real prediction and aligned reference:
# python analyze_chunk.py --actions "$GO1_ACTIONS" --reference "$GO1_REFERENCE" --hz 30 --prefix compared-chunk
)

EXPECTED RESULT

Demo detects a deliberately inserted dimension-zero spike and rejects a nonfinite input test.

Outputs include one CSV row per predicted step, JSON metrics and an SVG plot of the first six dimensions.

A 30-step chunk at 30 Hz covers one second of commanded intervals; its final sample lies at 29/30 seconds.

Reference comparison is optional and explicitly labeled an open-loop diagnostic.

Read the time axis correctly

An action chunk contains successive target values, not an instantaneous pose. For N values issued at frequency f, the intended interval horizon is N/f while sample coordinates run from zero to (N−1)/f. The CSV and SVG preserve that distinction. The script reports the largest adjacent change per dimension and numerical range; it does not call those differences a physical speed until the output representation, units and normalization are established.



Use the plot to find a question worth investigating

The synthetic example adds a one-step spike to a smooth coordinate trace so the largest-change metric and visible kink agree. In real output, an abrupt change could reflect task dynamics, a bad normalization file, wrong camera role or a model failure. A reference RMSE is meaningful only for identical units, frame conventions and temporal alignment. Neither a smooth-looking curve nor low open-loop error proves that a grasp succeeds when feedback and contact change the next observation.



TROUBLESHOOTING

The SVG curves are nearly flat or dominated by one coordinate
Inspect per-dimension ranges and units. A single shared plotting scale is intentional; compare normalized values separately if justified by the checkpoint contract.

Reference shape rejected
Align data deliberately and document the transformation. Truncating or broadcasting an array solely to obtain a score hides a data-contract error.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-go1-evaluation

https://kamilszwed.com/courses/#/lesson/ag-go1-deployment-capstone

SOURCES

GO-1 base configuration
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/go1/configs/go1_base_cfg.py
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z

GO-1 inference implementation
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/evaluate/deploy.py
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z

GO-1 LIBERO evaluation
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/evaluate/libero/README.md
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z
