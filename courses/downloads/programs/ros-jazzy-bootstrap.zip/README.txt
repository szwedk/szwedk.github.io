Install Jazzy on the course Ubuntu VM and prove readiness

A complete guarded installer using the official ROS repository package, followed by a real talker/listener acceptance check. This is the starting recipe when ROS imports and commands are not installed yet.

PLATFORM: ROS 2

ENVIRONMENT: Offline

VALIDATION

Guards and release selection tested; installation pending

Bash syntax/ShellCheck checked. The platform guard was exercised on macOS and refused installation before sudo. Release selection validated current official metadata (1.3.0 on research date) and rejects unexpected asset paths. No system packages were installed by the author.

REQUIREMENTS

Ubuntu 24.04 amd64/arm64; ROS 2 Jazzy

A dedicated Ubuntu 24.04 amd64 or arm64 learning VM or workstation

Administrator permission inside that Ubuntu environment

A working UTF-8 locale and current Ubuntu package indexes

Open the linked ros-environment lesson and official installation source before running the installer

CONFIGURATION

Platform = Ubuntu 24.04
Installer checks ID and VERSION_ID from /etc/os-release before any elevated command.

Architecture = amd64 or arm64
Only the documented Ubuntu binary targets pass this recipe guard.

ROS distribution = jazzy
Fixed intentionally; changing the string is not a supported migration procedure.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ros-jazzy-bootstrap. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ros-jazzy-bootstrap"
  bash -n install_jazzy.sh
  python3 -m py_compile select_release.py
  bash install_jazzy.sh
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ros-jazzy-bootstrap"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 -c "import rclpy; from sensor_msgs.msg import Temperature; print('Jazzy Python imports ready')"
  ros2 doctor --report
  ros2 run demo_nodes_cpp talker
)

EXPECTED RESULT

The installer refuses macOS, a non-Ubuntu system, or an Ubuntu release other than 24.04 before making package changes.

The repository .deb and its exact release metadata remain in downloads/ for inspection.

The Run block starts the standard talker after checking Python imports and the environment.

In a second terminal, source Jazzy, set the same domain/discovery settings, then run ros2 run demo_nodes_py listener. Received strings are the local communication acceptance evidence.

What changes on the Ubuntu VM

This recipe uses sudo to install Ubuntu dependencies, enable Universe, install the official ros2-apt-source repository-configuration package, and install Jazzy desktop plus development tools. Read the package manager prompts. It does not install Humble into the same environment, upgrade the Ubuntu release, or modify a robot computer.



How repository setup is obtained

The installer retrieves release metadata from the official ros-infrastructure repository, selects the exact Noble package asset, saves it locally, and checks the expected HTTPS owner/path before downloading. It displays package information before dpkg installation. It never pipes downloaded text into a shell. The saved metadata records the version actually used; latest release selection means a later run may use a newer official package.



Finish with two terminals

Keep the talker from the Run block active. Open a second Ubuntu Bash terminal and paste this complete listener block. Seeing corresponding strings verifies this local exchange. Stop both with Ctrl-C. This test does not verify a robot SDK or physical control.

(
  set -e
  cd "$HOME/robot-academy/ros-jazzy-bootstrap"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  ros2 run demo_nodes_py listener
)

Keep the vendor environments separate

Use this environment for foundation recipes. A vendor course requiring Ubuntu 22.04/Humble needs a separate matching VM or machine. Do not source both distributions into one terminal or use a vendor robot onboard computer as a general package-installation experiment.



TROUBLESHOOTING

Installer says the locale is not UTF-8
Use the official installation page locale section to enable a supported UTF-8 locale, reopen the shell, and verify locale charmap. The installer deliberately does not silently change your system language.

Package dependencies cannot be resolved
Inspect the official Jazzy installation troubleshooting and Ubuntu source suites. On Ubuntu 24.04, noble-updates and noble-backports may be required for ros-dev-tools; do not mix another Ubuntu release into the sources.

Talker runs but listener is silent
Both terminals must source Jazzy and use the same ROS_DOMAIN_ID=42, default Fast DDS implementation, and localhost discovery setting. Copy the Run block environment lines into the listener terminal.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/linux-packages-python

https://kamilszwed.com/courses/#/lesson/ros-environment

SOURCES

ROS 2 Jazzy Ubuntu binary installation
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Installation/Ubuntu-Install-Debs.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

Ubuntu package management
https://documentation.ubuntu.com/server/how-to/software/package-management/
Primary documentation retrieved 2026-09-29

ROS apt-source repository configuration packages
https://github.com/ros-infrastructure/ros-apt-source
Current official release metadata
