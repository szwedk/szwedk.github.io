#!/usr/bin/env python3
"""Select the official Noble repository-package asset from saved GitHub metadata."""
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlparse


def select_release(document):
    tag = document.get("tag_name", "")
    if not isinstance(tag, str) or not re.fullmatch(r"[A-Za-z0-9._-]+", tag):
        raise ValueError("missing or unexpected release tag")
    wanted = f"ros2-apt-source_{tag}.noble_all.deb"
    matches = [asset.get("browser_download_url", "") for asset in document.get("assets", [])
               if asset.get("name") == wanted]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one asset named {wanted}; inspect the official installation page")
    parsed = urlparse(matches[0])
    expected_path = f"/ros-infrastructure/ros-apt-source/releases/download/{tag}/{wanted}"
    if parsed.scheme != "https" or parsed.netloc != "github.com" or parsed.path != expected_path or parsed.query:
        raise ValueError("asset URL does not match the expected official HTTPS release path")
    return matches[0]


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 select_release.py SAVED_RELEASE_JSON")
    print(select_release(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))))
