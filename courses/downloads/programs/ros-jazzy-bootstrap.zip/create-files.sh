# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ros-jazzy-bootstrap"
cd "$HOME/robot-academy/ros-jazzy-bootstrap"
cat > install_jazzy.sh <<'ACADEMY_FILE_0'
#!/usr/bin/env bash
# Run only on the Ubuntu 24.04 learning VM. Reads official release metadata;
# downloads a repository-configuration .deb for inspection before dpkg installs it.
set -euo pipefail
cd "$(dirname "$0")"
if [[ ${1:-} == --help ]]; then
  printf '%s\n' 'Usage: bash install_jazzy.sh' 'Installs ROS 2 Jazzy packages on Ubuntu 24.04 using the official ros-apt-source release.'
  exit 0
fi
if [[ $(uname -s) != Linux || ! -f /etc/os-release ]]; then
  printf '%s\n' 'This installer requires Ubuntu 24.04 Linux; run it inside the course VM.' >&2
  exit 2
fi
# shellcheck disable=SC1091
source /etc/os-release
if [[ ${ID:-} != ubuntu || ${VERSION_ID:-} != 24.04 ]]; then
  printf '%s\n' 'Refusing: this recipe is only for Ubuntu 24.04 / ROS 2 Jazzy.' >&2
  exit 2
fi
case "$(dpkg --print-architecture)" in
  amd64|arm64) ;;
  *) printf '%s\n' 'This recipe supports the official Ubuntu amd64/arm64 binary targets.' >&2; exit 2 ;;
esac
if [[ $(locale charmap) != UTF-8 ]]; then
  printf '%s\n' 'A UTF-8 locale is required. Follow the linked official locale setup, reopen the terminal, and rerun.' >&2
  exit 2
fi
sudo apt-get update
sudo apt-get install software-properties-common curl python3
sudo add-apt-repository -y universe
mkdir -p downloads
curl --fail --show-error --location --retry 2 \
  https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest \
  --output downloads/ros-apt-source-release.json
python3 select_release.py downloads/ros-apt-source-release.json > downloads/package-url.txt
IFS= read -r package_url < downloads/package-url.txt
printf 'Official repository package: %s\n' "$package_url"
curl --fail --show-error --location --retry 2 "$package_url" --output downloads/ros2-apt-source.deb
dpkg-deb --info downloads/ros2-apt-source.deb
sudo dpkg -i downloads/ros2-apt-source.deb
sudo apt-get update
sudo apt-get install ros-jazzy-desktop ros-dev-tools
printf '%s\n' 'Installation commands completed. Run the separate talker/listener check; this message alone is not readiness evidence.'
ACADEMY_FILE_0
cat > select_release.py <<'ACADEMY_FILE_1'
#!/usr/bin/env python3
"""Select the official Noble repository-package asset from saved GitHub metadata."""
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlparse


def select_release(document):
    tag = document.get("tag_name", "")
    if not isinstance(tag, str) or not re.fullmatch(r"[A-Za-z0-9._-]+", tag):
        raise ValueError("missing or unexpected release tag")
    wanted = f"ros2-apt-source_{tag}.noble_all.deb"
    matches = [asset.get("browser_download_url", "") for asset in document.get("assets", [])
               if asset.get("name") == wanted]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one asset named {wanted}; inspect the official installation page")
    parsed = urlparse(matches[0])
    expected_path = f"/ros-infrastructure/ros-apt-source/releases/download/{tag}/{wanted}"
    if parsed.scheme != "https" or parsed.netloc != "github.com" or parsed.path != expected_path or parsed.query:
        raise ValueError("asset URL does not match the expected official HTTPS release path")
    return matches[0]


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 select_release.py SAVED_RELEASE_JSON")
    print(select_release(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))))
ACADEMY_FILE_1
printf '%s\n' 'Created 2 file(s) in ~/robot-academy/ros-jazzy-bootstrap'
)
