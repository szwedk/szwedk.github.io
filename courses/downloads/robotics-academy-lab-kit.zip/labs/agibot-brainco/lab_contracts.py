#!/usr/bin/env python3
"""Offline teaching validators. No SDK imports, network access or motor commands.

Run: python3 lab_contracts.py
The policies below are course exercise choices, not vendor safety limits.
"""
import json
import math
from dataclasses import dataclass

ARM_NAMES = tuple(f'{side}_{joint}_joint' for side in ('left', 'right') for joint in
    ('shoulder_pitch', 'shoulder_roll', 'shoulder_yaw', 'elbow', 'wrist_yaw', 'wrist_pitch', 'wrist_roll'))
VARIANTS = {
    'X2 Ultra': {'body_dof': 30, 'neck_dof': 1, 'urdf_family': '1.3.0'},
    'X2 Ultra -N': {'body_dof': 31, 'neck_dof': 2, 'urdf_family': '1.4.0'},
    'X2 EDU': {'body_dof': 29, 'neck_dof': 0, 'urdf_family': '1.4.0'},
}
HAND_LENGTHS = {1: 2, 2: 20, 3: 4}


def serialize_named_arm(values):
    """Validate a teaching record; output MUST NOT be sent to hardware."""
    if set(values) != set(ARM_NAMES):
        raise ValueError('joint_names_mismatch')
    if any(not isinstance(x, (int, float)) or isinstance(x, bool) or not math.isfinite(x)
           for x in values.values()):
        raise ValueError('nonfinite_or_non_numeric_joint')
    return [values[name] for name in ARM_NAMES]


def validate_x2_record(record):
    """Structural validation only; does not enforce physical joint constraints."""
    model = VARIANTS.get(record.get('model'))
    if model is None:
        raise ValueError('unknown_model')
    if record['urdf_family'] != model['urdf_family']:
        raise ValueError('model_family_mismatch')
    if record.get('head_control', False) and not model['neck_dof']:
        raise ValueError('head_not_supported')
    submode = record['hand_sub_mode']
    if submode not in HAND_LENGTHS or len(record['hand_pos']) != HAND_LENGTHS[submode]:
        raise ValueError('hand_submode_length_mismatch')
    if any(not math.isfinite(x) for x in record['hand_pos']):
        raise ValueError('nonfinite_hand_target')
    return serialize_named_arm(record['arm'])


@dataclass
class Observation:
    quaternion_wxyz: tuple
    body_velocity: tuple
    receive_time: float
    valid: bool = True


def audit_observation(obs, now, max_host_age):
    """max_host_age is an exercise policy, not a D1 specification.
    Host receive age does not establish hardware acquisition age.
    This synthetic fixture defines its quaternion as the body-to-world rotation;
    determine the real SDK convention separately before adapting this function.
    """
    if not obs.valid:
        raise ValueError('invalid_source_observation')
    if len(obs.quaternion_wxyz) != 4 or len(obs.body_velocity) != 3:
        raise ValueError('wrong_vector_length')
    if not all(math.isfinite(x) for x in (*obs.quaternion_wxyz, *obs.body_velocity, obs.receive_time, now)):
        raise ValueError('nonfinite_observation')
    age = now - obs.receive_time
    if age < 0 or age > max_host_age:
        raise ValueError('invalid_or_stale_host_time')
    norm = math.sqrt(sum(x*x for x in obs.quaternion_wxyz))
    if abs(norm - 1.0) > 1e-6:
        raise ValueError('non_unit_quaternion')
    w, x, y, z = obs.quaternion_wxyz
    bx, by, bz = obs.body_velocity
    world = (
        (1-2*(y*y+z*z))*bx + 2*(x*y-z*w)*by + 2*(x*z+y*w)*bz,
        2*(x*y+z*w)*bx + (1-2*(x*x+z*z))*by + 2*(y*z-x*w)*bz,
        2*(x*z-y*w)*bx + 2*(y*z+x*w)*by + (1-2*(x*x+y*y))*bz,
    )
    return {'world_velocity': world, 'host_age_seconds': age, 'sensor_age_known': False}


def main():
    results = []
    def expect(name, fn, error=None):
        try:
            result = fn()
        except ValueError as exc:
            assert str(exc) == error, (name, str(exc), error)
            results.append({'case': name, 'passed': True, 'rejected': str(exc)})
        else:
            assert error is None, (name, 'expected rejection', error)
            results.append({'case': name, 'passed': True, 'result': result})
    fixture = {'model': 'X2 Ultra -N', 'urdf_family': '1.4.0', 'head_control': True,
               'hand_sub_mode': 1, 'hand_pos': [0.0, 0.0],
               'arm': {name: i/100 for i, name in enumerate(ARM_NAMES)}}
    expect('asymmetric_arm_order', lambda: validate_x2_record(fixture))
    expected = list(range(14))
    assert [round(v*100) for v in validate_x2_record(fixture)] == expected
    expect('edu_head_rejected', lambda: validate_x2_record({**fixture, 'model': 'X2 EDU'}), 'head_not_supported')
    expect('wrong_model_family', lambda: validate_x2_record({**fixture, 'urdf_family': '1.3.0'}), 'model_family_mismatch')
    expect('wrong_hand_length', lambda: validate_x2_record({**fixture, 'hand_sub_mode': 2}), 'hand_submode_length_mismatch')
    expect('nan_joint', lambda: serialize_named_arm({**fixture['arm'], ARM_NAMES[0]: float('nan')}), 'nonfinite_or_non_numeric_joint')
    quarter_turn = Observation((math.sqrt(.5), 0, 0, math.sqrt(.5)), (1, 0, 0), 10.0)
    output = audit_observation(quarter_turn, 10.01, .1)
    assert abs(output['world_velocity'][0]) < 1e-9
    assert abs(output['world_velocity'][1] - 1) < 1e-9
    expect('body_forward_rotates_world_left', lambda: output)
    expect('stale_state', lambda: audit_observation(quarter_turn, 10.2, .1), 'invalid_or_stale_host_time')
    expect('zero_quaternion', lambda: audit_observation(Observation((0,0,0,0), (0,0,0),10),10,.1), 'non_unit_quaternion')
    print(json.dumps({'fixture': 'synthetic', 'hardware_tested': False, 'tests': results}, indent=2))

if __name__ == '__main__':
    main()
