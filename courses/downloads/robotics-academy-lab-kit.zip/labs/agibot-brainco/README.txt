AGIBOT + BRAINCO OFFLINE LAB KIT
Original instructional code. Python 3.10+; standard library only.
No SDK imports, robot networking, serial access, motor control, licensed data or model weights.

Run each exercise from this directory:
  python3 lab_contracts.py
  python3 lab_tactile.py
  python3 lab_dataset.py

Each program uses synthetic fixtures, checks explicit acceptance conditions,
and prints a JSON evidence report. Assertion failures mean an exercise failed.
These passes validate the instructional algorithms only. They do not establish
physical robot readiness, measured hand performance or GO-1 policy accuracy.

LESSON MAPPING
lab_contracts.py: X2 identity/array contract; D1 quaternion/frame/freshness audit.
lab_tactile.py: Revo tactile contact processing with hysteresis and persistence.
lab_dataset.py: GO-1 episode integrity, duplicate leakage and normalization.

EXTEND THE EXERCISES
1. Contracts: add a swapped left/right fixture and prove your semantic mapping
   detects it. Structural validation alone cannot detect values that lie about
   their names. Do not claim the included validator proves physical limits.
2. Tactile: add drift and saturation; measure false-contact duration and delayed
   release. All thresholds are synthetic teaching values, not BrainCo limits.
3. Dataset: add missing cameras and task-disjoint splits. Show why a clean
   episode split alone does not establish unseen-task generalization.

SOURCE BOUNDARIES
Official X2 model/API facts: https://x2-aimdk.agibot.com/en/latest/
Official D1 SDK: https://github.com/AgibotTech/agibot_D1_Edu-Ultra
Official BrainCo SDK: https://github.com/BrainCoTech/brainco-hand-sdk
Official GO-1 code: https://github.com/OpenDriveLab/AgiBot-World
The LMS source register records exact versions. The algorithms and synthetic
fixtures in this kit are instructional implementations, not vendor SDK code.
