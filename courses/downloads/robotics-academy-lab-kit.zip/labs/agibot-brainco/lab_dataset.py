#!/usr/bin/env python3
"""Synthetic episode audit and normalization exercise. No licensed data included.
Run: python3 lab_dataset.py
"""
import json
import math
import hashlib


def audit_episode(ep):
    errors = []
    times = ep['time_s']
    if not times or any(not math.isfinite(t) for t in times):
        errors.append('invalid_time')
    if any(b <= a for a,b in zip(times,times[1:])):
        errors.append('nonmonotonic_time')
    for key in ('state','action'):
        if len(ep[key]) != len(times):
            errors.append(key+'_length_mismatch')
        if any(len(row)!=2 or any(not math.isfinite(x) for x in row) for row in ep[key]):
            errors.append(key+'_invalid_values')
    # Hash the source-like observations, not metadata or episode name.
    fingerprint = hashlib.sha256(json.dumps({k: ep[k] for k in ('time_s','state','action')},sort_keys=True).encode()).hexdigest()
    return errors, fingerprint


def normalize(vector, mean, std):
    if len(vector)!=len(mean) or len(mean)!=len(std):
        raise ValueError('statistics_dimension_mismatch')
    if any(not math.isfinite(x) for x in (*vector,*mean,*std)) or any(x<=0 for x in std):
        raise ValueError('invalid_statistics_or_values')
    return [(x-m)/(s+1e-6) for x,m,s in zip(vector,mean,std)]


def main():
    a={'id':'train-a','time_s':[0,.1,.2],'state':[[1,10],[2,20],[3,30]],'action':[[2,11],[3,21],[4,31]]}
    b={'id':'validation-b','time_s':[0,.1,.2],'state':[[4,40],[5,50],[6,60]],'action':[[5,41],[6,51],[7,61]]}
    bad={**a,'id':'bad-time','time_s':[0,.2,.1]}
    duplicate={**a,'id':'renamed-copy'}
    cases=[];seen={};accepted=[]
    for ep in (a,b,bad,duplicate):
        errors,fingerprint=audit_episode(ep)
        if fingerprint in seen:
            errors.append('duplicate_of:'+seen[fingerprint])
        if not errors:
            seen[fingerprint]=ep['id'];accepted.append(ep['id'])
        cases.append({'episode':ep['id'],'accepted':not errors,'reasons':errors})
    assert accepted==['train-a','validation-b']
    assert 'nonmonotonic_time' in cases[2]['reasons']
    assert cases[3]['reasons']==['duplicate_of:train-a']
    train={'train-a'};validation={'validation-b'}
    assert not train.intersection(validation)
    values=[2.,40.];mean=[1.,10.];std=[2.,5.]
    encoded=normalize(values,mean,std)
    decoded=[z*(s+1e-6)+m for z,s,m in zip(encoded,std,mean)]
    assert all(abs(a-b)<1e-10 for a,b in zip(values,decoded))
    try: normalize(values,[1.],[2.])
    except ValueError as e: assert str(e)=='statistics_dimension_mismatch'
    else: raise AssertionError('wrong-sized statistics accepted')
    # This exact inverse is an exercise. The pinned vendor implementation uses
    # its own normalization/unnormalization equations: reproduce them when integrating.
    print(json.dumps({'fixture':'synthetic','hardware_tested':False,'episodes':cases,
        'split':{'train':sorted(train),'validation':sorted(validation)},
        'normalization_roundtrip':decoded,'chunk_horizons_s':{'30_at_30hz':1,'30_at_10hz':3}},indent=2))

if __name__=='__main__':main()
