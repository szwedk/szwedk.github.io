#!/usr/bin/env python3
"""Synthetic contact-detection exercise. Not a hand-control program.
Run: python3 lab_tactile.py
Threshold units and all limits are arbitrary exercise values, not BrainCo limits.
"""
import json
from dataclasses import dataclass

@dataclass
class Detector:
    enter: float = .7
    leave: float = .3
    persistence_seconds: float = .05
    contact: bool = False
    candidate_since: float | None = None
    last_time: float | None = None

    def update(self, time, signal, *, valid=True):
        if self.last_time is not None and time <= self.last_time:
            raise ValueError('timestamps_must_increase')
        self.last_time = time
        if not valid or signal is None or not (0 <= signal <= 1):
            self.candidate_since = None
            self.contact = False
            return 'fault'
        threshold_crossed = signal <= self.leave if self.contact else signal >= self.enter
        if not threshold_crossed:
            self.candidate_since = None
        elif self.candidate_since is None:
            self.candidate_since = time
        elif time - self.candidate_since >= self.persistence_seconds - 1e-10:
            self.contact = not self.contact
            self.candidate_since = None
        return 'contact' if self.contact else 'free'


def run_trace(hz, scenario):
    d = Detector()
    rows = []
    for i in range(hz * 2):
        t = i/hz
        truth = .5 <= t < 1.2
        value = .9 if truth else .1
        valid = True
        if scenario == 'noise_spike' and .2 <= t < .22:
            value = .95
        if scenario == 'dropout' and .8 <= t < .9:
            valid = False
        state = d.update(t, value, valid=valid)
        rows.append({'t': t, 'truth': truth, 'signal': value, 'state': state})
    contact_at = next((r['t'] for r in rows if r['state']=='contact'), None)
    free_after = next((r['t'] for r in rows if r['t']>=1.2 and r['state']=='free'), None)
    false_contact = sum(1/hz for r in rows if not r['truth'] and r['state']=='contact')
    # A finite release lag is expected; count it rather than hiding it.
    assert contact_at is not None and .05-1e-9 <= contact_at-.5 <= .05+2/hz
    assert free_after is not None and .05-1e-9 <= free_after-1.2 <= .05+2/hz
    if scenario == 'noise_spike':
        assert not any(r['state']=='contact' for r in rows if r['t']<.5)
    if scenario == 'dropout':
        assert all(r['state']=='fault' for r in rows if .8<=r['t']<.9)
    return {'hz': hz, 'scenario': scenario, 'contact_delay_s': round(contact_at-.5,4),
            'release_delay_s': round(free_after-1.2,4), 'false_contact_time_s': round(false_contact,4),
            'fault_samples': sum(r['state']=='fault' for r in rows)}

if __name__ == '__main__':
    results = [run_trace(hz,s) for hz in (100,200) for s in ('clean','noise_spike','dropout')]
    print(json.dumps({'fixture':'synthetic','hardware_tested':False,'results':results},indent=2))
