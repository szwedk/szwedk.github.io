ROBOTICS ACADEMY | KAMIL SZWED
Release: 2026-09-29.1
Online: https://kamilszwed.com/courses/

This kit contains original lesson sheets, evidence templates, primary source
references, and dependency-free offline exercises. No robot is controlled by
the included Python lab scripts. No vendor datasets or model weights are included.

START HERE
1. Read the first ROS workstation lesson in lesson-sheets/.
2. Use the lesson prerequisites to prepare the exact required environment.
3. For standalone AGIBOT/BrainCo exercises, read labs/agibot-brainco/README.md.
4. Keep observations with the evidence template. Submit results in the online LMS.
5. Review quiz feedback and sources before progressing to dependent lessons.

WHAT WAS TESTED
Standalone Python examples and numerical lab scripts were executed locally.
The standalone C++ fundamentals example was compiled and run.
ROS-dependent Python examples received syntax validation only.
Shell snippets received syntax or source inspection, not robot execution.
The full ROS/Gazebo/vendor SDK/hardware environments were not available on
this macOS authoring host. No real robot performance or hardware qualification
is claimed. Always follow the exact vendor prerequisites for hardware work.

COMPLETION STANDARD
Acknowledged reading + at least 80% knowledge check + submitted evidence with
all acceptance self-checks. Instructor review is separate. This is independent
education, not vendor certification or permission to operate hardware.

SOURCE POLICY
Sources were reviewed on September 29, 2026. Each record states its version or
commit where available. Reverify before firmware, SDK, or hardware changes.
Official sources retain their respective licenses. This kit includes original
instruction and original illustrative code, not vendor repository copies.
