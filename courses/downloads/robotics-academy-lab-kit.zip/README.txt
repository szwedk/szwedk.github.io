ROBOTICS ACADEMY | KAMIL SZWED
Release: 2026-09-29.2
Online: https://kamilszwed.com/courses/

This kit contains original lesson sheets, evidence templates, primary source
references, offline exercises, and original platform-specific programs.
Hardware programs require the documented SDK, configuration, and prerequisites.
Read each program's README and validation status before running it.
No vendor datasets or model weights are included.

START HERE
1. Start with Linux from zero in lesson-sheets/linux-from-zero/.
2. Use the lesson prerequisites to prepare the exact required environment.
3. For standalone AGIBOT/BrainCo exercises, read labs/agibot-brainco/README.md.
4. Keep observations with the evidence template. Submit results in the online LMS.
5. Review quiz feedback and sources before progressing to dependent lessons.
6. For complete programs, open programs/<program-id>/README.txt. Review the
   file-creation script, then use its setup and run commands on your Linux PC.

WHAT WAS TESTED
Standalone Python examples and numerical lab scripts were executed locally.
The standalone C++ fundamentals example was compiled and run.
ROS-dependent Python examples received syntax validation only.
Shell snippets received syntax or source inspection, not robot execution.
The full ROS/Gazebo/vendor SDK/hardware environments were not available on
this macOS authoring host. No real robot performance or hardware qualification
is claimed. Always follow the exact vendor prerequisites for hardware work.

COMPLETION STANDARD
Acknowledged reading + at least 80% knowledge check + submitted evidence with
all acceptance self-checks. Instructor review is separate. This is independent
education, not vendor certification or permission to operate hardware.

SOURCE POLICY
Sources were reviewed on September 29, 2026. Each record states its version or
commit where available. Reverify before firmware, SDK, or hardware changes.
Official sources retain their respective licenses. This kit includes original
instruction and original illustrative code, not vendor repository copies.
