Save one compressed X2 camera frame

Capture one head RGB frame without decoding or recompressing it, identify PNG/JPEG from its bytes, and save camera timestamp and format metadata.

PLATFORM: AGIBOT X2

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Device: Ubuntu 22.04 / ROS 2 Humble / sensor_msgs

An X2 configuration exposing the documented front-head RGBD compressed image topic

CONFIGURATION

--topic = /aima/hal/sensor/rgbd_head_front/rgb_image/compressed
Documented front-head compressed RGB topic.

--timeout = 10
Maximum seconds to wait for a frame, no more than 60.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-x2-camera-snapshot. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-x2-camera-snapshot"
cd "$HOME/robot-academy/ag-x2-camera-snapshot"
python3 --version
python3 -m py_compile camera_snapshot.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-x2-camera-snapshot"
python3 camera_snapshot.py --mock

# Optional: set X2_READ_DEVICE=1 before copying this block.
# Requires an already configured, matching Humble/AimDK host.
if [ "${X2_READ_DEVICE:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
AIMDK_WS="${AIMDK_WS:-$HOME/aimdk}"
source "$AIMDK_WS/install/local_setup.bash"
python3 camera_snapshot.py --timeout 10 --prefix x2-camera-device
fi
)

EXPECTED RESULT

Offline creates a tiny synthetic PNG plus JSON metadata.

Device path saves exactly one supported compressed frame, then destroys the subscriber.

The JSON records topic, frame_id, ROS stamp, format string and byte count.

Why compressed transport is selected

The X2 sensor documentation describes the raw head stream as a substantial data flow intended for the same computing unit. A one-frame compressed subscription is a smaller diagnostic workload for a development host. The program writes the received bytes directly, preserving the vendor encoder output rather than silently changing color ordering or compression quality. Byte signatures choose the file extension; an unsupported encoding fails instead of producing a misleading .jpg file.



What the snapshot establishes

A decodable frame proves that this subscriber received an image payload at that moment. It does not establish intrinsic calibration, depth alignment or synchronization with the wrists. Those need their own calibration records and paired timestamps. The synthetic fixture verifies only file handling and metadata generation. Its dimensions and appearance deliberately differ from a robot photograph.



TROUBLESHOOTING

Timeout
Confirm the robot variant provides this camera, its publisher is active, and ROS networking is configured. Do not replace the topic with a high-bandwidth raw stream just to hide discovery problems.

Unknown compressed-image signature
Inspect message.format and the first payload bytes. This recipe supports PNG/JPEG rather than guessing an extension for another codec.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-x2-sensor-contract

SOURCES

X2 sensor interfaces
https://x2-aimdk.agibot.com/en/latest/Interface/hal/sensor.html
AimDK_X2 1.1.0; live docs 2026-09-29

X2 coordinate systems and factory calibration
https://x2-aimdk.agibot.com/en/latest/about_agibot_X2/coordinate_system.html
AimDK_X2 1.1.0; live docs 2026-09-29
