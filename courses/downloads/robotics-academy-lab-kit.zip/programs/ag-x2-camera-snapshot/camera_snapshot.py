#!/usr/bin/env python3
"""Save one compressed X2 camera frame and metadata; never subscribes raw 80MB/s image."""
import argparse
import json
from pathlib import Path
import time

def save_frame(data,fmt,stamp,frame,prefix,mock=False):
    # Decide by bytes, not an untrusted filename or format string.
    if data.startswith(b'\xff\xd8\xff'):extension='.jpg'
    elif data.startswith(b'\x89PNG\r\n\x1a\n'):extension='.png'
    else:raise ValueError('Expected JPEG or PNG compressed bytes, got '+fmt)
    path=Path(str(prefix)+extension);path.write_bytes(data)
    metadata={'mock':mock,'file':str(path),'bytes':len(data),'format':fmt,'frame_id':frame,
              'header_stamp_s':stamp,'received_unix_s':time.time(),
              'scope':'One RGB image; no depth registration or metric localization is implied.'}
    Path(str(prefix)+'.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps(metadata));return metadata

def main():
    p=argparse.ArgumentParser();p.add_argument('--mock',action='store_true')
    p.add_argument('--topic',default='/aima/hal/sensor/rgbd_head_front/rgb_image/compressed')
    p.add_argument('--prefix',default='x2-camera');p.add_argument('--timeout',type=float,default=10)
    a=p.parse_args()
    if not 0<a.timeout<=60:p.error('--timeout must be in (0,60]')
    if a.mock:
        import base64
        # Original synthetic single transparent pixel fixture; no camera data.
        data=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=')
        out=save_frame(data,'png',0,'synthetic',a.prefix,True)
        assert Path(out['file']).read_bytes()==data
        return
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy
    from sensor_msgs.msg import CompressedImage
    rclpy.init();node=Node('course_x2_camera_snapshot');frames=[]
    qos=QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE)
    def receive(msg):
        if not frames:frames.append(msg)
    node.create_subscription(CompressedImage,a.topic,receive,qos)
    end=time.monotonic()+a.timeout
    try:
        while rclpy.ok() and not frames and time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.1)
        if not frames:raise TimeoutError('No compressed frame; EDU lacks the Ultra camera package')
        m=frames[0];save_frame(bytes(m.data),m.format,m.header.stamp.sec+m.header.stamp.nanosec/1e9,m.header.frame_id,a.prefix)
    finally:node.destroy_node();rclpy.try_shutdown()
if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:raise SystemExit(130)
