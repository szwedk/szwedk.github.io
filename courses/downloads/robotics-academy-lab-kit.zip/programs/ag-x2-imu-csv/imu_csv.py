#!/usr/bin/env python3
"""Bounded read-only IMU recorder. Robot header time is not sensor sample time."""
import argparse
import csv
import json
import math
from pathlib import Path
import statistics
import time

FIELDS=['receive_monotonic_s','header_stamp_s','frame_id','qx','qy','qz','qw','gx','gy','gz','ax','ay','az']

class Recorder:
    def __init__(self, path):
        self.file=Path(path).open('w',newline='')
        self.csv=csv.DictWriter(self.file,fieldnames=FIELDS);self.csv.writeheader()
        self.times=[];self.invalid=0
    def add(self, row):
        if any(not math.isfinite(row[k]) for k in FIELDS if k!='frame_id'):
            self.invalid+=1;return
        self.csv.writerow(row);self.times.append(row['receive_monotonic_s'])
    def close(self, path, mock, topic):
        self.file.close()
        gaps=[b-a for a,b in zip(self.times,self.times[1:])]
        out={'mock':mock,'topic':topic,'samples':len(self.times),'invalid':self.invalid,
             'mean_arrival_gap_ms':statistics.mean(gaps)*1000 if gaps else None,
             'max_arrival_gap_ms':max(gaps)*1000 if gaps else None,
             'header_time_semantics':'Chest/torso stamp is robot receive time, not IMU sample time. Covariances are unspecified/zero in current docs.'}
        Path(path).write_text(json.dumps(out,indent=2));print(json.dumps(out))
        return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--mock',action='store_true')
    p.add_argument('--topic',default='/aima/hal/imu/chest/state');p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--output',default='x2-imu.csv');a=p.parse_args()
    if not 0<a.seconds<=300:p.error('--seconds must be in (0,300]')
    rec=Recorder(a.output)
    if a.mock:
        for i in range(20):
            row=dict(zip(FIELDS,[i*.002,100+i*.002,'base_link',0,0,0,1,0,0,0,0,0,9.81]));rec.add(row)
        report=rec.close(a.output+'.json',True,a.topic)
        assert report['samples']==20 and abs(report['mean_arrival_gap_ms']-2)<1e-8
        return
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy
    from sensor_msgs.msg import Imu
    rclpy.init();node=Node('course_x2_imu_csv')
    # A volatile, best-effort reader is compatible with the documented best-effort
    # transient-local chest publisher; it intentionally requests fresh arrivals only.
    qos=QoSProfile(depth=100,reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE)
    def receive(m):
        q,g,v=m.orientation,m.angular_velocity,m.linear_acceleration
        rec.add(dict(zip(FIELDS,[time.monotonic(),m.header.stamp.sec+m.header.stamp.nanosec/1e9,
              m.header.frame_id,q.x,q.y,q.z,q.w,g.x,g.y,g.z,v.x,v.y,v.z])))
    node.create_subscription(Imu,a.topic,receive,qos)
    deadline=time.monotonic()+a.seconds
    try:
        while rclpy.ok() and time.monotonic()<deadline:rclpy.spin_once(node,timeout_sec=min(.1,max(0,deadline-time.monotonic())))
    except KeyboardInterrupt:pass
    finally:
        node.destroy_node();rclpy.try_shutdown();report=rec.close(a.output+'.json',False,a.topic)
    if not report['samples']:raise SystemExit('No IMU samples: inspect topic type, QoS, network and SDK state')
if __name__=='__main__':main()
