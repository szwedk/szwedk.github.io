Record X2 IMU samples and arrival gaps

Subscribe to the chest or torso IMU, write quaternion/gyro/acceleration CSV rows, and report dropped-invalid samples and host arrival timing.

PLATFORM: AGIBOT X2

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Device: Ubuntu 22.04 / Humble / sensor_msgs with matching X2 environment

The selected IMU topic must be exposed by this robot variant

CONFIGURATION

--topic = /aima/hal/imu/torso/state
Select chest or torso explicitly; both documented messages may use base_link, so preserve the topic in metadata.

--seconds = 10
Capture duration, greater than zero and no more than 300 seconds.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-x2-imu-csv. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-x2-imu-csv"
cd "$HOME/robot-academy/ag-x2-imu-csv"
python3 --version
python3 -m py_compile imu_csv.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-x2-imu-csv"
python3 imu_csv.py --mock

# Optional: set X2_READ_DEVICE=1 before copying this block.
# Requires an already configured, matching Humble/AimDK host.
if [ "${X2_READ_DEVICE:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
AIMDK_WS="${AIMDK_WS:-$HOME/aimdk}"
source "$AIMDK_WS/install/local_setup.bash"
python3 imu_csv.py --seconds 10 --topic /aima/hal/imu/chest/state --output x2-imu-device.csv
fi
)

EXPECTED RESULT

Offline writes 20 synthetic rows and timing metadata.

A device run stops after 10 seconds, saves x2-imu-device.csv and its JSON summary, and errors if no samples arrive.

Quaternion column order is x,y,z,w; gyro is rad/s and acceleration is m/s².

Two different clocks

The CSV contains host monotonic reception time and the ROS header timestamp. Their roles differ: monotonic host time measures interarrival gaps without wall-clock corrections, while the X2 documentation describes the header as the time the robot receives the data. Neither establishes the physical sensor sampling instant. Summarizing host gaps can reveal stalls or burst delivery, but it does not measure end-to-end latency without clock synchronization and a sampling-time reference.



QoS and invalid samples

The subscription requests best-effort, volatile delivery with a finite queue. This can connect to the documented best-effort, transient-local IMU publisher without requesting a historical backlog. Each numeric sensor field must be finite before the row is written. The report counts rejected rows. Zero covariance entries from the vendor are not interpreted as perfect certainty; retain that limitation when using the file in an estimator.



TROUBLESHOOTING

Zero rows despite visible topic
Use ros2 topic info -v on the exact topic; verify the producer is present and QoS matches. A listed topic alone does not prove messages are arriving.

Arrival rate is below the documented 500 Hz
Inspect host load, DDS/network loss and queue behavior. The rate is observed at this client and should not be relabeled as the IMU hardware rate.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-x2-sensor-contract

SOURCES

AimDK environment prerequisites
https://x2-aimdk.agibot.com/en/latest/quick_start/prerequisites.html
AimDK_X2 1.1.0; live docs 2026-09-29

X2 sensor interfaces
https://x2-aimdk.agibot.com/en/latest/Interface/hal/sensor.html
AimDK_X2 1.1.0; live docs 2026-09-29
