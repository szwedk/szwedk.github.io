Run GO-1 on an observation and save its action chunk

Exercise observation validation with deterministic synthetic output, or call the real pinned GO1Infer implementation with a local checkpoint and save predictions to an NPY file.

PLATFORM: AGIBOT G1 / GO-1

ENVIRONMENT: Offline

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Demo: Python 3.10+ and NumPy

Real model: separate Python 3.10 environment, NVIDIA GPU and compatible PyTorch/CUDA stack; official setup tested CUDA 12.4

Local checkpoint acquired under its published terms; matching statistics if checkpoint norm=true

An observation NPZ with top/right/left uint8 RGB images, state vector and one-element ctrl_freqs

CONFIGURATION

GO1_CHECKPOINT = Absolute path to a local checkpoint directory
Must contain the checkpoint config, weights and tokenizer files required by the official loader.

GO1_OBSERVATION = Absolute path to an observation.npz
Use the supplied synthetic-observation.npz as a shape example, never as a meaningful robot scene.

GO1_STATISTICS = Absolute path to matching statistics JSON
Required when norm=true; must belong to this checkpoint and embodiment.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-go1-inference-file. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-go1-inference-file"
cd "$HOME/robot-academy/ag-go1-inference-file"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install "numpy>=1.24,<3"
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-go1-inference-file"
source .venv/bin/activate
python infer_to_file.py --demo

# Optional, separate GPU model environment; does not download weights/data:
# bash prepare_model.sh
# Then run one actual prediction using explicit local input/checkpoint paths:
# source .venv-go1/bin/activate
# python infer_to_file.py --repo "$PWD/AgiBot-World" --checkpoint "$GO1_CHECKPOINT" --input "$GO1_OBSERVATION" --instruction 'place the object in the container' --output predicted-actions.npy
# Add --statistics "$GO1_STATISTICS" if the checkpoint config has norm=true.
)

EXPECTED RESULT

Demo creates an original observation NPZ and a clearly labeled synthetic [30,16] action array.

Real inference reads the local checkpoint dimensions/chunk size, validates all three camera arrays and invokes GO1Infer.inference(payload).

Finite shape-correct predictions are saved with metadata; no robot SDK is imported and no command is sent.

The complete input boundary

GO1Infer consumes top, right and left RGB arrays, a state vector, a one-element control-frequency array and instruction text. This wrapper checks dtypes and shapes before loading the large model. It reads state_dim/action_dim from action_config and action_chunk_size from the actual local config, rather than assuming every fine-tuned checkpoint uses sixteen coordinates. Those dimensional checks do not establish semantic agreement: camera viewpoints, coordinate order, physical units and normalization statistics must still match training.



A prediction remains a file

The real call uses evaluate.deploy.GO1Infer from the pinned official repository. If normalization is enabled, the matching statistics file is required. The result must have exactly the checkpoint’s chunk shape and contain finite values before it is saved. Metadata records the frequency and implied horizon, plus elapsed time including model loading; it is not a pure GPU inference benchmark. The deterministic demo tests plumbing only. This recipe intentionally ends at an NPY artifact because a hardware executor requires a separately verified embodiment mapping and control contract.



TROUBLESHOOTING

State or action dimension mismatch
Inspect the checkpoint config and your embodiment mapping. Do not pad a robot state with arbitrary zeros solely to satisfy the shape check.

CUDA, Flash Attention or model installation error
Use the separate Python 3.10 environment and match the vendor’s tested CUDA/PyTorch requirements. The included preparation script records installed versions; GPU execution was not validated in this course build.

Predictions exist but the robot does not move
That is expected: this program writes a file only. Use the chunk-analysis recipe next; hardware execution is a separate supervised integration task.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-go1-observation-contract

https://kamilszwed.com/courses/#/lesson/ag-go1-evaluation

https://kamilszwed.com/courses/#/lesson/ag-go1-deployment-capstone

SOURCES

AgiBot World and GO-1
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/README.md
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z

GO-1 inference implementation
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/evaluate/deploy.py
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z

GO-1 model card
https://huggingface.co/agibot-world/GO-1
Current model card; accessed 2026-09-29

GO-1 checkpoint configuration
https://huggingface.co/agibot-world/GO-1/blob/main/config.json
Reviewed 2026-09-29; model repository main is mutable
