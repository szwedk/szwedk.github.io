# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ag-go1-inference-file"
cd "$HOME/robot-academy/ag-go1-inference-file"
cat > infer_to_file.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""GO-1 inference to an output file only. No robot SDK, sockets or command publisher."""
import argparse
import json
from pathlib import Path
import sys
import time
import numpy as np


def make_fixture(path,dim=16):
    y,x=np.indices((48,64));image=np.stack([x*4,y*5,(x+y)*2],axis=-1).astype(np.uint8)
    np.savez_compressed(path,top=image,right=image[:,::-1].copy(),left=image[::-1].copy(),
                        state=np.linspace(-.1,.1,dim,dtype=np.float32),ctrl_freqs=np.array([30],dtype=np.float32))


def load_observation(path,dim,instruction):
    with np.load(path,allow_pickle=False) as data:
        payload={name:data[name].copy() for name in ('top','right','left','state','ctrl_freqs')}
    for name in ('top','right','left'):
        im=payload[name]
        if im.ndim!=3 or im.shape[2]!=3 or im.dtype!=np.uint8:raise ValueError(name+' must be uint8 HxWx3 RGB')
    if payload['state'].shape!=(dim,) or not np.isfinite(payload['state']).all():raise ValueError('Wrong or nonfinite state vector')
    if payload['ctrl_freqs'].shape!=(1,) or not np.isfinite(payload['ctrl_freqs']).all() or payload['ctrl_freqs'][0]<=0:raise ValueError('ctrl_freqs must be one positive finite value')
    if not instruction.strip():raise ValueError('Instruction cannot be empty')
    payload['state']=payload['state'].astype(np.float32);payload['ctrl_freqs']=payload['ctrl_freqs'].astype(np.float32)
    payload['instruction']=instruction
    return payload


def main():
    p=argparse.ArgumentParser();p.add_argument('--demo',action='store_true');p.add_argument('--input',type=Path)
    p.add_argument('--repo',type=Path);p.add_argument('--checkpoint',type=Path);p.add_argument('--statistics',type=Path)
    p.add_argument('--instruction',default='place the object in the container')
    p.add_argument('--output',type=Path,default=Path('go1-actions.npy'));a=p.parse_args()
    if a.demo:
        a.input=Path('synthetic-observation.npz');make_fixture(a.input);dim=16;action_dim=16;chunk=30
    else:
        if any(v is None for v in (a.input,a.repo,a.checkpoint)):p.error('Real inference requires --input, --repo and --checkpoint local paths')
        config=json.loads((a.checkpoint/'config.json').read_text())
        action_config=config['action_config'];dim=int(action_config['state_dim']);action_dim=int(action_config['action_dim']);chunk=int(config['action_chunk_size'])
        if config.get('norm',False) and a.statistics is None:p.error('This checkpoint requires its matching --statistics JSON')
    payload=load_observation(a.input,dim,a.instruction);start=time.monotonic()
    if a.demo:
        # Deterministic artificial output exercises file handling, NOT a GO-1 prediction.
        actions=np.linspace(0,.02,chunk,dtype=np.float32)[:,None]*np.ones((1,action_dim),dtype=np.float32)
    else:
        sys.path.insert(0,str(a.repo.resolve()))
        from evaluate.deploy import GO1Infer
        model=GO1Infer(model_path=str(a.checkpoint),data_stats_path=str(a.statistics) if a.statistics else None)
        actions=np.asarray(model.inference(payload))
    if actions.shape!=(chunk,action_dim) or not np.isfinite(actions).all():raise ValueError('Unexpected action chunk; nothing written')
    np.save(a.output,actions,allow_pickle=False)
    metadata={'demo':a.demo,'checkpoint':str(a.checkpoint) if a.checkpoint else None,'input':str(a.input),
              'output':str(a.output),'shape':list(actions.shape),'elapsed_including_load_s':time.monotonic()-start,
              'control_hz':float(payload['ctrl_freqs'][0]),'horizon_s':chunk/float(payload['ctrl_freqs'][0]),
              'execution':'Output file only; no action sent to hardware'}
    Path(str(a.output)+'.json').write_text(json.dumps(metadata,indent=2));print(json.dumps(metadata,indent=2))
    if a.demo:assert actions.shape==(30,16) and abs(metadata['horizon_s']-1)<1e-9
if __name__=='__main__':main()
ACADEMY_FILE_0
cat > prepare_model.sh <<'ACADEMY_FILE_1'
#!/usr/bin/env bash
# Optional GPU research environment, separate from the lightweight offline venv.
set -euo pipefail
cd "$(dirname "$0")"
command -v python3.10 >/dev/null || { echo 'Install Python 3.10 before preparing the vendor model environment.' >&2;exit 2; }
command -v nvidia-smi >/dev/null || { echo 'This course model environment requires an NVIDIA CUDA host.' >&2;exit 2; }
nvidia-smi
python3.10 -m venv .venv-go1
source .venv-go1/bin/activate
if [ ! -d AgiBot-World ]; then
  git clone https://github.com/OpenDriveLab/AgiBot-World.git AgiBot-World
  git -C AgiBot-World checkout --detach 98f136ea6b345db1a08451a2f543d67c1789a809
fi
test "$(git -C AgiBot-World rev-parse HEAD)" = 98f136ea6b345db1a08451a2f543d67c1789a809 || { echo 'Existing model code differs from course pin.' >&2;exit 2; }
python -m pip install --upgrade pip
python -m pip install -e ./AgiBot-World
python -m pip freeze > installed-go1-packages.txt
python -c 'import torch; assert torch.cuda.is_available(), "CUDA is unavailable"; print(torch.__version__, torch.version.cuda)'
echo 'Environment prepared. Acquire the checkpoint under its published license; no weights or dataset were downloaded by this script.'
ACADEMY_FILE_1
printf '%s\n' 'Created 2 file(s) in ~/robot-academy/ag-go1-inference-file'
)
