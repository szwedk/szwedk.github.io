#!/usr/bin/env bash
# Optional GPU research environment, separate from the lightweight offline venv.
set -euo pipefail
cd "$(dirname "$0")"
command -v python3.10 >/dev/null || { echo 'Install Python 3.10 before preparing the vendor model environment.' >&2;exit 2; }
command -v nvidia-smi >/dev/null || { echo 'This course model environment requires an NVIDIA CUDA host.' >&2;exit 2; }
nvidia-smi
python3.10 -m venv .venv-go1
source .venv-go1/bin/activate
if [ ! -d AgiBot-World ]; then
  git clone https://github.com/OpenDriveLab/AgiBot-World.git AgiBot-World
  git -C AgiBot-World checkout --detach 98f136ea6b345db1a08451a2f543d67c1789a809
fi
test "$(git -C AgiBot-World rev-parse HEAD)" = 98f136ea6b345db1a08451a2f543d67c1789a809 || { echo 'Existing model code differs from course pin.' >&2;exit 2; }
python -m pip install --upgrade pip
python -m pip install -e ./AgiBot-World
python -m pip freeze > installed-go1-packages.txt
python -c 'import torch; assert torch.cuda.is_available(), "CUDA is unavailable"; print(torch.__version__, torch.version.cuda)'
echo 'Environment prepared. Acquire the checkpoint under its published license; no weights or dataset were downloaded by this script.'
