#!/usr/bin/env python3
"""Inspect an AgiBot World proprio_stats.h5; --demo creates original synthetic data."""
import argparse
import csv
import json
from pathlib import Path
import h5py
import numpy as np


def create_demo(path):
    n=121;t=np.arange(n)/30
    action=np.stack([.2*np.sin(t+i*.1) for i in range(14)],axis=1)
    with h5py.File(path,'w') as f:
        f.attrs['course_synthetic_fixture']=True
        f.create_dataset('timestamp',data=np.arange(n,dtype=np.int64)*33333333)
        f.create_dataset('state/joint/position',data=action*.9)
        f.create_dataset('action/joint/position',data=action)


def inspect(path,out):
    with h5py.File(path,'r') as f:
        paths=('timestamp','state/joint/position','action/joint/position')
        missing=[p for p in paths if p not in f]
        if missing:raise ValueError('Missing datasets: '+', '.join(missing))
        raw_time=np.asarray(f['timestamp'])
        state=np.asarray(f['state/joint/position']);action=np.asarray(f['action/joint/position'])
        synthetic=bool(f.attrs.get('course_synthetic_fixture',False))
    if raw_time.ndim!=1 or len(raw_time)<2:raise ValueError('Expected at least two timestamps')
    if raw_time.dtype.kind not in 'iu' or np.any(raw_time>np.iinfo(np.int64).max):raise ValueError('Expected int64-compatible nanosecond timestamps')
    stamps=raw_time.astype(np.int64);gaps=np.diff(stamps)
    if np.any(gaps<=0):raise ValueError('Nonmonotonic or duplicate timestamps')
    if state.shape!=(len(stamps),14) or action.shape!=state.shape:raise ValueError('Expected [N,14] arm state/action arrays; choose the correct dataset schema')
    if not np.isfinite(state).all() or not np.isfinite(action).all():raise ValueError('Nonfinite joint values')
    elapsed=(stamps-stamps[0])/1e9
    with Path(str(out)+'.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['elapsed_s']+[f'state_joint_{i:02d}' for i in range(14)]+[f'action_joint_{i:02d}' for i in range(14)])
        for t,s,a in zip(elapsed,state,action):writer.writerow([t,*s,*a])
    result={'file':str(path),'synthetic':synthetic,'samples':len(stamps),'duration_s':float(elapsed[-1]),
       'median_period_ms':float(np.median(gaps)/1e6),'max_gap_ms':float(gaps.max()/1e6),
       'per_joint_state_action_rmse_rad':np.sqrt(np.mean((state-action)**2,axis=0)).tolist(),
       'joint_order':'Dataset arm slots 0..6 left, 7..13 right; these are array labels, not a hardware SDK mapping.',
       'interpretation':'State-action disagreement is a tracking/data diagnostic, not a learned policy score.'}
    Path(str(out)+'.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--demo',action='store_true');p.add_argument('--file',type=Path)
    p.add_argument('--out',type=Path,default=Path('episode-report'));a=p.parse_args()
    if a.demo:
        a.file=Path('synthetic-episode.h5');create_demo(a.file)
    if a.file is None:p.error('Choose --demo or --file pointing to your authorized proprio_stats.h5')
    report=inspect(a.file,a.out)
    if a.demo:
        assert report['samples']==121 and report['synthetic']
        broken=Path('synthetic-broken-time.h5');create_demo(broken)
        with h5py.File(broken,'r+') as f:f['timestamp'][2]=f['timestamp'][1]
        try:inspect(broken,Path('should-not-exist'))
        except ValueError as error:assert 'timestamps' in str(error)
        else:raise AssertionError('Duplicate timestamp was accepted')
        print('Synthetic normal and invalid-time checks passed')
if __name__=='__main__':main()
