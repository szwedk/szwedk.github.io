Turn an AgiBot G1 episode into a usable joint CSV

Read an actual AgiBot World HDF5 episode, validate its nanosecond timeline and fourteen arm coordinates, then export measured/target joint traces and timing diagnostics.

PLATFORM: AGIBOT G1 / GO-1

ENVIRONMENT: Offline

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Python 3.10+, NumPy and h5py

Optional: a locally available, authorized AgiBot World proprio_stats.h5 with the documented Alpha joint schema

This is the AGIBOT data platform, not Unitree G1

CONFIGURATION

AGIBOT_EPISODE = An absolute path to one proprio_stats.h5
Select one episode rather than attempting to download the complete multi-terabyte dataset.

--out = real-episode-report
Prefix for the CSV and JSON report.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-g1-episode-inspector. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-g1-episode-inspector"
cd "$HOME/robot-academy/ag-g1-episode-inspector"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install "numpy>=1.24,<3"
python -m pip install "h5py>=3.10,<4"
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-g1-episode-inspector"
source .venv/bin/activate
python inspect_episode.py --demo
# Optional: point to one already downloaded, authorized episode.
# python inspect_episode.py --file "$AGIBOT_EPISODE" --out real-episode-report
)

EXPECTED RESULT

Demo generates a synthetic 121-sample episode, CSV and JSON report.

The embedded negative test rejects a duplicate timestamp before producing a misleading report.

Real input requires monotonically increasing integer timestamps and matching [N,14] state/action arrays.

Summary includes median sample interval, largest gap and per-joint state/action disagreement.

What is actually inspected

The program opens /timestamp, /state/joint/position and /action/joint/position. It converts nanoseconds to elapsed seconds only after validating their order, preserving subsecond precision without casting epoch timestamps to floating point first. The arm arrays must both have fourteen finite values per timestamp. CSV headers use explicit array-slot labels; the dataset’s left-seven/right-seven order does not automatically become a hardware SDK joint map.



Do not turn disagreement into a policy score

The state/action RMSE describes how recorded measured positions differ from recorded targets at the same stored index. Timing offset, actuator lag and dataset conventions can all affect it. It is not an evaluation of GO-1 and does not measure task completion. Inspect camera synchronization and the dataset’s action-index semantics separately before building training windows. The synthetic file exists only to exercise parsing and validation and is marked with a fixture attribute.



TROUBLESHOOTING

Expected [N,14] arrays
Confirm you selected the documented AgiBot World joint schema. A LeRobot-converted dataset or another embodiment needs its own explicit adapter.

Nonmonotonic or duplicate timestamps
Inspect the episode rather than sorting rows independently. Reordering timestamps without aligned state/action/image records can corrupt synchronization.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-go1-identity

https://kamilszwed.com/courses/#/lesson/ag-go1-data-audit

https://kamilszwed.com/courses/#/lesson/ag-go1-observation-contract

SOURCES

AgiBot World and GO-1
https://github.com/OpenDriveLab/AgiBot-World/blob/98f136ea6b345db1a08451a2f543d67c1789a809/README.md
98f136ea6b345db1a08451a2f543d67c1789a809; 2026-05-29T12:31:22Z

AgiBotWorld Alpha dataset card
https://huggingface.co/datasets/agibot-world/AgiBotWorld-Alpha
Current dataset card; verify artifact license before reuse
