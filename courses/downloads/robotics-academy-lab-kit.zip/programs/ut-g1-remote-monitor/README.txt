Decode G1 remote buttons and joystick axes

Decode the vendor 40-byte wireless remote layout, record axes, and print button press/release edges without binding them to robot actions.

PLATFORM: Unitree G1

ENVIRONMENT: Synthetic data; optional DDS subscription

VALIDATION

Offline tests passed

Python syntax, embedded self-test and synthetic run passed on macOS arm64 with Python 3.11. Live transport and physical robot behavior were not tested.

REQUIREMENTS

Offline path: Python 3.10 or 3.11 and a terminal. No SDK, ROS, robot or network is needed for synthetic data.

Optional SDK path: Ubuntu 22.04 x86_64/aarch64, Python 3.10, administrative access for build packages, an Ethernet interface, and the exact robot edition with supported development access.

Pinned SDK2 C++ 63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36; SDK2 Python 814556d15970dd2ecf1c9984e845ca02ab07e206; CycloneDDS 0.10.2 at 9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd.

The raw wireless_remote layout and button mapping must match the audited G1 SDK example. Live default topic is rt/lf/lowstate.

CONFIGURATION

--topic = rt/lf/lowstate
Verified remote example topic. Override only when the actual state publisher uses a different name.

--output = remote-live.jsonl
Output includes receive time, button word, pressed names and normalized decoder field names.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-g1-remote-monitor. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-g1-remote-monitor"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-g1-remote-monitor"
  .venv/bin/python g1_remote.py --self-test
  .venv/bin/python g1_remote.py --mock --samples 40 --output remote.jsonl
  head -n 2 remote.jsonl
)

# OPTIONAL LIVE READ: first verify the exact robot, network interface,
# DDS domain and vendor development access. Uncomment the whole block.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-g1-remote-monitor"
#   bash install_sdk2.sh --install
#   source activate-sdk.sh
#   ROBOT_INTERFACE=enp3s0
#   python g1_remote.py --live --interface "$ROBOT_INTERFACE" --domain 0 --seconds 10 --output remote-live.jsonl
# )

EXPECTED RESULT

The fixture produces R1 and A press/release events plus 40 complete decoded records.

The self-test checks little-endian floating-point axes, the 16-button bit mapping and short-payload rejection.

Moving a live joystick only changes the log produced by this program; this reader sends no robot commands.

Byte layout, not arbitrary unpacking

Bytes 2 and 3 form a 16-bit button word. Lx, Rx and Ry are little-endian floats beginning at offsets 4, 8 and 12; Ly begins at 20. A four-byte field at offset 16 is not treated as an axis. The parser requires at least 40 bytes and validates finite float results before logging.



Events without action coupling

The recorder logs every sample but prints button changes only. This separation makes it useful when reviewing a remote layout or collecting operator timing evidence. No press, including Start or Select, invokes a locomotion or mode API in this program. Mapping a button into a control state machine is a separate implementation with explicit ownership and stop behavior.



TROUBLESHOOTING

The live reader records zero samples.
Confirm the interface exists, the DDS domain matches, the exact HG type and topic are published, and the robot edition supports this interface. The reader exits after the requested duration; it never changes a controller mode to make state appear.

Importing cyclonedds fails or the native library cannot be found.
Run the included installer only on its supported Ubuntu version, then source activate-sdk.sh from this recipe directory. Do not mix the system ROS Python environment with this private SDK virtual environment.

Axis names or signs appear unexpected.
Inspect the raw SDK mapping and confirm that Lx, Rx, Ry and Ly correspond to the intended operator controls. The reserved float at byte 16 is deliberately skipped; do not shift Ly into that slot.

A button remains pressed across many samples.
That is a button state, not repeated press events. The tool reports rising and falling edges by comparing consecutive bit sets.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-state

https://kamilszwed.com/courses/#/lesson/ut-g1-ownership

SOURCES

SDK2 Python installation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/README.md
814556d15970dd2ecf1c9984e845ca02ab07e206

G1 LowState wire schema
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/msg/LowState.msg
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

SDK2 Python subscriber lifecycle and queue implementation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/core/channel.py
814556d15970dd2ecf1c9984e845ca02ab07e206

G1 Python wireless remote parser
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/example/wireless_controller/wireless_controller.py
814556d15970dd2ecf1c9984e845ca02ab07e206
