"""Decode G1 remote bytes from HG LowState; this program never acts on buttons."""
import argparse
import json
import math
import struct
from pathlib import Path
from reader_common import add_reader_args,fixture,stream
BUTTONS=['R1','L1','Start','Select','R2','L2','F1','F3','A','B','X','Y','Up','Right','Down','Left']


def decode(raw):
    data=bytes(raw)
    if len(data)!=40:raise ValueError('Expected 40 remote bytes in HG LowState')
    bits=data[2] | (data[3]<<8)
    axes={name:struct.unpack_from('<f',data,offset)[0] for name,offset in [('Lx',4),('Rx',8),('Ry',12),('Ly',20)]}
    if not all(math.isfinite(x) for x in axes.values()):raise ValueError('Nonfinite stick value')
    return {'buttons':[name for bit,name in enumerate(BUTTONS) if bits&(1<<bit)],'axes':axes,'raw_button_bits':bits}


def main():
    p=argparse.ArgumentParser(description=__doc__);add_reader_args(p,'rt/lf/lowstate')
    p.add_argument('--output',default='remote-events.jsonl');a=p.parse_args()
    if a.self_test:
        d=decode(fixture('g1',0).wireless_remote);assert d['buttons']==['R1','A'];assert abs(d['axes']['Ly']+0.2)<1e-6
        try:decode([0]*39)
        except ValueError:pass
        else:raise AssertionError('Short record accepted')
        print('PASS: little-endian axes, button map and length guard');return 0
    stats={};previous=set();count=0
    with Path(a.output).open('w') as handle:
        try:
            for received,message in stream('g1',a,stats):
                d=decode(message.wireless_remote);current=set(d['buttons'])
                d.update(received_s=received,pressed=sorted(current-previous),released=sorted(previous-current))
                handle.write(json.dumps(d,allow_nan=False)+'\n')
                if d['pressed'] or d['released']:print(json.dumps(d))
                previous=current;count+=1
        except KeyboardInterrupt:print('Stopped; reader closed.')
    print(json.dumps(dict(stats,records=count)));return 0 if count else 2
if __name__=='__main__':raise SystemExit(main())
