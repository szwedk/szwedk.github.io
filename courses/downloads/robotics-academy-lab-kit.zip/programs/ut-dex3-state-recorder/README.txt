Record Dex3 joints and tactile arrays

Subscribe to one hand’s state channel, preserve seven joint observations and variable tactile arrays, and report raw sensor availability without running the vendor motion example.

PLATFORM: Unitree Dex3

ENVIRONMENT: Synthetic data; optional DDS subscription

VALIDATION

Offline tests passed

Python syntax, embedded self-test and synthetic run passed on macOS arm64 with Python 3.11. Live transport and physical robot behavior were not tested.

REQUIREMENTS

Offline path: Python 3.10 or 3.11 and a terminal. No SDK, ROS, robot or network is needed for synthetic data.

Optional SDK path: Ubuntu 22.04 x86_64/aarch64, Python 3.10, administrative access for build packages, an Ethernet interface, and the exact robot edition with supported development access.

Pinned SDK2 C++ 63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36; SDK2 Python 814556d15970dd2ecf1c9984e845ca02ab07e206; CycloneDDS 0.10.2 at 9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd.

A verified Dex3 hand and side, its attached tactile configuration, and an available HandState publisher. The current audited example uses rt/lf/dex3/left/state or rt/lf/dex3/right/state.

CONFIGURATION

--side = left
Select left or right; determines the default state topic and side metadata.

--topic = rt/lf/dex3/left/state
Explicit override for a verified firmware topic. The default is derived from --side.

--seconds = 10
Stops an optional live subscription after the chosen duration.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-dex3-state-recorder. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-dex3-state-recorder"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-dex3-state-recorder"
  .venv/bin/python dex3_record.py --self-test
  .venv/bin/python dex3_record.py --mock --side left --samples 100 --output dex3-left.jsonl
  head -n 1 dex3-left.jsonl
)

# OPTIONAL LIVE READ: first verify the exact robot, network interface,
# DDS domain and vendor development access. Uncomment the whole block.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-dex3-state-recorder"
#   bash install_sdk2.sh --install
#   source activate-sdk.sh
#   ROBOT_INTERFACE=enp3s0
#   python dex3_record.py --live --interface "$ROBOT_INTERFACE" --domain 0 --seconds 10 --side left --output dex3-left-live.jsonl
# )

EXPECTED RESULT

The fixture writes 100 frames with seven joint records and two synthetic pressure arrays of twelve values each. Two arrays are a test fixture, not a hardware sensor-count claim.

Each record preserves pressure-array lost counters, motor raw status, power_v, power_a and hand error values.

An empty press_sensor_state sequence produces pressure_available=false; the recorder does not synthesize contact or force.

What the hand schema exposes

HandState contains a sequence of motor states and a sequence of pressure sensor states. Each pressure entry carries twelve pressure values, twelve temperatures and a lost counter. Array count can depend on the actual hand/sensor configuration; this recorder enumerates the sequence instead of hard-coding a whole-hand tactile layout.



Preserve absence and error evidence

The program rejects a motor-count mismatch because joint labels would otherwise be misleading. Missing pressure arrays are retained as an explicit availability flag. Device errors and lost counts remain raw integers so later analysis can apply the exact firmware documentation. A populated array establishes data availability, not successful force calibration.



TROUBLESHOOTING

The live reader records zero samples.
Confirm the interface exists, the DDS domain matches, the exact HG type and topic are published, and the robot edition supports this interface. The reader exits after the requested duration; it never changes a controller mode to make state appear.

Importing cyclonedds fails or the native library cannot be found.
Run the included installer only on its supported Ubuntu version, then source activate-sdk.sh from this recipe directory. Do not mix the system ROS Python environment with this private SDK virtual environment.

The recorder rejects a non-seven-motor message.
Confirm the exact hand model, side and topic. Dex3’s seven-actuator contract must not be applied to Dex5 or another gripper.

Pressure numbers are present but not interpretable as newtons.
Keep the raw values. The schema alone does not establish calibration, contact thresholds or force conversion for the delivered sensors.

The vendor dex3 sample starts moving the hand.
That sample includes INIT and ROTATE command states. Use this subscriber-only program for inspection; it contains no HandCmd or publisher.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-dex3-map

https://kamilszwed.com/courses/#/lesson/ut-hand-tactile

SOURCES

Official Dex3 control example
https://github.com/unitreerobotics/unitree_sdk2/blob/63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36/example/g1/dex3/g1_dex3_example.cpp
63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36

HG hand feedback schema
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/msg/HandState.msg
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

SDK2 Python subscriber lifecycle and queue implementation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/core/channel.py
814556d15970dd2ecf1c9984e845ca02ab07e206

HG Python PressSensorState generated fields
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/idl/unitree_hg/msg/dds_/_PressSensorState_.py
814556d15970dd2ecf1c9984e845ca02ab07e206
