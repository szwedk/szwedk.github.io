"""Receive-only Dex3 HandState logger. Pressure values retain raw vendor units."""
import argparse
import json
import math
from pathlib import Path
from reader_common import add_reader_args,fixture,stream
NAMES=['thumb_0','thumb_1','thumb_2','index_0','index_1','middle_0','middle_1']


def convert(m,t,side):
    if len(m.motor_state)!=7:raise ValueError('Expected seven Dex3 motor states; confirm hand model')
    motors=[dict(index=i,name=NAMES[i],q=float(x.q),dq=float(x.dq),tau_est=float(x.tau_est),
                 temperature=list(x.temperature),status=int(x.motorstate)) for i,x in enumerate(m.motor_state)]
    arrays=[dict(index=i,pressure=list(x.pressure),temperature=list(x.temperature),lost=int(x.lost))
            for i,x in enumerate(m.press_sensor_state)]
    return dict(received_s=t,side=side,motors=motors,pressure_arrays=arrays,
                pressure_available=bool(arrays),power_v=float(m.power_v),power_a=float(m.power_a),
                errors=list(m.error),pressure_units='raw; calibration not assumed')


def main():
    p=argparse.ArgumentParser(description=__doc__);add_reader_args(p,'')
    p.add_argument('--side',choices=['left','right'],default='left');p.add_argument('--output',default='dex3-state.jsonl')
    a=p.parse_args();a.topic=a.topic or 'rt/lf/dex3/'+a.side+'/state'
    if a.self_test:
        row=convert(fixture('dex3',0),0,'left');assert len(row['motors'])==7 and len(row['pressure_arrays'][0]['pressure'])==12
        m=fixture('dex3',0);m.press_sensor_state=[];assert convert(m,0,'right')['pressure_available'] is False
        m.motor_state=m.motor_state[:6]
        try:convert(m,0,'left')
        except ValueError:pass
        else:raise AssertionError('Wrong motor count accepted')
        print('PASS: seven joints, twelve values per fixture array, missing pressure and wrong count');return 0
    stats={};count=0;rejected=0
    with Path(a.output).open('w') as handle:
        try:
            for received,m in stream('dex3',a,stats):
                try:encoded=json.dumps(convert(m,received,a.side),allow_nan=False)
                except (ValueError,AttributeError) as error:rejected+=1;print('Rejected:',error);continue
                handle.write(encoded+'\n');count+=1
                if count==1:print(encoded)
        except KeyboardInterrupt:print('Stopped; reader closed.')
    print(json.dumps(dict(stats,records=count,rejected=rejected,topic=a.topic)));return 0 if count else 2
if __name__=='__main__':raise SystemExit(main())
