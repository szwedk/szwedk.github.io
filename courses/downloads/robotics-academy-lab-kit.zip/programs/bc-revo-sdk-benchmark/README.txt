Measure Revo read success and latency

Run the vendor’s read-only motor-status benchmark with fixed test selection, then turn its JSON into a concise rate, reliability and latency report.

PLATFORM: BrainCo Revo

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Device: Linux x86_64/aarch64, Python 3.9+, glibc ≥2.34 and an SDK-supported Revo hand/adapter

Only the intended hand attached: the pinned vendor benchmark selects the first detected device

Optional installation uses an isolated venv and the verified PyPI SDK release 2.0.5

CONFIGURATION

--device = Enable only after the offline run
Connects through the pinned vendor read benchmark. Omitted by default.

--target-hz = 100
Requested read rate; course limit 500 Hz is an input bound, not a performance claim.

--duration = 10
Requested measurement interval, at most 120 seconds; wrapper adds a 30-second overall allowance.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/bc-revo-sdk-benchmark. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/bc-revo-sdk-benchmark"
cd "$HOME/robot-academy/bc-revo-sdk-benchmark"
python3 --version
python3 -m py_compile read_benchmark.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/bc-revo-sdk-benchmark"
python3 read_benchmark.py

# Optional SDK installation; does not open the device:
# bash prepare_sdk.sh
# Optional read-only hardware measurement after checking attached adapters:
# source .venv/bin/activate
# python read_benchmark.py --device --sdk-dir "$PWD/brainco-hand-sdk" --duration 10 --target-hz 100 --output revo-device.json
)

EXPECTED RESULT

Offline summary shows 100 synthetic attempts, 98 successes, two failures and success_fraction 0.98.

Device path invokes only vendor test 1; it cannot select a writing test through passthrough flags.

JSON summary preserves achieved rate, requested rate, p99, worst latency and connection details.

A wrapper with a deliberately narrow interface

The pinned comm_frequency_test.py includes tests that move fingers. This wrapper hard-codes the positional test number 1, which reads motor status, and exposes only duration, target rate and output options. It uses the same Python interpreter as the wrapper, so the optional venv holds both dependencies and the vendor SDK. The optional installer uses the official documented PyPI fallback pinned to 2.0.5 because the vendor OSS wheel URLs returned 404 during QA. Both matching Linux release files were checked on PyPI. A wall-clock timeout terminates an overlong read test. The vendor benchmark discovers the first device, making adapter inventory necessary before a live run.



What the numbers mean

Attempt count includes failures; achieved_frequency_hz in the vendor report counts successful operations per elapsed second. The summary checks that successful plus failed attempts equals the total. A 100 Hz request with 98 Hz achieved throughput may result from errors, scheduling, transport latency or a combination. p99 is a tail-latency diagnostic from successful samples, not a hard latency bound. Run repeated measurements at documented rates and save exact adapter/firmware identity before choosing a controller update rate.



TROUBLESHOOTING

No report produced
Check device discovery and permissions in the pinned vendor example. Auto-detection may find no supported device even if the subprocess exits normally.

Wheel cannot install
Use supported Linux architecture, Python ≥3.9 and glibc ≥2.34; stay inside the venv. Do not override system package protections.

Wrong device selected
Disconnect unrelated adapters and confirm the intended protocol and hand generation. This benchmark does not expose a manually selected port.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/bc-revo-identity

https://kamilszwed.com/courses/#/lesson/bc-revo-benchmark

SOURCES

BrainCo Revo1/2 SDK
https://github.com/BrainCoTech/brainco-hand-sdk/blob/f7c9c4264cee9461bc6aa99f8082e77e5a330857/README.md
f7c9c4264cee9461bc6aa99f8082e77e5a330857; 2026-09-17T06:39:59Z

BrainCo read-frequency benchmark implementation
https://github.com/BrainCoTech/brainco-hand-sdk/blob/f7c9c4264cee9461bc6aa99f8082e77e5a330857/python/demo/comm_frequency_test.py
f7c9c4264cee9461bc6aa99f8082e77e5a330857

BrainCo SDK wheel installer
https://github.com/BrainCoTech/brainco-hand-sdk/blob/f7c9c4264cee9461bc6aa99f8082e77e5a330857/python/install_whl.sh
f7c9c4264cee9461bc6aa99f8082e77e5a330857; wheel 2.0.5

BrainCo Stark SDK 2.0.5 release files
https://pypi.org/project/bc-stark-sdk/2.0.5/
2.0.5; Linux wheel URLs checked 2026-09-30
