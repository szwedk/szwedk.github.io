#!/usr/bin/env bash
# Explicit optional installation; this script never opens a robot or hand.
set -euo pipefail
cd "$(dirname "$0")"
test "$(uname -s)" = Linux || { echo 'The vendor wheel in this recipe requires Linux.' >&2; exit 2; }
arch=$(uname -m)
case "$arch" in x86_64|aarch64) ;; *) echo "Unsupported architecture: $arch" >&2; exit 2;; esac
python3 -m venv .venv
source .venv/bin/activate
if [ ! -d brainco-hand-sdk ]; then
  git clone https://github.com/BrainCoTech/brainco-hand-sdk.git brainco-hand-sdk
  git -C brainco-hand-sdk checkout --detach f7c9c4264cee9461bc6aa99f8082e77e5a330857
fi
test "$(git -C brainco-hand-sdk rev-parse HEAD)" = f7c9c4264cee9461bc6aa99f8082e77e5a330857 || { echo 'Existing SDK checkout differs from course pin.' >&2;exit 2; }
python -m pip install -r brainco-hand-sdk/python/requirements.txt
# The vendor OSS links returned 404 during course QA; use its documented PyPI fallback.
python -m pip install --only-binary=:all: "bc-stark-sdk==2.0.5"
python -m pip freeze > installed-sdk-packages.txt
echo 'Installed. No device was opened. Inspect the USB adapters before selecting --device.'
