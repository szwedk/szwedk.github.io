#!/usr/bin/env python3
"""Run only vendor read test 1, then summarize its version-1 report."""
import argparse
import json
from pathlib import Path
import signal
import subprocess
import sys
import tempfile


def summarize(payload):
    if payload.get('schema_version')!=1:raise ValueError('Unexpected vendor report schema')
    reports=payload.get('reports',[])
    if not reports:raise ValueError('No measurement reports returned')
    rows=[]
    for r in reports:
        total,good,bad=r['total_tests'],r['successful_tests'],r['failed_tests']
        if total!=good+bad or total<=0:raise ValueError('Inconsistent attempt accounting')
        rows.append({'operation':r['function_name'],'attempts':total,'successes':good,'failures':bad,
          'success_fraction':good/total,'achieved_hz':r['actual_frequency_hz'],'requested_hz':r['target_frequency_hz'],
          'p99_latency_ms':r['p99_latency_ms'],'worst_latency_ms':r['max_latency_ms'],
          'connection':r['connection']})
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--device',action='store_true');p.add_argument('--sdk-dir',type=Path)
    p.add_argument('--duration',type=float,default=10);p.add_argument('--target-hz',type=float,default=100)
    p.add_argument('--output',type=Path,default=Path('revo-benchmark.json'));a=p.parse_args()
    if not 0<a.duration<=120 or not 0<a.target_hz<=500:p.error('Duration (0,120] and rate (0,500] required')
    if not a.device:
        payload={'schema_version':1,'reports':[{'function_name':'get_motor_status','total_tests':100,'successful_tests':98,'failed_tests':2,
         'actual_frequency_hz':98.,'target_frequency_hz':100.,'p99_latency_ms':14.,'max_latency_ms':20.,
         'connection':{'protocol':'SYNTHETIC','port_name':'none'}}]}
        a.output.write_text(json.dumps(payload,indent=2))
    else:
        if a.sdk_dir is None:p.error('--device requires --sdk-dir')
        program=a.sdk_dir.resolve()/'python/demo/comm_frequency_test.py'
        if not program.is_file():raise SystemExit('Pinned vendor benchmark not found: '+str(program))
        # A unique report path prevents a no-device run from reusing yesterday's JSON.
        with tempfile.TemporaryDirectory(prefix='revo-read-') as temporary:
            report_path=Path(temporary)/'vendor-report.json'
            command=[sys.executable,str(program),'1','--duration',str(a.duration),'--target-hz',str(a.target_hz),'--output',str(report_path)]
            # Hard-code test 1. No passthrough argument can select a moving test.
            child=subprocess.Popen(command)
            try:
                try:code=child.wait(timeout=a.duration+30)
                except (subprocess.TimeoutExpired,KeyboardInterrupt):
                    child.send_signal(signal.SIGINT)
                    try:child.wait(timeout=3)
                    except subprocess.TimeoutExpired:child.kill();child.wait()
                    raise SystemExit('Read-only benchmark interrupted or timed out')
                if code:raise SystemExit('Vendor read benchmark failed: '+str(code))
            finally:
                if child.poll() is None:child.terminate();child.wait(timeout=3)
            if not report_path.is_file():raise SystemExit('Vendor returned no new report; check device discovery')
            payload=json.loads(report_path.read_text())
            summarize(payload)  # Validate before replacing a prior successful report.
            a.output.write_text(json.dumps(payload,indent=2))
    summary={'mock':not a.device,'measurements':summarize(payload)}
    Path(str(a.output)+'.summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
    if not a.device:assert summary['measurements'][0]['success_fraction']==.98
if __name__=='__main__':main()
