# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ag-x2-mode-snapshot"
cd "$HOME/robot-academy/ag-x2-mode-snapshot"
cat > mode_snapshot.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Read-only X2 GetMcAction query; --mock runs without ROS or a robot."""
import argparse
import json
from pathlib import Path
import time


def write_report(response, output, mock=False):
    info = response.get('info', {})
    status = info.get('status', {}).get('value')
    if not info.get('action_desc') or status is None:
        raise ValueError('Response lacks the documented info.action_desc or info.status.value')
    report = {'mock': mock, 'received_unix_s': time.time(),
              'mode': info['action_desc'], 'status': status, 'raw_response': response}
    Path(output).write_text(json.dumps(report, indent=2))
    print(json.dumps({'mode': report['mode'], 'status': status, 'output': str(output), 'mock': mock}))
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mock', action='store_true')
    ap.add_argument('--output', default='x2-mode.json')
    ap.add_argument('--timeout', type=float, default=5.0)
    a = ap.parse_args()
    if not 0 < a.timeout <= 30:
        ap.error('--timeout must be between 0 and 30 seconds')
    if a.mock:
        r = write_report({'info': {'action_desc':'STAND_DEFAULT','status':{'value':100}}},a.output,True)
        assert r['mode']=='STAND_DEFAULT' and r['status']==100
        return
    import rclpy
    from rclpy.node import Node
    from aimdk_msgs.srv import GetMcAction
    from aimdk_msgs.msg import CommonRequest
    from rosidl_runtime_py.convert import message_to_ordereddict
    rclpy.init()
    node = Node('course_x2_mode_snapshot')
    client = node.create_client(GetMcAction, '/aimdk_5Fmsgs/srv/GetMcAction')
    try:
        if not client.wait_for_service(timeout_sec=a.timeout):
            raise RuntimeError('GetMcAction unavailable; check SDK/firmware match, domain and network')
        request = GetMcAction.Request()
        request.request = CommonRequest()
        request.request.header.stamp = node.get_clock().now().to_msg()
        future = client.call_async(request)
        rclpy.spin_until_future_complete(node, future, timeout_sec=a.timeout)
        if not future.done():
            future.cancel()
            raise TimeoutError('Read-only mode query timed out')
        response = future.result()
        if response is None:
            raise RuntimeError('No response: '+str(future.exception()))
        write_report(message_to_ordereddict(response), a.output)
    finally:
        node.destroy_node()
        rclpy.try_shutdown()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:raise SystemExit(130)
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ag-x2-mode-snapshot'
)
