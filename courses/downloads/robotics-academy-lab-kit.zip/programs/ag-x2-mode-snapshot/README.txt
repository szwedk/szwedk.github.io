Save the X2 motion mode as JSON

Call the real GetMcAction service once, preserve the entire response, and save a timestamped mode report. The first run exercises the same report writer with a synthetic response.

PLATFORM: AGIBOT X2

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Device: Ubuntu 22.04, ROS 2 Humble and matching AimDK X2 SDK/firmware

Vendor-approved external host or Ultra PC2 development container; never PC1 motion compute

CONFIGURATION

X2_READ_DEVICE = 1
Optional environment flag that enables the read-only service call after the mock test.

AIMDK_WS = $HOME/aimdk
Path to your built, firmware-matched SDK workspace.

--timeout = 5
Seconds for each discovery/response wait; maximum 30.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-x2-mode-snapshot. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-x2-mode-snapshot"
cd "$HOME/robot-academy/ag-x2-mode-snapshot"
python3 --version
python3 -m py_compile mode_snapshot.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-x2-mode-snapshot"
python3 mode_snapshot.py --mock

# Optional: set X2_READ_DEVICE=1 before copying this block.
# Requires an already configured, matching Humble/AimDK host.
if [ "${X2_READ_DEVICE:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
AIMDK_WS="${AIMDK_WS:-$HOME/aimdk}"
source "$AIMDK_WS/install/local_setup.bash"
python3 mode_snapshot.py --timeout 5 --output x2-mode-device.json
fi
)

EXPECTED RESULT

Offline prints STAND_DEFAULT, status 100 and mock true.

Device path saves the observed mode plus the full generated ROS response in x2-mode-device.json.

Service discovery and response waits each have a five-second limit by default.

The request and response

GetMcAction is a service, so the client issues one request and receives one reply. CommonRequest holds the vendor request header; its timestamp is filled immediately before call_async. The documented fields info.action_desc and info.status.value become convenient top-level report fields, while message_to_ordereddict retains the rest of the response for later diagnosis. The file also records host reception time. It is a snapshot, not a continuous interlock.



Why this does not switch modes

No SetMcAction client is created. The program never sends a standing, walking or damping request. The mock response is labeled explicitly and is useful only for exercising JSON handling. On hardware, use the returned mode and status together with the SDK version and physical observation; the string STAND_DEFAULT alone does not prove that the robot is mechanically stable.



TROUBLESHOOTING

Service unavailable
Check ROS_DOMAIN_ID, the connected interface, SDK overlay and firmware match. Confirm the official get_mc_action example works in the same shell.

No module named aimdk_msgs
Build the vendor-provided SDK archive in the Humble environment and source its install/local_setup.bash.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-x2-mode-state

https://kamilszwed.com/courses/#/lesson/ag-x2-environment

SOURCES

X2 mode state machine
https://x2-aimdk.agibot.com/en/latest/Interface/control_mod/modeswitch.html
AimDK_X2 1.1.0; live docs 2026-09-29

AimDK X2 Python examples
https://x2-aimdk.agibot.com/en/latest/example/Python.html
AimDK_X2 1.1.0; reviewed 2026-09-29

AimDK build and run workflow
https://x2-aimdk.agibot.com/en/latest/quick_start/run_example.html
AimDK_X2 1.1.0; reviewed 2026-09-29

ROS 2 Humble generated interface utilities
https://docs.ros.org/en/humble/p/rosidl_runtime_py/rosidl_runtime_py.convert.html
Humble; reviewed 2026-09-29
