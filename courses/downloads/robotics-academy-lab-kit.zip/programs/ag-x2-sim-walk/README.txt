Move the isolated X2 simulator, then send zero velocity

Generate a timed command trace offline, or publish a short forward request through the documented input-source mechanism in a loopback-only simulator.

PLATFORM: AGIBOT X2

ENVIRONMENT: Simulation

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

Simulation: Ubuntu 22.04 x86_64, Humble, matching AimDK, sim_mujoco and mc packages

All simulator processes on ROS_DOMAIN_ID=77 and ROS_LOCALHOST_ONLY=1; a local simulator already in STAND_DEFAULT

CONFIGURATION

X2_RUN_SIM = 1
Opt in to the isolated simulator after the offline trace has passed.

--speed = 0.15
Forward speed in m/s; course bound 0.1 to 0.2.

--seconds = 1
Duration up to two seconds.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-x2-sim-walk. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-x2-sim-walk"
cd "$HOME/robot-academy/ag-x2-sim-walk"
python3 --version
python3 -m py_compile sim_walk.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-x2-sim-walk"
python3 sim_walk.py --seconds 1 --speed 0.15

# Optional simulation execution: prepare the vendor simulator on the same
# loopback-only domain, then set X2_RUN_SIM=1 before copying this block.
if [ "${X2_RUN_SIM:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
AIMDK_WS="${AIMDK_WS:-$HOME/aimdk}"
source "$AIMDK_WS/install/local_setup.bash"
export ROS_DOMAIN_ID=77 ROS_LOCALHOST_ONLY=1
python3 sim_walk.py --sim --seconds 1 --speed 0.15 --output x2-sim-execution.json
fi
)

EXPECTED RESULT

Offline trace contains 50 forward requests followed by 10 zero requests.

Simulation path registers a unique sdk_course_ source, publishes at a target 50 Hz, sends zeros and removes that source.

Wrong isolation environment, unavailable service, missing velocity subscriber or wrong mode produces a refusal.

Ownership is part of the program

The simulator receives the same documented McLocomotionVelocity type used by AimDK. A unique sdk_ source is added through SetMcInputSource, then written into every message. Registration failure ends the run before movement. The program removes only its own source, avoiding interference with native entries. Priority 20 and a 1000 ms source timeout are explicit course choices; they do not bypass arbitration or guarantee that this source wins.



The timer and the stopping path

The host schedules requests every 20 ms for at most two seconds. Finally sends ten zero-velocity requests and attempts to delete the custom source. This is a useful control-flow exercise, not a real-time scheduling guarantee. The program has no hardware mode and requires loopback-only DDS on domain 77. Those settings must also be applied to every simulator process, and no real robot bridge may run in that local domain. The script never performs a stand transition or publishes low-level joint commands.



TROUBLESHOOTING

No velocity subscriber
Start all three vendor simulation components with the same isolation environment and source the matching AimDK overlay.

Simulator does not move although publication succeeds
Inspect the current control mode and source arbitration. Another higher-priority input may own control. Do not raise priority blindly or change a real robot mode.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-x2-command-ownership

https://kamilszwed.com/courses/#/lesson/ag-x2-simulation-stack

SOURCES

X2 input-source arbitration
https://x2-aimdk.agibot.com/en/latest/Interface/control_mod/MC_control.html
AimDK_X2 1.1.0; live docs 2026-09-29

X2 velocity control
https://x2-aimdk.agibot.com/en/latest/Interface/control_mod/locomotion.html
AimDK_X2 1.1.0; live docs 2026-09-29

X2 MuJoCo simulation
https://x2-aimdk.agibot.com/en/latest/sim_contents.html
AimDK_X2 1.1.0; live docs 2026-09-29

AimDK X2 Python examples
https://x2-aimdk.agibot.com/en/latest/example/Python.html
AimDK_X2 1.1.0; reviewed 2026-09-29
