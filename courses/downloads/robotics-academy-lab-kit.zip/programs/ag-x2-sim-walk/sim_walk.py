#!/usr/bin/env python3
"""X2 SIMULATION ONLY. Defaults to a mock command trace; no hardware option exists."""
import argparse
import json
import os
from pathlib import Path
import time
import uuid


def plan(speed, seconds):
    if not 0.1<=speed<=0.2 or not 0<seconds<=2:
        raise ValueError('Course simulation limits: speed 0.1..0.2 m/s; duration (0,2] s')
    return [speed]*max(1,round(seconds*50)) + [0.0]*10


def main():
    p=argparse.ArgumentParser();p.add_argument('--sim',action='store_true')
    p.add_argument('--speed',type=float,default=.15);p.add_argument('--seconds',type=float,default=1)
    p.add_argument('--output',default='x2-sim-commands.json');a=p.parse_args();values=plan(a.speed,a.seconds)
    if not a.sim:
        out={'mock':True,'rate_hz':50,'forward_velocity_mps':values,'note':'No ROS imports or robot connection'}
        assert values[-10:]==[0.0]*10
        Path(a.output).write_text(json.dumps(out,indent=2));print(json.dumps({'mock':True,'commands':len(values),'last_command':values[-1]}));return
    if os.environ.get('ROS_DOMAIN_ID')!='77' or os.environ.get('ROS_LOCALHOST_ONLY')!='1':
        raise SystemExit('Refusing: set ROS_DOMAIN_ID=77 and ROS_LOCALHOST_ONLY=1 on this client AND isolated simulator')
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy
    from aimdk_msgs.msg import CommonRequest,McLocomotionVelocity,McInputAction,McInputSource
    from aimdk_msgs.srv import GetMcAction,SetMcInputSource
    rclpy.init();node=Node('course_x2_sim_walk');source='sdk_course_'+uuid.uuid4().hex[:8];events=[];registered=False
    qos=QoSProfile(depth=1,reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE)
    pub=node.create_publisher(McLocomotionVelocity,'/aima/mc/locomotion/velocity',qos)
    def call(kind,name,request):
        client=node.create_client(kind,name)
        try:
            if not client.wait_for_service(timeout_sec=3):raise TimeoutError(name+' unavailable')
            f=client.call_async(request);rclpy.spin_until_future_complete(node,f,timeout_sec=3)
            if not f.done():f.cancel();raise TimeoutError(name+' response timeout')
            result=f.result()
            if result is None:raise RuntimeError(str(f.exception()))
            return result
        finally:node.destroy_client(client)
    def source_operation(value):
        req=SetMcInputSource.Request();req.request=CommonRequest();req.request.header.stamp=node.get_clock().now().to_msg()
        req.action=McInputAction();req.action.value=value
        req.input_source=McInputSource();req.input_source.name=source;req.input_source.priority=20;req.input_source.timeout=1000
        res=call(SetMcInputSource,'/aimdk_5Fmsgs/srv/SetMcInputSource',req)
        if res.response.header.code!=0:raise RuntimeError('Input-source request rejected: '+str(res.response.header.code))
    def send(v):
        msg=McLocomotionVelocity();msg.header.stamp=node.get_clock().now().to_msg();msg.source=source
        msg.forward_velocity=float(v);msg.lateral_velocity=0.;msg.angular_velocity=0.;pub.publish(msg)
        events.append({'monotonic_s':time.monotonic(),'forward_mps':v})
    try:
        query=GetMcAction.Request();query.request=CommonRequest();query.request.header.stamp=node.get_clock().now().to_msg()
        response=call(GetMcAction,'/aimdk_5Fmsgs/srv/GetMcAction',query)
        if response.info.action_desc not in ('STAND_DEFAULT','LOCOMOTION_DEFAULT'):
            raise RuntimeError('Prepare the isolated simulator in STAND_DEFAULT first; this script does not change modes')
        source_operation(1001);registered=True
        deadline=time.monotonic()+3
        while pub.get_subscription_count()==0 and time.monotonic()<deadline:rclpy.spin_once(node,timeout_sec=.1)
        if pub.get_subscription_count()==0:raise RuntimeError('No simulated velocity subscriber')
        end=time.monotonic()+a.seconds;next_tick=time.monotonic()
        while rclpy.ok() and time.monotonic()<end:
            send(a.speed);next_tick+=.02;rclpy.spin_once(node,timeout_sec=0);time.sleep(max(0,next_tick-time.monotonic()))
    except KeyboardInterrupt:pass
    finally:
        if registered:
            for _ in range(10):send(0.);rclpy.spin_once(node,timeout_sec=0);time.sleep(.02)
            try:source_operation(1003)
            except Exception as e:print('Custom source cleanup failed:',e)
        Path(a.output).write_text(json.dumps({'mock':False,'simulation_only':True,'source':source,'events':events},indent=2))
        node.destroy_node();rclpy.try_shutdown()
if __name__=='__main__':main()
