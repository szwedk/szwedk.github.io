Make a simulated G1 elbow track a moving target

Run real MuJoCo dynamics on the pinned G1 model, drive one named elbow through a smooth sinusoid, and measure tracking error with no robot transport.

PLATFORM: Unitree G1

ENVIRONMENT: Actual local physics simulation

VALIDATION

Physics simulation tested

MuJoCo 3.3.6 headless simulation passed 4,000 real physics steps on macOS arm64/Python 3.11. RMSE was 0.0168108478 rad, with 29 actuators and a moving measured elbow. No DDS/network, physical robot, free-base balance or contact behavior was tested.

REQUIREMENTS

Python 3.10 or 3.11, Git, MuJoCo 3.3.6 and NumPy 1.26.4 installed into this recipe’s private .venv.

unitree_mujoco pinned to 1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d; g1_29dof.xml and its mesh assets are loaded from that checkout.

The teaching fixture fixes the pelvis, disables gravity and collisions, and holds other actuated joints at zero. It studies an isolated actuator loop, not standing balance or locomotion.

CONFIGURATION

--seconds = 8
Simulation time, limited to at most 60 seconds. The default headless loop may run faster than wall time.

--model = vendor/unitree_mujoco/unitree_robots/g1/g1_29dof.xml
Pinned G1 MJCF with the expected named elbow and mesh assets.

--viewer = Explicit flag
Opens a passive viewer, sleeps between steps, and closes it when the run ends or is interrupted.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-g1-elbow-simulation. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-g1-elbow-simulation"
  command -v git
  python3 -m venv .venv
  .venv/bin/python -m pip install 'mujoco==3.3.6' 'numpy==1.26.4'
  mkdir -p vendor
  if [ ! -d vendor/unitree_mujoco/.git ]; then
    git clone https://github.com/unitreerobotics/unitree_mujoco.git vendor/unitree_mujoco
  fi
  [ -z "$(git -C vendor/unitree_mujoco status --porcelain --untracked-files=no)" ]
  git -C vendor/unitree_mujoco checkout --detach 1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d
  [ "$(git -C vendor/unitree_mujoco rev-parse HEAD)" = 1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d ]
  .venv/bin/python -m py_compile g1_elbow_sim.py
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-g1-elbow-simulation"
  .venv/bin/python g1_elbow_sim.py --seconds 8 --self-test --output elbow-track.csv
  cat elbow-track.summary.json
  head -n 4 elbow-track.csv
)

# OPTIONAL viewer on Linux, in the same recipe directory:
# (
#   set -e
#   cd "$HOME/robot-academy/ut-g1-elbow-simulation"
#   .venv/bin/python g1_elbow_sim.py --seconds 8 --viewer --output elbow-viewer.csv
# )
# On macOS the passive viewer requires mjpython; replace the preceding
# .venv/bin/python with .venv/bin/mjpython. Headless runs use normal Python.

EXPECTED RESULT

The eight-second run advances 4,000 physics steps at 0.002 seconds per step. It writes target, measured angle, error and applied actuator control to CSV.

The self-test verifies 29 scalar positions/actuators, measurable elbow motion and steady tracking RMSE below 0.08 rad in this exact fixture.

The tested headless run achieved 0.01681 rad RMSE and measured angles approximately 0.3564–0.6436 rad. These are fixture results, not physical G1 accuracy claims.

The moving behavior

The controller requests q*=0.5+0.15 sin(2π·0.25·t) radians for right_elbow. All other actuator targets stay at zero. Each step computes a proportional/derivative control signal from position error and joint velocity, clips it to the MJCF actuator range, and calls mj_step to advance the actual dynamics. The logged angle is the resulting simulated joint position, not a generated copy of the target.



Name-based model access

mj_name2id locates the joint and actuator by name. actuator_trnid, jnt_qposadr and jnt_dofadr locate the correct coordinates; the code does not assume actuator indices equal generalized-position indices. The floating joint is removed only in the in-memory XML, leaving the source checkout untouched.



Measure a specific claim

RMSE is computed after the first second, avoiding the initial transient in the reference fixture. The summary reports the simplifications explicitly. Passing this test establishes that model loading, named actuation, stepping and measurement agree under these conditions. It provides no hardware gain recommendation or evidence of balancing, contact stability or real actuator bandwidth.



TROUBLESHOOTING

MuJoCo cannot load a mesh.
Confirm the full pinned repository checkout exists and is not a downloaded XML alone. prepare_xml resolves every mesh path to the model’s mesh directory before loading.

The named elbow actuator or 29-joint assertion fails.
Check the model path and pinned revision. The program intentionally rejects an incompatible model instead of reusing an unverified actuator index.

The viewer fails on macOS.
Use .venv/bin/mjpython for --viewer. The default headless run needs no viewer window and remains the reproducible test path.

The simulation succeeds but a free-floating model falls.
This fixture removes the floating-base joint and disables gravity/collisions. A balance controller and contact model are separate tasks; copying these gains to a free robot is not supported by this result.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-simulation

https://kamilszwed.com/courses/#/lesson/ut-g1-command-contract

https://kamilszwed.com/courses/#/lesson/ut-advanced-sim2sim

SOURCES

Unitree MuJoCo simulator
https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/readme.md
1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d

G1 29-DOF MuJoCo model
https://github.com/unitreerobotics/unitree_mujoco/blob/1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d/unitree_robots/g1/g1_29dof.xml
1eb6642e3f3fdfb7fb13a9794fd6a2dd93ea0e7d

MuJoCo 3.3.6 Python bindings
https://github.com/google-deepmind/mujoco/blob/3.3.6/doc/python.rst
3.3.6
