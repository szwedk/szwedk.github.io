# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-g1-elbow-simulation"
cd "$HOME/robot-academy/ut-g1-elbow-simulation"
cat > g1_elbow_sim.py <<'ACADEMY_FILE_0'
"""Actual MuJoCo elbow tracking on a fixed-base G1 model; no DDS or sockets."""
import argparse
import csv
import json
import math
import time
import xml.etree.ElementTree as ET
from pathlib import Path


def prepare_xml(path):
    root=ET.parse(path).getroot()
    compiler=root.find('compiler')
    mesh_dir=(path.parent/(compiler.get('meshdir','') if compiler is not None else '')).resolve()
    if compiler is not None:compiler.attrib.pop('meshdir',None)
    for mesh in root.findall('./asset/mesh'):
        mesh.set('file',str(mesh_dir/mesh.get('file')))
    removed=0
    for body in root.findall('.//body'):
        for joint in list(body):
            if joint.tag=='freejoint' or (joint.tag=='joint' and joint.get('type')=='free'):
                body.remove(joint);removed+=1
    if removed!=1:raise ValueError('Expected exactly one floating base in the pinned G1 model')
    return ET.tostring(root,encoding='unicode')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',default='vendor/unitree_mujoco/unitree_robots/g1/g1_29dof.xml')
    p.add_argument('--seconds',type=float,default=8);p.add_argument('--output',default='elbow-track.csv')
    p.add_argument('--viewer',action='store_true');p.add_argument('--self-test',action='store_true')
    a=p.parse_args()
    if not 0<a.seconds<=60:p.error('Use 0 < seconds <= 60')
    import mujoco
    import numpy as np
    model=mujoco.MjModel.from_xml_string(prepare_xml(Path(a.model).resolve()))
    model.opt.timestep=0.002
    # These deliberate simplifications make this an isolated actuator lesson.
    model.opt.gravity[:]=0;model.geom_contype[:]=0;model.geom_conaffinity[:]=0
    data=mujoco.MjData(model)
    joint=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,'right_elbow_joint')
    actuator=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_ACTUATOR,'right_elbow')
    if joint<0 or actuator<0:raise ValueError('Pinned model joint/actuator names not found')
    joints=model.actuator_trnid[:,0]
    qadr=model.jnt_qposadr[joints];vadr=model.jnt_dofadr[joints]
    target=np.zeros(model.nu);target[actuator]=0.5
    data.qpos[qadr]=target
    mujoco.mj_forward(model,data)
    rows=[];viewer=None
    if a.viewer:
        import mujoco.viewer
        viewer=mujoco.viewer.launch_passive(model,data)
    try:
        steps=int(a.seconds/model.opt.timestep)
        for i in range(steps):
            desired=0.5+0.15*math.sin(2*math.pi*0.25*data.time)
            target[actuator]=desired
            # Simulation-only controller; gains are not robot operating settings.
            torque=30*(target-data.qpos[qadr])-2*data.qvel[vadr]
            data.ctrl[:]=np.clip(torque,model.actuator_ctrlrange[:,0],model.actuator_ctrlrange[:,1])
            mujoco.mj_step(model,data)
            measured=float(data.qpos[model.jnt_qposadr[joint]])
            if not math.isfinite(measured):raise RuntimeError('Nonfinite simulated position')
            rows.append((float(data.time),desired,measured,desired-measured,float(data.ctrl[actuator])))
            if viewer:
                if not viewer.is_running():break
                if i%10==0:viewer.sync()
                time.sleep(model.opt.timestep)
    except KeyboardInterrupt:print('Simulation interrupted; saving completed samples.')
    finally:
        if viewer:viewer.close()
    if not rows:raise RuntimeError('No simulated samples')
    with Path(a.output).open('w',newline='') as handle:
        writer=csv.writer(handle);writer.writerow(['time_s','target_rad','measured_rad','error_rad','applied_control']);writer.writerows(rows)
    steady=[r for r in rows if r[0]>=min(1.0,a.seconds/2)]
    rmse=math.sqrt(sum(r[3]**2 for r in steady)/len(steady))
    summary=dict(mujoco_version=mujoco.__version__,samples=len(rows),rmse_rad=rmse,
                 minimum_measured_rad=min(r[2] for r in rows),maximum_measured_rad=max(r[2] for r in rows),
                 fixed_base=True,gravity_enabled=False,collisions_enabled=False,network_used=False)
    Path(a.output).with_suffix('.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))
    if a.self_test:
        assert model.nq==29 and model.nu==29
        assert rmse<0.08, 'Tracking exceeded this teaching fixture tolerance'
        assert summary['maximum_measured_rad']-summary['minimum_measured_rad']>0.05
        print('PASS: real MuJoCo dynamics advanced and named elbow tracked a varying target')
if __name__=='__main__':main()
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ut-g1-elbow-simulation'
)
