Record a bounded telemetry bag and verify finalization

A complete recorder wrapper that checks for a real synthetic sample, records only the course topic for a bounded interval, stops with SIGINT, and verifies bag metadata before reporting completion.

PLATFORM: ROS 2

ENVIRONMENT: Simulation

VALIDATION

Bash syntax and ShellCheck passed; ROS recording pending

bash -n and ShellCheck warning-level checks passed. The ROS bag CLI and timed SIGINT finalization were not executed on this macOS authoring host; use the included acceptance checks on Ubuntu/Jazzy.

REQUIREMENTS

Ubuntu 24.04 + ROS 2 Jazzy + GNU coreutils timeout

Jazzy rosbag2 CLI and GNU timeout

The companion publisher running for longer than the recording interval

Enough local disk space for this small synthetic stream

If Jazzy is not installed, complete recipe ros-jazzy-bootstrap and lesson ros-environment first.

CONFIGURATION

SECONDS = 15
Whole seconds from 1 through 300.

OUTPUT_DIRECTORY = bags/temperature-run-001
New bag directory; existing paths are refused.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ros-bag-recorder. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ros-bag-recorder"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  command -v timeout
  command -v ros2
  bash -n record_lab_bag.sh
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ros-bag-recorder"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  bash record_lab_bag.sh 15 "bags/temperature-$(date -u +%Y%m%dT%H%M%SZ)"
)

EXPECTED RESULT

The first-message check succeeds before recording begins.

The output bag directory is new; existing recordings are not overwritten.

A normal duration expiry sends SIGINT and permits up to ten additional seconds for shutdown.

metadata.yaml and ros2 bag info output exist after finalization.

Adjacent evidence files preserve the first message, endpoint QoS, recorder log, and bag summary.

Why preflight asks for a sample

A topic name in a graph is weaker evidence than an actual received message. The preflight uses an eight-second bound and best-effort subscription compatible with the teaching sensor stream. It also saves verbose endpoint information, which helps explain a later recording failure. This preflight is scoped to one known synthetic topic.



Understand timeout status

GNU timeout normally returns 124 when its duration expires, even if the child handles the requested signal. The wrapper treats that expected duration limit separately from other failures, then requires finalized metadata and a successful bag-info inspection. A force-killed or unfinalized recorder does not pass merely because the timer elapsed.



Replay in an isolated graph

Stop the live publisher before replaying the saved bag to avoid interleaved sources. Reuse the bag lesson’s inspection and replay procedure, with the exact output path printed by this script. This wrapper records only /academy/temperature; it does not capture a complete robot state, TF tree, camera dataset, or physical task.



Keep a publisher running while recording

Create and set up the ros-temperature-publisher recipe first. Start this block in one terminal, then immediately run the recorder in another. The 60-second publication window gives time for discovery, the sample preflight, and the 15-second recording. A zero message count still requires investigation even when metadata finalized.

(
  set -e
  cd "$HOME/robot-academy/ros-temperature-publisher"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 telemetry_publisher.py --rate-hz 10 --duration 60 --stamp-offset-ms 0
)

TROUBLESHOOTING

First-message check times out
Start the synthetic publisher in the same isolated graph and keep it running longer than the record interval.

Recorder exits 137 or another failure status
The process may have required forced termination or failed early. Inspect the recorder log; an incomplete recording is not success.

Existing output path is refused
Choose a new run identifier. The script intentionally preserves previous evidence.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ros-bags-evidence

https://kamilszwed.com/courses/#/lesson/linux-permissions-processes

https://kamilszwed.com/courses/#/lesson/ros-environment

SOURCES

ROS 2 Quality of Service settings
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Concepts/Intermediate/About-Quality-of-Service-Settings.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

Recording and playing back data
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Tutorials/Beginner-CLI-Tools/Recording-And-Playing-Back-Data/Recording-And-Playing-Back-Data.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

GNU Coreutils source manual
https://raw.githubusercontent.com/coreutils/coreutils/master/doc/coreutils.texi
Primary source manual retrieved 2026-09-29
