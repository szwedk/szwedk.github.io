# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ros-bag-recorder"
cd "$HOME/robot-academy/ros-bag-recorder"
cat > record_lab_bag.sh <<'ACADEMY_FILE_0'
#!/usr/bin/env bash
# Record only this course's synthetic telemetry, for a bounded duration.
set -euo pipefail
cd "$(dirname "$0")"
seconds=${1:-15}
output=${2:-"bags/temperature-$(date -u +%Y%m%dT%H%M%SZ)"}
case "$seconds" in
  ''|*[!0-9]*) printf '%s\n' 'Usage: bash record_lab_bag.sh SECONDS OUTPUT_DIRECTORY' >&2; exit 2 ;;
esac
if (( ${#seconds} > 3 )); then
  printf '%s\n' 'Duration must be between 1 and 300 seconds.' >&2
  exit 2
fi
seconds=$((10#$seconds))
if (( seconds < 1 || seconds > 300 )); then
  printf '%s\n' 'Duration must be between 1 and 300 seconds.' >&2
  exit 2
fi
if [[ -e "$output" ]]; then
  printf 'Refusing to overwrite existing recording: %s\n' "$output" >&2
  exit 2
fi
for tool in ros2 timeout; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    printf 'Missing command: %s. Use the documented Ubuntu/Jazzy environment.\n' "$tool" >&2
    exit 2
  fi
done
if [[ ${ROS_DISTRO:-} != jazzy ]]; then
  printf '%s\n' 'Source /opt/ros/jazzy/setup.bash in this shell before recording.' >&2
  exit 2
fi
# Match the isolated publisher and monitor recipes.
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
export ROS_DOMAIN_ID=42
export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
unset ROS_STATIC_PEERS
mkdir -p "$(dirname "$output")"
printf '%s\n' 'Checking for one synthetic temperature message (8 second limit).'
timeout --signal=INT --kill-after=2s 8s ros2 topic echo /academy/temperature sensor_msgs/msg/Temperature --once --qos-reliability best_effort >"$output.first-message.txt"
ros2 topic info /academy/temperature --verbose >"$output.endpoints.txt"
printf 'Recording for %s seconds to %s\n' "$seconds" "$output"
set +e
timeout --signal=INT --kill-after=10s "${seconds}s" ros2 bag record -o "$output" /academy/temperature >"$output.recorder.log" 2>&1
record_status=$?
set -e
if [[ "$record_status" != 0 && "$record_status" != 124 ]]; then
  printf 'Recorder failed with status %s; inspect %s.recorder.log\n' "$record_status" "$output" >&2
  exit "$record_status"
fi
if [[ ! -f "$output/metadata.yaml" ]]; then
  printf '%s\n' 'Recording did not finalize metadata; do not report it as complete.' >&2
  exit 1
fi
ros2 bag info "$output" >"$output.info.txt"
cat "$output.info.txt"
printf 'Recording finalized. Inspect with: ros2 bag info %q\n' "$output"
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ros-bag-recorder'
)
