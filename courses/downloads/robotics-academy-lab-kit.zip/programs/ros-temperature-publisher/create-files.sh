# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ros-temperature-publisher"
cd "$HOME/robot-academy/ros-temperature-publisher"
cat > telemetry_publisher.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Publish synthetic sensor_msgs/Temperature samples; no hardware access."""
import argparse
import math
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import qos_profile_sensor_data
from rclpy.utilities import remove_ros_args
from sensor_msgs.msg import Temperature


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise argparse.ArgumentTypeError("a finite number is required")
    return result


class SyntheticTemperature(Node):
    def __init__(self, args):
        super().__init__("academy_temperature_source")
        self.args = args
        self.started = time.monotonic()
        self.scheduled = 0
        self.published = 0
        self.skipped = 0
        self.publisher = self.create_publisher(Temperature, args.topic, qos_profile_sensor_data)
        self.timer = self.create_timer(1.0 / args.rate_hz, self.publish_sample)
        self.get_logger().info(f"Synthetic source on {args.topic}; no physical sensor is used.")

    def publish_sample(self):
        self.scheduled += 1
        if self.args.drop_every and self.scheduled % self.args.drop_every == 0:
            self.skipped += 1
            return
        stamp_ns = self.get_clock().now().nanoseconds - round(self.args.stamp_offset_ms * 1_000_000)
        if stamp_ns < 0:
            self.skipped += 1
            return  # ROS simulation time has not yet advanced past the requested offset.
        message = Temperature()
        message.header.stamp.sec, message.header.stamp.nanosec = divmod(stamp_ns, 1_000_000_000)
        message.header.frame_id = self.args.frame
        message.temperature = 20.0 + math.sin((time.monotonic() - self.started) * 0.5)
        message.variance = 0.0  # Interface convention: variance unknown, not perfect certainty.
        self.publisher.publish(message)
        self.published += 1
        if self.published == 1 or self.published % max(1, round(self.args.rate_hz)) == 0:
            self.get_logger().info(f"published={self.published} temperature_c={message.temperature:.3f}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic", default="/academy/temperature")
    parser.add_argument("--frame", default="lab_sensor")
    parser.add_argument("--rate-hz", type=finite_float, default=10.0)
    parser.add_argument("--duration", type=finite_float, default=20.0, help="Host elapsed seconds, 0–600 exclusive of zero")
    parser.add_argument("--stamp-offset-ms", type=finite_float, default=0.0,
                        help="Positive makes samples old; negative creates future stamps for a failure test.")
    parser.add_argument("--drop-every", type=int, default=0, help="Skip every Nth scheduled sample; zero disables.")
    args = parser.parse_args(remove_ros_args(args=sys.argv)[1:])
    if not 0.1 <= args.rate_hz <= 200:
        parser.error("--rate-hz must be between 0.1 and 200")
    if not 0 < args.duration <= 600:
        parser.error("--duration must be positive and at most 600")
    if args.drop_every < 0 or abs(args.stamp_offset_ms) > 60000:
        parser.error("drop interval must be nonnegative and timestamp offset within ±60000 ms")
    if not args.topic.startswith("/academy/"):
        parser.error("this teaching publisher restricts topics to /academy/")
    rclpy.init(args=sys.argv)
    node = SyntheticTemperature(args)
    deadline = time.monotonic() + args.duration
    try:
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        print(f"Finished: published={node.published}, scheduled={node.scheduled}, skipped={node.skipped}")
        node.destroy_node()
        rclpy.try_shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ros-temperature-publisher'
)
