Publish timestamped synthetic ROS 2 telemetry

A complete rclpy node with a real sensor_msgs/Temperature interface, source timestamps, configurable rate, bounded run time, and controlled stale/future/drop fault injection.

PLATFORM: ROS 2

ENVIRONMENT: Simulation

VALIDATION

Syntax checked; ROS runtime pending

Complete Python source parsed successfully and API/interface usage checked against official Jazzy sources. This macOS authoring host does not run Jazzy, so publication rate and graph behavior are learner/runtime acceptance tests, not claimed executed results.

REQUIREMENTS

Ubuntu 24.04 + ROS 2 Jazzy; default Fast DDS middleware

Official Jazzy desktop or equivalent rclpy + sensor_msgs installation

Run in a Bash terminal inside Ubuntu; do not use an unrelated pip virtual environment

Start the companion freshness monitor in another terminal to observe behavior

If Jazzy is not installed, complete recipe ros-jazzy-bootstrap and lesson ros-environment first.

CONFIGURATION

--rate-hz = 10
Requested publication frequency, 0.1–200 Hz; observed frequency must be measured.

--duration = 20
Host elapsed seconds before cleanup, maximum 600.

--stamp-offset-ms = 250
Positive makes data old; negative creates future stamps for an explicit test.

--drop-every = 5
Skip every fifth scheduled publication; zero disables.

--frame = lab_sensor
Message location identifier; must match the monitor’s expectation.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ros-temperature-publisher. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ros-temperature-publisher"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 -c "import rclpy; from sensor_msgs.msg import Temperature; print('ROS imports ready')"
  python3 -m py_compile telemetry_publisher.py
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ros-temperature-publisher"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 telemetry_publisher.py --rate-hz 10 --duration 20 --stamp-offset-ms 0
)

EXPECTED RESULT

The node publishes approximately 10 synthetic temperature samples per second for 20 host elapsed seconds.

The topic is /academy/temperature, the location frame is lab_sensor, and temperature stays between 19 and 21 degrees Celsius.

The standard Temperature variance field is zero to mean unknown variance.

The final console summary reports scheduled, published, and skipped callbacks; actual counts depend on scheduling.

What is being published

This is invented temperature data for learning the communication contract. The message type carries a timestamp, location frame, Celsius value, and variance. The node uses the standard sensor-data QoS profile, which the companion monitor also uses. There is no vendor SDK, physical sensor, motor command, or background hardware connection.



A complete two-terminal exercise

Create and set up this recipe and the ROS freshness-monitor recipe. Start the monitor first in one terminal, then run this publisher in another. Each Run block sources Jazzy and establishes the same isolated localhost graph. Compare the publisher count with received count cautiously: discovery startup, duration differences, and best-effort delivery mean exact equality is not guaranteed.



Inject one fault at a time

Set --stamp-offset-ms 250 to make measurements at least 250 ms old; a monitor with a 200 ms threshold should reject them as stale. A negative offset creates future timestamps and tests clock-assumption rejection. Use --drop-every 5 to skip every fifth scheduled callback. Restore the baseline between experiments so the causal difference stays clear.



Clocks and completion

Measurement headers use the node’s ROS clock. The program’s maximum run duration uses the host monotonic clock, so it remains bounded even if simulation time pauses. A publication callback is still subject to executor scheduling. Treat measured frequency and accepted freshness as observations rather than guarantees derived from the configured timer period.



Copyable stale-sample trial

Restart the companion monitor before this trial and save its report under a new name. This deliberately adds 250 ms of timestamp age; with the standard 200 ms threshold, received samples should be rejected as stale. The transport still carries messages.

(
  set -e
  cd "$HOME/robot-academy/ros-temperature-publisher"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 telemetry_publisher.py --rate-hz 10 --duration 20 --stamp-offset-ms 250
)

TROUBLESHOOTING

rclpy import fails
Use the system Python associated with the sourced Jazzy installation. This recipe intentionally does not pip-install ROS libraries.

No samples reach the monitor
Run both recipes with the same domain 42, Fast DDS middleware, localhost discovery, topic, and frame. Both use sensor-data QoS.

Simulation time is paused
The publication timer may pause with ROS time, while the host-elapsed duration still ends the program. Start /clock if intentionally using use_sim_time.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ros-interfaces-topics

https://kamilszwed.com/courses/#/lesson/ros-dds-qos

https://kamilszwed.com/courses/#/lesson/ros-time-executors

https://kamilszwed.com/courses/#/lesson/ros-environment

SOURCES

Writing a Python publisher and subscriber
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Tutorials/Beginner-Client-Libraries/Writing-A-Simple-Py-Publisher-And-Subscriber.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

ROS 2 Quality of Service settings
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Concepts/Intermediate/About-Quality-of-Service-Settings.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

sensor_msgs Temperature interface
https://raw.githubusercontent.com/ros2/common_interfaces/jazzy/sensor_msgs/msg/Temperature.msg
Primary documentation retrieved 2026-09-29

rclpy clock API
https://raw.githubusercontent.com/ros2/rclpy/jazzy/rclpy/rclpy/clock.py
Primary documentation retrieved 2026-09-29
