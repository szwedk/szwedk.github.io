# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-go1-battery-report"
cd "$HOME/robot-academy/ut-go1-battery-report"
cat > go1_battery.py <<'ACADEMY_FILE_0'
"""Summarize Go1 receive-only CSV battery and thermal observations."""
import argparse
import csv
import json
from pathlib import Path


def summarize(rows,min_soc=20,temperature_warning=70):
    rows=list(rows)
    if not rows:raise ValueError('No telemetry rows to analyze')
    alerts=[];soc=[];currents=[];temperatures=[];spreads=[]
    for n,row in enumerate(rows,1):
        charge=int(row['soc_percent']);soc.append(charge);currents.append(float(row['current_mA'])/1000)
        if not 0<=charge<=100:alerts.append(dict(row=n,kind='INVALID_SOC',value=charge))
        elif charge<min_soc:alerts.append(dict(row=n,kind='PROJECT_LOW_SOC',value=charge))
        temps=[int(row[f'temperature{i}']) for i in range(12)];temperatures+=temps
        if max(temps)>=temperature_warning:alerts.append(dict(row=n,kind='PROJECT_TEMPERATURE_WARNING',value=max(temps)))
        cells=[int(row[f'cell{i}_mV']) for i in range(10)]
        # Zero/missing channels are unavailable, not zero-volt measured cells.
        valid=[v for v in cells if v>0]
        spreads.append(max(valid)-min(valid) if len(valid)>1 else None)
    return dict(records=len(rows),minimum_soc_percent=min(soc),maximum_abs_current_A=max(abs(x) for x in currents),
                signed_current_A=dict(minimum=min(currents),maximum=max(currents)),maximum_temperature=max(temperatures),
                maximum_available_cell_spread_mV=max((x for x in spreads if x is not None),default=None),alerts=alerts,
                note='Thresholds are project review flags, not vendor charge/discharge limits. Current sign is preserved without inferring firmware sign semantics.')


def fixture():
    d=dict(soc_percent='80',current_mA='-1000')
    d.update({f'temperature{i}':'30' for i in range(12)})
    d.update({f'cell{i}_mV':'4000' for i in range(10)})
    return d


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input');p.add_argument('--mock',action='store_true')
    p.add_argument('--self-test',action='store_true');p.add_argument('--min-soc',type=int,default=20)
    p.add_argument('--temperature-warning',type=int,default=70);p.add_argument('--output',default='go1-health.json');a=p.parse_args()
    if a.self_test:
        d=fixture();assert summarize([d])['maximum_abs_current_A']==1
        d['soc_percent']='10';d['temperature0']='80';assert len(summarize([d])['alerts'])==2
        d['cell0_mV']='0';assert summarize([d])['maximum_available_cell_spread_mV']==0
        print('PASS: mA/A conversion, project thresholds and unavailable cell handling');return
    if a.input:
        with open(a.input,newline='') as h:result=summarize(csv.DictReader(h),a.min_soc,a.temperature_warning)
    else:result=summarize([fixture()],a.min_soc,a.temperature_warning)
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ut-go1-battery-report'
)
