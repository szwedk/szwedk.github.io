Analyze Go1 battery and motor temperatures

Turn the legacy recorder CSV into a reviewable battery/thermal report with explicit unit conversion, unavailable cell handling and adjustable project thresholds.

PLATFORM: Unitree Go1

ENVIRONMENT: Offline telemetry analysis

VALIDATION

Offline tests passed

Unit-conversion and flag self-tests passed. The report also successfully analyzed 100 CSV rows emitted by the compiled C++ fixture. No physical battery measurements were taken.

REQUIREMENTS

Python 3.10 or 3.11; no third-party packages.

Optional input: CSV produced by the Go1 UDP recorder recipe. Its legacy BmsState format is different from G1 HG LowState.

CONFIGURATION

--min-soc = 20
Project low-charge review threshold, not a vendor discharge limit.

--temperature-warning = 70
Project motor-temperature review flag. Confirm units and hardware operating guidance.

--input = go1-live.csv
CSV from the matching legacy receive-only program; omission uses a fixture.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-go1-battery-report. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-go1-battery-report"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-go1-battery-report"
  .venv/bin/python go1_battery.py --self-test
  .venv/bin/python go1_battery.py --mock --output go1-health.json
  cat go1-health.json
)

# Analyze an actual recorder file by setting an existing local path:
# (
#   set -e
#   cd "$HOME/robot-academy/ut-go1-battery-report"
#   CAPTURE="$HOME/robot-academy/ut-go1-udp-recorder/go1-live.csv"
#   .venv/bin/python go1_battery.py --input "$CAPTURE" --output go1-live-health.json
# )

EXPECTED RESULT

The fixture reports 80% SOC, 1 A maximum absolute current, -1 A signed current, 30-degree maximum temperature and zero available-cell spread.

The self-test verifies mA-to-A conversion and deliberately low SOC/high temperature alerts.

Zero cell slots are excluded from spread calculation; a single available cell does not establish a spread.

Read the unit conversion

Each row converts current_mA / 1000 to amperes. Cell values remain millivolts, matching the audited legacy header. SOC is checked against 0–100 before comparison with --min-soc. These simple operations are intentionally visible so an unexpected unit can be traced back to the capture and header.



Make reports comparable

Store the original capture and the CLI settings alongside the JSON. The script reports peak motor temperature among the first twelve slots and the largest spread among available cell values, with row-indexed flags. Comparing two runs requires the same data layout and review thresholds; a green report only means those checks did not fire.



TROUBLESHOOTING

The cell spread looks lower after some cells disappear.
The report only compares available nonzero slots. Inspect the original CSV and delivered battery topology; missing data can reduce the set being compared. This metric is not a battery-health diagnosis.

The current is negative.
The source unit is verified, but sign interpretation is firmware-dependent. The report keeps signed current and absolute maximum separately; it does not label charge versus discharge without that contract.

A temperature flag disagrees with the robot warning.
The script uses your project threshold. Firmware protections can apply different filtering, limits and time behavior; use the vendor operating guidance for decisions.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-go1-udp-contract

https://kamilszwed.com/courses/#/lesson/ut-go1-capstone

SOURCES

Go1 command and state structures
https://github.com/unitreerobotics/unitree_legged_sdk/blob/4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1/include/unitree_legged_sdk/comm.h
4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1
