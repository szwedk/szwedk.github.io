# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-g1-health-report"
cd "$HOME/robot-academy/ut-g1-health-report"
cat > reader_common.py <<'ACADEMY_FILE_0'
"""Shared receive-only SDK2 utilities; importing this module never opens DDS."""
import argparse
import math
import queue
import struct
import time
from types import SimpleNamespace as NS


def add_reader_args(parser, default_topic):
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--live', action='store_true', help='Subscribe to a configured DDS endpoint')
    group.add_argument('--mock', action='store_true', help='Use synthetic data (default)')
    parser.add_argument('--interface', default='lo')
    parser.add_argument('--domain', type=int, default=1)
    parser.add_argument('--topic', default=default_topic)
    parser.add_argument('--seconds', type=float, default=10.0)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--self-test', action='store_true')


def check_args(args):
    if not 0 < args.seconds <= 3600 or not 1 <= args.samples <= 1_000_000:
        raise ValueError('Use 0 < seconds <= 3600 and 1 <= samples <= 1000000')
    if args.domain < 0:
        raise ValueError('Domain must be nonnegative')


def motor_fixture(index, t):
    return NS(mode=1, q=0.02*math.sin(t+index/10), dq=0.02*math.cos(t+index/10),
              ddq=0.0, tau_est=0.1, temperature=[30+index%3, 31+index%3],
              vol=52.0, sensor=[0, 0], motorstate=0, reserve=[0]*4)


def fixture(kind, i):
    t = i*0.02
    imu = NS(quaternion=[1.0, 0.0, 0.0, 0.0], gyroscope=[0.0]*3,
             accelerometer=[0.0, 0.0, 9.81], rpy=[0.0]*3, temperature=30)
    if kind == 'g1':
        remote = bytearray(40)
        remote[2] = 1 if i%20 < 10 else 0  # R1
        remote[3] = 1 if i%30 < 15 else 0  # A
        struct.pack_into('<fffff', remote, 4, 0.1*math.sin(t), 0.0, 0.0, 0.0, -0.2)
        return NS(version=[1, 0], mode_pr=0, mode_machine=0, tick=i*20,
                  motor_state=[motor_fixture(j, t) for j in range(35)],
                  imu_state=imu, wireless_remote=list(remote), reserve=[0]*4, crc=0)
    if kind == 'dex3':
        sensors = [NS(pressure=[float(j+k) for k in range(12)], temperature=[25.0]*12,
                      lost=0, reserve=0) for j in range(2)]
        return NS(motor_state=[motor_fixture(j, t) for j in range(7)],
                  press_sensor_state=sensors, imu_state=imu,
                  power_v=48.0, power_a=0.15, system_v=5.0, device_v=3.3,
                  error=[0, 0], reserve=[0, 0])
    raise ValueError('Unknown fixture kind: '+kind)


def stream(kind, args, stats):
    """Yield receive-time/message pairs; callback queue is bounded and counted."""
    check_args(args)
    stats.update(source='live' if args.live else 'synthetic', received=0, dropped=0)
    if not args.live:
        for i in range(args.samples):
            stats['received'] += 1
            yield i*0.02, fixture(kind, i)
        return
    # These are the exact audited vendor imports. No publisher is imported.
    from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
    from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_, HandState_
    ChannelFactoryInitialize(args.domain, args.interface)
    inbox = queue.Queue(maxsize=256)
    started = time.monotonic()
    def receive(message):
        stats['received'] += 1
        try:
            inbox.put_nowait((time.monotonic()-started, message))
        except queue.Full:
            stats['dropped'] += 1
    subscriber = ChannelSubscriber(args.topic, LowState_ if kind == 'g1' else HandState_)
    subscriber.Init(receive, 0)  # Our own bounded queue retains receive timestamps.
    try:
        while time.monotonic()-started < args.seconds:
            try:
                yield inbox.get(timeout=min(0.2, max(0.001, args.seconds-(time.monotonic()-started))))
            except queue.Empty:
                pass
    finally:
        subscriber.Close()
ACADEMY_FILE_0
cat > g1_record.py <<'ACADEMY_FILE_1'
"""Record G1 HG state to CSV + JSONL. No commands or motion-mode changes."""
import argparse
import csv
import json
import math
from pathlib import Path
from reader_common import add_reader_args, fixture, stream

G1_29_PR = ['left_hip_pitch','left_hip_roll','left_hip_yaw','left_knee',
 'left_ankle_pitch','left_ankle_roll','right_hip_pitch','right_hip_roll','right_hip_yaw',
 'right_knee','right_ankle_pitch','right_ankle_roll','waist_yaw','waist_roll','waist_pitch',
 'left_shoulder_pitch','left_shoulder_roll','left_shoulder_yaw','left_elbow','left_wrist_roll',
 'left_wrist_pitch','left_wrist_yaw','right_shoulder_pitch','right_shoulder_roll',
 'right_shoulder_yaw','right_elbow','right_wrist_roll','right_wrist_pitch','right_wrist_yaw']


def record(message, received_s, mapping='raw'):
    if mapping == 'g1-29-pr' and int(message.mode_pr) != 0:
        raise ValueError('Named PR map cannot label a sample in AB coordinate mode')
    motors = []
    for index, motor in enumerate(message.motor_state):
        name = G1_29_PR[index] if mapping == 'g1-29-pr' and index < 29 else 'slot_'+str(index)
        motors.append(dict(index=index, name=name, q=float(motor.q), dq=float(motor.dq),
                           tau_est=float(motor.tau_est), temperature=list(motor.temperature),
                           voltage=float(motor.vol), status=int(motor.motorstate)))
    return dict(received_s=received_s, tick=int(message.tick), mode_pr=int(message.mode_pr),
                mode_machine=int(message.mode_machine), quaternion=list(message.imu_state.quaternion),
                gyroscope=list(message.imu_state.gyroscope), motors=motors)


def self_test():
    row = record(fixture('g1', 0), 0.0, 'g1-29-pr')
    assert len(row['motors']) == 35 and row['motors'][25]['name'] == 'right_elbow'
    bad = fixture('g1', 0); bad.mode_pr = 1
    try: record(bad, 0.0, 'g1-29-pr')
    except ValueError: pass
    else: raise AssertionError('AB mode accepted as PR')
    print('PASS: 35 raw slots retained; 29-joint labels checked; wrong coordinate mode rejected')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    add_reader_args(p, 'rt/lowstate')
    p.add_argument('--map', choices=['raw','g1-29-pr'], default='raw')
    p.add_argument('--output', default='g1-state')
    args = p.parse_args()
    if args.self_test: self_test(); return 0
    prefix = Path(args.output); prefix.parent.mkdir(parents=True, exist_ok=True)
    stats = {}; written = rejected = 0
    try:
        with prefix.with_suffix('.jsonl').open('w') as jf, prefix.with_suffix('.csv').open('w', newline='') as cf:
            writer = csv.writer(cf)
            writer.writerow(['received_s','tick','mode_pr','mode_machine','index','joint','q_rad',
                             'dq_rad_s','tau_est','temperature_0','temperature_1','voltage','status'])
            try:
                for received, message in stream('g1', args, stats):
                    try:
                        row = record(message, received, args.map)
                        encoded = json.dumps(row, allow_nan=False)
                    except (ValueError, TypeError, AttributeError) as error:
                        rejected += 1
                        print('Rejected sample:', error)
                        continue
                    jf.write(encoded+'\n')
                    for m in row['motors']:
                        writer.writerow([received,row['tick'],row['mode_pr'],row['mode_machine'],
                                         m['index'],m['name'],m['q'],m['dq'],m['tau_est'],
                                         *m['temperature'],m['voltage'],m['status']])
                    written += 1
            except KeyboardInterrupt:
                print('Interrupted; closing files and subscriber.')
    finally:
        summary = dict(stats, written=written, rejected=rejected, mapping=args.map)
        prefix.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary))
    return 0 if written else 2

if __name__ == '__main__':
    raise SystemExit(main())
ACADEMY_FILE_1
cat > g1_health.py <<'ACADEMY_FILE_2'
"""Analyze G1 recorder output without claiming firmware-specific fault meanings."""
import argparse
import copy
import json
import math
import statistics
from pathlib import Path
from reader_common import fixture
from g1_record import record


def analyze(rows, max_gap=0.1, temperature_warning=70.0):
    problems = []; gaps = []; temperatures = []; previous = None
    counts = set(); records = 0
    for line, row in enumerate(rows, 1):
        records += 1
        t = float(row['received_s'])
        if previous is not None:
            gap = t-previous; gaps.append(gap)
            if gap <= 0: problems.append(dict(line=line, kind='NONMONOTONIC_RECEIVE_TIME'))
            elif gap > max_gap: problems.append(dict(line=line, kind='ARRIVAL_GAP', seconds=gap))
        previous = t
        counts.add(len(row['motors']))
        q = row['quaternion']; norm = math.sqrt(sum(float(v)**2 for v in q))
        if len(q)!=4 or not math.isfinite(norm) or abs(norm-1)>0.05:
            problems.append(dict(line=line, kind='QUATERNION_NORM'))
        for motor in row['motors']:
            if not all(math.isfinite(float(motor[k])) for k in ['q','dq','tau_est','voltage']):
                problems.append(dict(line=line, kind='NONFINITE_MOTOR', index=motor['index']))
            for temp in motor['temperature']:
                if math.isfinite(float(temp)):
                    temperatures.append(float(temp))
                    if temp >= temperature_warning:
                        problems.append(dict(line=line, kind='PROJECT_TEMPERATURE_WARNING', index=motor['index'], value=temp))
            if motor['status']:
                problems.append(dict(line=line, kind='NONZERO_RAW_STATUS', index=motor['index'], raw=motor['status']))
    if not records:
        raise ValueError('No telemetry rows to analyze')
    return dict(records=records, motor_slot_counts=sorted(counts),
                median_arrival_gap_s=statistics.median(gaps) if gaps else None,
                maximum_arrival_gap_s=max(gaps) if gaps else None,
                maximum_temperature=max(temperatures) if temperatures else None,
                thresholds=dict(maximum_gap_s=max_gap, project_temperature_warning=temperature_warning),
                problems=problems,
                limitations=['Arrival gaps include host effects; they do not locate packet loss.',
                             'Temperature threshold is a project warning, not a vendor operating limit.',
                             'HG LowState does not expose a battery SOC field; motor voltage is not SOC.'])


def mock_rows():
    return [record(fixture('g1',i),i*0.02) for i in range(10)]


def self_test():
    rows = mock_rows(); assert not analyze(rows)['problems']
    rows[4]['received_s'] = rows[3]['received_s']
    rows[5]['motors'][0]['temperature'][0] = 90
    rows[6]['quaternion'] = [2,0,0,0]
    kinds={p['kind'] for p in analyze(rows)['problems']}
    assert {'NONMONOTONIC_RECEIVE_TIME','PROJECT_TEMPERATURE_WARNING','QUATERNION_NORM'} <= kinds
    print('PASS: valid fixture plus timestamp, temperature and quaternion failures')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input'); p.add_argument('--mock',action='store_true')
    p.add_argument('--self-test',action='store_true'); p.add_argument('--output',default='g1-health.json')
    p.add_argument('--max-gap',type=float,default=0.1); p.add_argument('--temperature-warning',type=float,default=70)
    a=p.parse_args()
    if a.self_test: self_test();return
    if a.max_gap<=0: p.error('--max-gap must be positive')
    if a.input:
        with open(a.input) as handle: result=analyze((json.loads(x) for x in handle if x.strip()),a.max_gap,a.temperature_warning)
    else: result=analyze(mock_rows(),a.max_gap,a.temperature_warning)
    Path(a.output).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='problems'}));print('Problem records:',len(result['problems']))
if __name__=='__main__':main()
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/ut-g1-health-report'
)
