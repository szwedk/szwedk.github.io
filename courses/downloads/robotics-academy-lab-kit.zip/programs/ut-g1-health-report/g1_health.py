"""Analyze G1 recorder output without claiming firmware-specific fault meanings."""
import argparse
import copy
import json
import math
import statistics
from pathlib import Path
from reader_common import fixture
from g1_record import record


def analyze(rows, max_gap=0.1, temperature_warning=70.0):
    problems = []; gaps = []; temperatures = []; previous = None
    counts = set(); records = 0
    for line, row in enumerate(rows, 1):
        records += 1
        t = float(row['received_s'])
        if previous is not None:
            gap = t-previous; gaps.append(gap)
            if gap <= 0: problems.append(dict(line=line, kind='NONMONOTONIC_RECEIVE_TIME'))
            elif gap > max_gap: problems.append(dict(line=line, kind='ARRIVAL_GAP', seconds=gap))
        previous = t
        counts.add(len(row['motors']))
        q = row['quaternion']; norm = math.sqrt(sum(float(v)**2 for v in q))
        if len(q)!=4 or not math.isfinite(norm) or abs(norm-1)>0.05:
            problems.append(dict(line=line, kind='QUATERNION_NORM'))
        for motor in row['motors']:
            if not all(math.isfinite(float(motor[k])) for k in ['q','dq','tau_est','voltage']):
                problems.append(dict(line=line, kind='NONFINITE_MOTOR', index=motor['index']))
            for temp in motor['temperature']:
                if math.isfinite(float(temp)):
                    temperatures.append(float(temp))
                    if temp >= temperature_warning:
                        problems.append(dict(line=line, kind='PROJECT_TEMPERATURE_WARNING', index=motor['index'], value=temp))
            if motor['status']:
                problems.append(dict(line=line, kind='NONZERO_RAW_STATUS', index=motor['index'], raw=motor['status']))
    if not records:
        raise ValueError('No telemetry rows to analyze')
    return dict(records=records, motor_slot_counts=sorted(counts),
                median_arrival_gap_s=statistics.median(gaps) if gaps else None,
                maximum_arrival_gap_s=max(gaps) if gaps else None,
                maximum_temperature=max(temperatures) if temperatures else None,
                thresholds=dict(maximum_gap_s=max_gap, project_temperature_warning=temperature_warning),
                problems=problems,
                limitations=['Arrival gaps include host effects; they do not locate packet loss.',
                             'Temperature threshold is a project warning, not a vendor operating limit.',
                             'HG LowState does not expose a battery SOC field; motor voltage is not SOC.'])


def mock_rows():
    return [record(fixture('g1',i),i*0.02) for i in range(10)]


def self_test():
    rows = mock_rows(); assert not analyze(rows)['problems']
    rows[4]['received_s'] = rows[3]['received_s']
    rows[5]['motors'][0]['temperature'][0] = 90
    rows[6]['quaternion'] = [2,0,0,0]
    kinds={p['kind'] for p in analyze(rows)['problems']}
    assert {'NONMONOTONIC_RECEIVE_TIME','PROJECT_TEMPERATURE_WARNING','QUATERNION_NORM'} <= kinds
    print('PASS: valid fixture plus timestamp, temperature and quaternion failures')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input'); p.add_argument('--mock',action='store_true')
    p.add_argument('--self-test',action='store_true'); p.add_argument('--output',default='g1-health.json')
    p.add_argument('--max-gap',type=float,default=0.1); p.add_argument('--temperature-warning',type=float,default=70)
    a=p.parse_args()
    if a.self_test: self_test();return
    if a.max_gap<=0: p.error('--max-gap must be positive')
    if a.input:
        with open(a.input) as handle: result=analyze((json.loads(x) for x in handle if x.strip()),a.max_gap,a.temperature_warning)
    else: result=analyze(mock_rows(),a.max_gap,a.temperature_warning)
    Path(a.output).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='problems'}));print('Problem records:',len(result['problems']))
if __name__=='__main__':main()
