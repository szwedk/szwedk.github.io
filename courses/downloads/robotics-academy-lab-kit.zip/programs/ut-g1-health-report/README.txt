Find G1 timing, quaternion and joint-state anomalies

Generate a capture, analyze its arrival timing and joint observations, and produce a structured anomaly report that preserves the limits of the data.

PLATFORM: Unitree G1

ENVIRONMENT: Offline telemetry analysis

VALIDATION

Offline tests passed

Python syntax, embedded self-test and synthetic run passed on macOS arm64 with Python 3.11. Live transport and physical robot behavior were not tested.

REQUIREMENTS

Python 3.10 or 3.11; standard library only.

The included fixture matches the recorder JSONL contract. An optional --input file must come from the matching G1 SDK2 or ROS 2 recorder.

CONFIGURATION

--input = g1-state.jsonl
JSONL from the included recorder. Omitting this option analyzes the small built-in fixture.

--max-gap = 0.1
Project arrival-gap review threshold in seconds.

--temperature-warning = 70
Project review flag applied to raw motor temperature values; verify units and acceptable limits for your hardware.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-g1-health-report. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-g1-health-report"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-g1-health-report"
  .venv/bin/python g1_health.py --self-test
  .venv/bin/python g1_record.py --mock --samples 100 --output g1-state
  .venv/bin/python g1_health.py --input g1-state.jsonl --output g1-health.json
  cat g1-health.json
)

EXPECTED RESULT

The clean fixture has 100 records, 35 motor slots, a median arrival gap near 0.02 seconds and zero anomaly records.

The self-test injects a duplicate receive timestamp, a 90-degree temperature observation and a quaternion of norm two, and verifies detection.

The report includes explicit analysis thresholds. It never invents a battery SOC from motor voltage.

What each check can establish

The analyzer checks arrival time monotonicity, gaps above --max-gap, quaternion length and norm, finite motor values, two motor temperature channels, and raw nonzero status. A near-unit quaternion passes a consistency check, but this does not prove its coordinate convention is correct. A timing alert identifies a data-quality question, not a network diagnosis.



Thresholds belong to the experiment

The default 0.1-second gap and 70-degree warning are project review settings. They are not Unitree operating limits or a substitute for firmware protections. Run two reports with different --max-gap values and compare which records change classification. Keep these settings with the resulting JSON so later comparisons use the same rule.



TROUBLESHOOTING

A large arrival gap appears during high CPU or disk load.
Compare it with the recorder dropped count and host load. Arrival timing includes scheduling, transport and write-side effects; this report does not identify which component caused the gap.

A nonzero raw status is reported without a fault name.
Decode that integer only against the exact firmware fault table. This tool preserves it and flags it for review instead of assigning a guessed meaning.

The report has no battery charge percentage.
The audited HG LowState schema does not contain SOC. Use a separately verified battery interface for that edition; voltage-to-SOC conversion is not implemented.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-state

https://kamilszwed.com/courses/#/lesson/ut-g1-timing

https://kamilszwed.com/courses/#/lesson/ut-advanced-data

SOURCES

G1 LowState wire schema
https://github.com/unitreerobotics/unitree_ros2/blob/668d1ec5a05d1c38d3306bdca7d59f2ba3581a88/cyclonedds_ws/src/unitree/unitree_hg/msg/LowState.msg
668d1ec5a05d1c38d3306bdca7d59f2ba3581a88

HG Python MotorState generated fields
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/unitree_sdk2py/idl/unitree_hg/msg/dds_/_MotorState_.py
814556d15970dd2ecf1c9984e845ca02ab07e206
