"""Pure message-validation rules; importable without ROS for offline tests."""
import math


def assess_sample(temperature_c, stamp_ns, now_ns, frame, expected_frame, max_age_ms):
    if not all(math.isfinite(value) for value in (temperature_c, stamp_ns, now_ns, max_age_ms)):
        return "non_finite", None
    if max_age_ms < 0 or stamp_ns < 0 or now_ns < 0:
        return "invalid_time", None
    age_ms = (now_ns - stamp_ns) / 1_000_000
    if frame != expected_frame:
        return "frame_mismatch", age_ms
    if age_ms < 0:
        return "future_stamp", age_ms
    if age_ms > max_age_ms:
        return "stale", age_ms
    return "valid", age_ms
