#!/usr/bin/env python3
"""Read synthetic ROS temperature; reject stale/invalid samples; never publish commands."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import qos_profile_sensor_data
from rclpy.utilities import remove_ros_args
from sensor_msgs.msg import Temperature
from telemetry_rules import assess_sample


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise argparse.ArgumentTypeError("a finite number is required")
    return result


class TemperatureMonitor(Node):
    def __init__(self, args):
        super().__init__("academy_temperature_monitor")
        self.args = args
        self.started = time.monotonic()
        self.last_received = None
        self.received = 0
        self.accepted = 0
        self.rejected = Counter()
        self.max_accepted_age_ms = None
        self.state = "waiting"
        self.subscription = self.create_subscription(
            Temperature, args.topic, self.on_sample, qos_profile_sensor_data)
        self.get_logger().info(f"Reading {args.topic}; max age {args.max_age_ms} ms; no command output.")

    def change_state(self, state):
        if state != self.state:
            self.state = state
            self.get_logger().info("state=" + state)

    def on_sample(self, message):
        self.received += 1
        self.last_received = time.monotonic()
        stamp_ns = message.header.stamp.sec * 1_000_000_000 + message.header.stamp.nanosec
        reason, age_ms = assess_sample(message.temperature, stamp_ns,
                                      self.get_clock().now().nanoseconds,
                                      message.header.frame_id, self.args.frame,
                                      self.args.max_age_ms)
        if reason == "valid":
            self.accepted += 1
            self.max_accepted_age_ms = age_ms if self.max_accepted_age_ms is None else max(self.max_accepted_age_ms, age_ms)
            self.change_state("current")
        else:
            self.rejected[reason] += 1
            self.change_state("rejected:" + reason)

    def check_silence(self):
        reference = self.last_received if self.last_received is not None else self.started
        if (time.monotonic() - reference) * 1000 > self.args.silence_ms:
            self.change_state("source_silent" if self.last_received is not None else "no_source")

    def report(self):
        return {"topic": self.args.topic, "expected_frame": self.args.frame,
                "received": self.received, "accepted": self.accepted,
                "rejected": dict(self.rejected), "final_state": self.state,
                "max_accepted_age_ms": self.max_accepted_age_ms,
                "max_age_ms": self.args.max_age_ms, "silence_ms": self.args.silence_ms,
                "elapsed_host_s": round(time.monotonic() - self.started, 3),
                "clock_assumption": "Publisher and monitor stamps use a common ROS clock domain.",
                "scope": "Data validation only; no physical stop, SDK compatibility, or packet-loss count is established."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic", default="/academy/temperature")
    parser.add_argument("--frame", default="lab_sensor")
    parser.add_argument("--duration", type=finite_float, default=25.0)
    parser.add_argument("--max-age-ms", type=finite_float, default=200.0)
    parser.add_argument("--silence-ms", type=finite_float, default=1000.0)
    parser.add_argument("--output", type=Path, default=Path("reports/monitor.json"))
    parser.add_argument("--strict", action="store_true", help="Exit 2 if no samples were accepted or any sample was rejected.")
    args = parser.parse_args(remove_ros_args(args=sys.argv)[1:])
    if not 0 < args.duration <= 600 or args.max_age_ms < 0 or args.silence_ms <= 0:
        parser.error("duration must be 0–600 s, max age nonnegative, and silence threshold positive")
    if not args.topic.startswith("/academy/"):
        parser.error("this teaching monitor restricts topics to /academy/")
    rclpy.init(args=sys.argv)
    node = TemperatureMonitor(args)
    deadline = time.monotonic() + args.duration
    try:
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
            node.check_silence()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        report = node.report()
        node.destroy_node()
        rclpy.try_shutdown()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 2 if args.strict and (report["accepted"] == 0 or report["rejected"]) else 0


if __name__ == "__main__":
    sys.exit(main())
