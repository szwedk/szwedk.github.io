Subscribe, reject stale data, and report source silence

A complete ROS subscriber with unit-tested freshness rules, frame validation, source-silence detection, bounded execution, and an inspectable JSON summary. It never publishes control commands.

PLATFORM: ROS 2

ENVIRONMENT: Simulation

VALIDATION

Eight rule tests passed; ROS runtime pending

All eight pure validation tests executed successfully. ROS node syntax checked against Jazzy interfaces; actual subscription, scheduling, and source-silence integration require the stated Linux runtime.

REQUIREMENTS

Ubuntu 24.04 + ROS 2 Jazzy; pure validation tests run on Python 3

Official Jazzy rclpy and sensor_msgs installation for the node

Python 3 alone runs the eight pure rule tests

Companion synthetic publisher in another sourced terminal

If Jazzy is not installed, complete recipe ros-jazzy-bootstrap and lesson ros-environment first.

CONFIGURATION

--max-age-ms = 200
Inclusive maximum sample age under the common-clock assumption.

--silence-ms = 1000
Host elapsed interval without any received message before reporting silence.

--duration = 60
Bounded host elapsed runtime, maximum 600 seconds.

--strict = --strict
Exit 2 if no sample was accepted or any sample was rejected.

--output = reports/stale-test.json
Use distinct filenames for different fault trials.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ros-freshness-monitor. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ros-freshness-monitor"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 -m unittest -v test_rules.py
  python3 -m py_compile telemetry_monitor.py
  python3 -c "import rclpy; from sensor_msgs.msg import Temperature; print('ROS imports ready')"
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ros-freshness-monitor"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 telemetry_monitor.py --duration 60 --max-age-ms 200 --silence-ms 1000 --output reports/monitor.json
)

EXPECTED RESULT

Eight standalone freshness-rule tests pass.

A correctly configured live publisher transitions the monitor to current and increases accepted count.

Stale, future, non-finite, and wrong-frame samples increment separate rejection counters.

After the publisher stops, source_silent appears once the host-elapsed silence threshold passes.

The saved report states the common-clock assumption and contains no physical stop claim.

Separate transport arrival from usable data

The subscriber counts every received message but accepts only samples that satisfy finite-value, frame, and age rules. Rejected data is categorized instead of silently being reused as current state. The maximum age comparison is inclusive: exactly 200 ms is accepted when the configured limit is 200 ms.



Two timing questions need two clocks

Sample age compares the incoming ROS timestamp with the node’s ROS clock and assumes a common clock domain. Source silence measures elapsed time since the last arrival using the host monotonic clock. A source can keep sending stale data, in which case it is not silent but its samples are still rejected.



Run the fault matrix

First run the publisher with zero offset and verify accepted data. Then repeat with a 250 ms offset, a negative offset, and a different frame name, saving each monitor report under a distinct filename. Finally run the monitor without a publisher to exercise no_source. These cases test different assumptions and should produce different recorded outcomes.



Know the boundary

This monitor reports software observations only. It has no actuator interface, emergency-stop role, or guarantee that any physical device responds to its state. Strict mode returns a failing process status when no samples were accepted or any sample was rejected; that is a data-quality automation gate, not a hardware safety function.



Start the baseline publisher in a second terminal

Create and set up the companion ros-temperature-publisher recipe first. Start this monitor with Run, then paste the following into a second terminal while the monitor is still running. The 60-second monitor window leaves time to begin a 20-second publisher run. Inspect reports/monitor.json after the monitor ends.

(
  set -e
  cd "$HOME/robot-academy/ros-temperature-publisher"
  test -f /opt/ros/jazzy/setup.bash
  source /opt/ros/jazzy/setup.bash
  export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
  export ROS_DOMAIN_ID=42
  export ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
  unset ROS_STATIC_PEERS
  python3 telemetry_publisher.py --rate-hz 10 --duration 20 --stamp-offset-ms 0
)

TROUBLESHOOTING

State becomes no_source
No message has arrived. Verify publisher existence, exact topic, matching domain/middleware, and compatible QoS.

Every sample is future_stamp
Clock domains or machine clocks disagree, or the publisher has a negative timestamp offset. Do not take an absolute age to hide this.

Source is silent but ROS time is paused
Silence uses host monotonic time intentionally, so this detector can still expire while simulation time is paused.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ros-time-executors

https://kamilszwed.com/courses/#/lesson/ros-testing-diagnostics

https://kamilszwed.com/courses/#/lesson/ros-environment

SOURCES

Writing a Python publisher and subscriber
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Tutorials/Beginner-Client-Libraries/Writing-A-Simple-Py-Publisher-And-Subscriber.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

ROS 2 clock and time design
https://raw.githubusercontent.com/ros2/design/gh-pages/articles/130_ros_time.md
Current primary documentation retrieved 2026-09-29

sensor_msgs Temperature interface
https://raw.githubusercontent.com/ros2/common_interfaces/jazzy/sensor_msgs/msg/Temperature.msg
Primary documentation retrieved 2026-09-29
