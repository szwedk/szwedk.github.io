import unittest
from telemetry_rules import assess_sample


class RuleTests(unittest.TestCase):
    def check_reason(self, stamp, now, reason, temperature=20.0, frame="lab_sensor", limit=200.0):
        actual, _ = assess_sample(temperature, stamp, now, frame, "lab_sensor", limit)
        self.assertEqual(actual, reason)
    def test_current(self):
        self.check_reason(900_000_000, 1_000_000_000, "valid")
    def test_boundary(self):
        self.check_reason(800_000_000, 1_000_000_000, "valid")
    def test_stale(self):
        self.check_reason(799_000_000, 1_000_000_000, "stale")
    def test_future(self):
        self.check_reason(1_001_000_000, 1_000_000_000, "future_stamp")
    def test_nan(self):
        self.check_reason(0, 0, "non_finite", temperature=float("nan"))
    def test_wrong_frame(self):
        self.check_reason(0, 0, "frame_mismatch", frame="unknown")
    def test_negative_limit(self):
        self.check_reason(0, 0, "invalid_time", limit=-1)
    def test_zero_age(self):
        self.check_reason(1_000_000_000, 1_000_000_000, "valid", limit=0)


if __name__ == "__main__":
    unittest.main()
