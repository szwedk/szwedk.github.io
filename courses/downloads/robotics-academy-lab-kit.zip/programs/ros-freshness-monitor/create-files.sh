# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ros-freshness-monitor"
cd "$HOME/robot-academy/ros-freshness-monitor"
cat > telemetry_monitor.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Read synthetic ROS temperature; reject stale/invalid samples; never publish commands."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import sys
import time

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from rclpy.qos import qos_profile_sensor_data
from rclpy.utilities import remove_ros_args
from sensor_msgs.msg import Temperature
from telemetry_rules import assess_sample


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise argparse.ArgumentTypeError("a finite number is required")
    return result


class TemperatureMonitor(Node):
    def __init__(self, args):
        super().__init__("academy_temperature_monitor")
        self.args = args
        self.started = time.monotonic()
        self.last_received = None
        self.received = 0
        self.accepted = 0
        self.rejected = Counter()
        self.max_accepted_age_ms = None
        self.state = "waiting"
        self.subscription = self.create_subscription(
            Temperature, args.topic, self.on_sample, qos_profile_sensor_data)
        self.get_logger().info(f"Reading {args.topic}; max age {args.max_age_ms} ms; no command output.")

    def change_state(self, state):
        if state != self.state:
            self.state = state
            self.get_logger().info("state=" + state)

    def on_sample(self, message):
        self.received += 1
        self.last_received = time.monotonic()
        stamp_ns = message.header.stamp.sec * 1_000_000_000 + message.header.stamp.nanosec
        reason, age_ms = assess_sample(message.temperature, stamp_ns,
                                      self.get_clock().now().nanoseconds,
                                      message.header.frame_id, self.args.frame,
                                      self.args.max_age_ms)
        if reason == "valid":
            self.accepted += 1
            self.max_accepted_age_ms = age_ms if self.max_accepted_age_ms is None else max(self.max_accepted_age_ms, age_ms)
            self.change_state("current")
        else:
            self.rejected[reason] += 1
            self.change_state("rejected:" + reason)

    def check_silence(self):
        reference = self.last_received if self.last_received is not None else self.started
        if (time.monotonic() - reference) * 1000 > self.args.silence_ms:
            self.change_state("source_silent" if self.last_received is not None else "no_source")

    def report(self):
        return {"topic": self.args.topic, "expected_frame": self.args.frame,
                "received": self.received, "accepted": self.accepted,
                "rejected": dict(self.rejected), "final_state": self.state,
                "max_accepted_age_ms": self.max_accepted_age_ms,
                "max_age_ms": self.args.max_age_ms, "silence_ms": self.args.silence_ms,
                "elapsed_host_s": round(time.monotonic() - self.started, 3),
                "clock_assumption": "Publisher and monitor stamps use a common ROS clock domain.",
                "scope": "Data validation only; no physical stop, SDK compatibility, or packet-loss count is established."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topic", default="/academy/temperature")
    parser.add_argument("--frame", default="lab_sensor")
    parser.add_argument("--duration", type=finite_float, default=25.0)
    parser.add_argument("--max-age-ms", type=finite_float, default=200.0)
    parser.add_argument("--silence-ms", type=finite_float, default=1000.0)
    parser.add_argument("--output", type=Path, default=Path("reports/monitor.json"))
    parser.add_argument("--strict", action="store_true", help="Exit 2 if no samples were accepted or any sample was rejected.")
    args = parser.parse_args(remove_ros_args(args=sys.argv)[1:])
    if not 0 < args.duration <= 600 or args.max_age_ms < 0 or args.silence_ms <= 0:
        parser.error("duration must be 0–600 s, max age nonnegative, and silence threshold positive")
    if not args.topic.startswith("/academy/"):
        parser.error("this teaching monitor restricts topics to /academy/")
    rclpy.init(args=sys.argv)
    node = TemperatureMonitor(args)
    deadline = time.monotonic() + args.duration
    try:
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
            node.check_silence()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        report = node.report()
        node.destroy_node()
        rclpy.try_shutdown()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 2 if args.strict and (report["accepted"] == 0 or report["rejected"]) else 0


if __name__ == "__main__":
    sys.exit(main())
ACADEMY_FILE_0
cat > telemetry_rules.py <<'ACADEMY_FILE_1'
"""Pure message-validation rules; importable without ROS for offline tests."""
import math


def assess_sample(temperature_c, stamp_ns, now_ns, frame, expected_frame, max_age_ms):
    if not all(math.isfinite(value) for value in (temperature_c, stamp_ns, now_ns, max_age_ms)):
        return "non_finite", None
    if max_age_ms < 0 or stamp_ns < 0 or now_ns < 0:
        return "invalid_time", None
    age_ms = (now_ns - stamp_ns) / 1_000_000
    if frame != expected_frame:
        return "frame_mismatch", age_ms
    if age_ms < 0:
        return "future_stamp", age_ms
    if age_ms > max_age_ms:
        return "stale", age_ms
    return "valid", age_ms
ACADEMY_FILE_1
cat > test_rules.py <<'ACADEMY_FILE_2'
import unittest
from telemetry_rules import assess_sample


class RuleTests(unittest.TestCase):
    def check_reason(self, stamp, now, reason, temperature=20.0, frame="lab_sensor", limit=200.0):
        actual, _ = assess_sample(temperature, stamp, now, frame, "lab_sensor", limit)
        self.assertEqual(actual, reason)
    def test_current(self):
        self.check_reason(900_000_000, 1_000_000_000, "valid")
    def test_boundary(self):
        self.check_reason(800_000_000, 1_000_000_000, "valid")
    def test_stale(self):
        self.check_reason(799_000_000, 1_000_000_000, "stale")
    def test_future(self):
        self.check_reason(1_001_000_000, 1_000_000_000, "future_stamp")
    def test_nan(self):
        self.check_reason(0, 0, "non_finite", temperature=float("nan"))
    def test_wrong_frame(self):
        self.check_reason(0, 0, "frame_mismatch", frame="unknown")
    def test_negative_limit(self):
        self.check_reason(0, 0, "invalid_time", limit=-1)
    def test_zero_age(self):
        self.check_reason(1_000_000_000, 1_000_000_000, "valid", limit=0)


if __name__ == "__main__":
    unittest.main()
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/ros-freshness-monitor'
)
