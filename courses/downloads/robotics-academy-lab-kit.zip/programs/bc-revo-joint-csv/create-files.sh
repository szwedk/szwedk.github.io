# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/bc-revo-joint-csv"
cd "$HOME/robot-academy/bc-revo-joint-csv"
cat > joint_csv.py <<'ACADEMY_FILE_0'
#!/usr/bin/env python3
"""Bounded read-only JointState recorder, preserving unavailable fields as blanks."""
import argparse
import csv
import json
import math
from pathlib import Path
import time

FIELDS=['host_monotonic_s','header_stamp_s','joint','position_rad','velocity_rad_s','effort']
def expand(names,positions,velocities,efforts,host,stamp):
    n=len(names)
    if not n or len(set(names))!=n:raise ValueError('Empty or duplicate joint names')
    if any(len(x) not in (0,n) for x in (positions,velocities,efforts)):raise ValueError('JointState lengths disagree')
    for values in (positions,velocities,efforts):
        if any(not math.isfinite(x) for x in values):raise ValueError('Nonfinite joint value')
    return [dict(zip(FIELDS,[host,stamp,name,positions[i] if positions else '',velocities[i] if velocities else '',efforts[i] if efforts else ''])) for i,name in enumerate(names)]

def main():
    p=argparse.ArgumentParser();p.add_argument('--mock',action='store_true');p.add_argument('--seconds',type=float,default=10)
    p.add_argument('--topic',default='/joint_states');p.add_argument('--contains',default='right_')
    p.add_argument('--output',default='revo-joints.csv');a=p.parse_args()
    if not 0<a.seconds<=300:p.error('--seconds must be in (0,300]')
    rows=0;messages=0;rejected=0;observed=set()
    with Path(a.output).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=FIELDS);writer.writeheader()
        def record(names,pos,vel,eff,host,stamp):
            nonlocal rows,messages,rejected
            try:data=expand(names,pos,vel,eff,host,stamp)
            except ValueError as error:rejected+=1;print('Rejected:',error);return
            messages+=1
            for r in data:
                if a.contains in r['joint']:writer.writerow(r);rows+=1;observed.add(r['joint'])
        if a.mock:
            for i in range(10):record(['right_index_proximal_joint','left_index_proximal_joint'],[i*.01,0],[],[],i*.01,i*.01)
            assert rows==10
            try:expand(['same','same'],[0,0],[],[],0,0)
            except ValueError:pass
            else:raise AssertionError('Duplicate joints not rejected')
        else:
            import rclpy
            from rclpy.node import Node
            from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy
            from sensor_msgs.msg import JointState
            rclpy.init();node=Node('course_revo_joint_csv')
            qos=QoSProfile(depth=100,reliability=ReliabilityPolicy.BEST_EFFORT,durability=DurabilityPolicy.VOLATILE)
            def receive(m):record(list(m.name),list(m.position),list(m.velocity),list(m.effort),time.monotonic(),m.header.stamp.sec+m.header.stamp.nanosec/1e9)
            node.create_subscription(JointState,a.topic,receive,qos);end=time.monotonic()+a.seconds
            try:
                while rclpy.ok() and time.monotonic()<end:rclpy.spin_once(node,timeout_sec=.1)
            except KeyboardInterrupt:pass
            finally:node.destroy_node();rclpy.try_shutdown()
    result={'mock':a.mock,'rows':rows,'messages':messages,'rejected':rejected,'joints':sorted(observed),
            'meaning':'Blank fields are unavailable, not physical zero. Effort semantics come from the active driver.'}
    Path(a.output+'.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    if rows==0:raise SystemExit('No selected joint rows; inspect actual names and --contains filter')
if __name__=='__main__':main()
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/bc-revo-joint-csv'
)
