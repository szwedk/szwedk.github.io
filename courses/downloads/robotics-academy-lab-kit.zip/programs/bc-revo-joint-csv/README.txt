Record Revo joint positions without publishing commands

Subscribe to an existing Revo2 ROS driver or FakeSystem, filter the right-hand joint names, and save a long-form CSV that preserves absent velocity/effort values.

PLATFORM: BrainCo Revo

ENVIRONMENT: Read-only hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

Offline program executes and embedded assertions pass.  Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: Python 3.10+

ROS path: Ubuntu 22.04 / Humble / sensor_msgs

An already commissioned Revo2 driver or FakeSystem publishing JointState; this recipe does not launch hardware

CONFIGURATION

--contains = right_
Keep only names containing this exact string; use left_ for the other side.

--topic = /joint_states
Standard state topic or the explicit namespace used by your existing driver.

--seconds = 10
Capture window, up to 300 seconds.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/bc-revo-joint-csv. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/bc-revo-joint-csv"
cd "$HOME/robot-academy/bc-revo-joint-csv"
python3 --version
python3 -m py_compile joint_csv.py
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/bc-revo-joint-csv"
python3 joint_csv.py --mock

# Optional capture from an already commissioned driver or FakeSystem:
# Set REVO_READ_ROS=1 before copying this block to enable it.
if [ "${REVO_READ_ROS:-0}" = 1 ]; then
source /opt/ros/humble/setup.bash
python3 joint_csv.py --topic /joint_states --contains right_ --seconds 10 --output revo-device-joints.csv
fi
)

EXPECTED RESULT

Offline writes ten synthetic right-hand rows and rejects a duplicate-name test.

Each CSV row identifies one joint and records the ROS timestamp, host reception time and present state values.

Live capture is bounded and rejects duplicate names, mismatched nonempty arrays and nonfinite samples.

Long-form joint data

A JointState message is a set of parallel arrays. The script first checks the name list and array lengths, then selects names containing the requested side prefix. Writing one row per joint makes missing samples and mixed left/right streams easier to inspect. An absent velocity or effort array becomes an empty CSV field, preserving the distinction between unavailable and measured zero. Position units for revolute joints follow the ROS radians convention; the driver’s mapping to raw actuator coordinates remains a separate layer.



Read a commissioned system

This program creates one subscription and no publishers. Starting a hardware driver can initialize or acquire the hand, so that commissioning step belongs to the matching driver procedure and is not hidden inside a telemetry script. You can first point the same reader at the FakeSystem recipe. Its report marks synthetic data separately. On a real hand, name presence alone does not prove the model variant or actuator mapping is correct; compare the loaded description and hardware configuration.



TROUBLESHOOTING

Messages arrive but no rows are selected
Inspect ros2 topic echo once and compare actual name prefixes with --contains. Do not guess side identity from numeric array order.

Velocity and effort columns are blank
The source omitted those arrays. Blank values are intentional and must not be converted to zeros when assessing tracking or load.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/bc-revo-ros-control

https://kamilszwed.com/courses/#/lesson/bc-revo-g1-integration

SOURCES

BrainCo Revo2 ROS 2 packages
https://github.com/BrainCoTech/brainco_hand_ros2/blob/e98dd933bcc85da86f6993910ffe64e8b981160b/README.md
e98dd933bcc85da86f6993910ffe64e8b981160b; 2026-08-20T02:04:48Z

BrainCo digital robot assets
https://github.com/BrainCoTech/brainco-description/blob/3d4ec110eb977ba2b7a770f481239543a1633be4/README.md
3d4ec110eb977ba2b7a770f481239543a1633be4; 2026-09-26T16:27:33Z
