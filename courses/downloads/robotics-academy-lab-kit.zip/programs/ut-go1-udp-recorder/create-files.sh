# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-go1-udp-recorder"
cd "$HOME/robot-academy/ut-go1-udp-recorder"
cat > go1_receive.cpp <<'ACADEMY_FILE_0'
// Original receive-only Go1 telemetry tool. No UDP Send or SetSend calls.
#include <unitree_legged_sdk/comm.h>
#ifdef UNITREE_LIVE
#include <unitree_legged_sdk/udp.h>
#endif
#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
using namespace UNITREE_LEGGED_SDK;
volatile std::sig_atomic_t stop_requested=0;
void stop_handler(int){stop_requested=1;}

void header(){
  std::cout<<"received_s,mode,soc_percent,current_mA,body_height_m,vx_m_s,vy_m_s,yaw_rad_s";
  for(int i=0;i<12;i++)std::cout<<",q"<<i<<"_rad";
  for(int i=0;i<12;i++)std::cout<<",temperature"<<i;
  for(int i=0;i<10;i++)std::cout<<",cell"<<i<<"_mV";
  std::cout<<"\n";
}
void row(const HighState& s,double elapsed){
  std::cout<<std::fixed<<std::setprecision(6)<<elapsed<<','<<int(s.mode)<<','<<int(s.bms.SOC)<<','<<s.bms.current
    <<','<<s.bodyHeight<<','<<s.velocity[0]<<','<<s.velocity[1]<<','<<s.yawSpeed;
  for(int i=0;i<12;i++)std::cout<<','<<s.motorState[i].q;
  for(int i=0;i<12;i++)std::cout<<','<<int(s.motorState[i].temperature);
  for(auto cell:s.bms.cell_vol)std::cout<<','<<cell;
  std::cout<<'\n';
}
HighState fixture(int n){
  HighState s{};s.mode=0;s.bms.SOC=80;s.bms.current=-1000;s.bodyHeight=0.28f;
  for(int i=0;i<12;i++){s.motorState[i].q=0.02f*std::sin(n*0.02f+i*0.1f);s.motorState[i].temperature=30+i%3;}
  for(auto& cell:s.bms.cell_vol)cell=4000;
  return s;
}
int main(int argc,char** argv){
  try{
    bool live=false,self_test=false;int samples=100,local_port=8090,target_port=8082;double seconds=10;
    std::string address="192.168.123.161";
    for(int i=1;i<argc;i++){
      std::string a=argv[i];auto value=[&](){if(i+1>=argc)throw std::runtime_error("Missing value for "+a);return std::string(argv[++i]);};
      if(a=="--live")live=true;else if(a=="--mock")live=false;else if(a=="--self-test")self_test=true;
      else if(a=="--samples")samples=std::stoi(value());else if(a=="--seconds")seconds=std::stod(value());
      else if(a=="--local-port")local_port=std::stoi(value());else if(a=="--target-port")target_port=std::stoi(value());
      else if(a=="--target-ip")address=value();else throw std::runtime_error("Unknown argument: "+a);
    }
    if(samples<1||samples>1000000||!(seconds>0&&seconds<=3600)||local_port<1||local_port>65535||target_port<1||target_port>65535)
      throw std::runtime_error("Invalid duration, sample count or UDP port");
    if(self_test){auto s=fixture(1);if(s.bms.SOC!=80||s.bms.current!=-1000||s.bms.cell_vol[9]!=4000||s.motorState[11].temperature!=32)throw std::runtime_error("Fixture failed");std::cout<<"PASS: compiled against pinned HighState/BmsState fields; no socket opened\n";return 0;}
    if(!live){header();for(int i=0;i<samples;i++)row(fixture(i),i*0.02);std::cerr<<"Synthetic records: "<<samples<<"\n";return 0;}
#ifndef UNITREE_LIVE
    throw std::runtime_error("This binary contains only fixture mode. Build the Linux live target explicitly.");
#else
    std::signal(SIGINT,stop_handler);std::signal(SIGTERM,stop_handler);
    UDP receiver(static_cast<uint16_t>(local_port),address.c_str(),static_cast<uint16_t>(target_port),
                 sizeof(HighCmd),sizeof(HighState),false,RecvEnum::nonBlock);
    HighState state{};unsigned long long previous=receiver.udpState.RecvCount,records=0;
    auto start=std::chrono::steady_clock::now();header();
    while(!stop_requested){
      double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
      if(elapsed>=seconds)break;
      receiver.Recv();
      if(receiver.udpState.RecvCount>previous){
        previous=receiver.udpState.RecvCount;receiver.GetRecv(state);row(state,elapsed);records++;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    std::cerr<<"Received: "<<records<<", receive CRC errors: "<<receiver.udpState.RecvCRCError<<"\n";
    if(!records)std::cerr<<"No telemetry. This tool never sends a command/handshake; the approved stream must already target the configured host/port. Do not substitute a motion example to make it respond.\n";
    return records?0:2;
#endif
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
ACADEMY_FILE_0
cat > CMakeLists.txt <<'ACADEMY_FILE_1'
cmake_minimum_required(VERSION 3.16)
project(go1_receive_only LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(SDK_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/vendor/unitree_legged_sdk" CACHE PATH "Pinned Go1 SDK root")
add_executable(go1_receive go1_receive.cpp)
target_include_directories(go1_receive PRIVATE "${SDK_ROOT}/include")
option(ENABLE_LIVE "Link the Linux-only vendor transport" OFF)
if(ENABLE_LIVE)
  if(NOT CMAKE_SYSTEM_NAME STREQUAL "Linux")
    message(FATAL_ERROR "Vendor transport libraries in this recipe require Linux")
  endif()
  if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64")
    set(SDK_ARCH amd64)
  elseif(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
    set(SDK_ARCH arm64)
  else()
    message(FATAL_ERROR "Unsupported vendor binary architecture")
  endif()
  find_package(Threads REQUIRED)
  target_compile_definitions(go1_receive PRIVATE UNITREE_LIVE=1)
  target_link_libraries(go1_receive PRIVATE "${SDK_ROOT}/lib/cpp/${SDK_ARCH}/libunitree_legged_sdk.a" Threads::Threads)
endif()
ACADEMY_FILE_1
cat > go1_battery.py <<'ACADEMY_FILE_2'
"""Summarize Go1 receive-only CSV battery and thermal observations."""
import argparse
import csv
import json
from pathlib import Path


def summarize(rows,min_soc=20,temperature_warning=70):
    rows=list(rows)
    if not rows:raise ValueError('No telemetry rows to analyze')
    alerts=[];soc=[];currents=[];temperatures=[];spreads=[]
    for n,row in enumerate(rows,1):
        charge=int(row['soc_percent']);soc.append(charge);currents.append(float(row['current_mA'])/1000)
        if not 0<=charge<=100:alerts.append(dict(row=n,kind='INVALID_SOC',value=charge))
        elif charge<min_soc:alerts.append(dict(row=n,kind='PROJECT_LOW_SOC',value=charge))
        temps=[int(row[f'temperature{i}']) for i in range(12)];temperatures+=temps
        if max(temps)>=temperature_warning:alerts.append(dict(row=n,kind='PROJECT_TEMPERATURE_WARNING',value=max(temps)))
        cells=[int(row[f'cell{i}_mV']) for i in range(10)]
        # Zero/missing channels are unavailable, not zero-volt measured cells.
        valid=[v for v in cells if v>0]
        spreads.append(max(valid)-min(valid) if len(valid)>1 else None)
    return dict(records=len(rows),minimum_soc_percent=min(soc),maximum_abs_current_A=max(abs(x) for x in currents),
                signed_current_A=dict(minimum=min(currents),maximum=max(currents)),maximum_temperature=max(temperatures),
                maximum_available_cell_spread_mV=max((x for x in spreads if x is not None),default=None),alerts=alerts,
                note='Thresholds are project review flags, not vendor charge/discharge limits. Current sign is preserved without inferring firmware sign semantics.')


def fixture():
    d=dict(soc_percent='80',current_mA='-1000')
    d.update({f'temperature{i}':'30' for i in range(12)})
    d.update({f'cell{i}_mV':'4000' for i in range(10)})
    return d


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input');p.add_argument('--mock',action='store_true')
    p.add_argument('--self-test',action='store_true');p.add_argument('--min-soc',type=int,default=20)
    p.add_argument('--temperature-warning',type=int,default=70);p.add_argument('--output',default='go1-health.json');a=p.parse_args()
    if a.self_test:
        d=fixture();assert summarize([d])['maximum_abs_current_A']==1
        d['soc_percent']='10';d['temperature0']='80';assert len(summarize([d])['alerts'])==2
        d['cell0_mV']='0';assert summarize([d])['maximum_available_cell_spread_mV']==0
        print('PASS: mA/A conversion, project thresholds and unavailable cell handling');return
    if a.input:
        with open(a.input,newline='') as h:result=summarize(csv.DictReader(h),a.min_soc,a.temperature_warning)
    else:result=summarize([fixture()],a.min_soc,a.temperature_warning)
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
ACADEMY_FILE_2
printf '%s\n' 'Created 3 file(s) in ~/robot-academy/ut-go1-udp-recorder'
)
