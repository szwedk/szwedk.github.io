Compile a receive-only Go1 UDP telemetry recorder

Compile against the legacy HighState layout, generate fixture CSV, and optionally use a bounded passive UDP receiver with the vendor Linux transport library.

PLATFORM: Unitree Go1

ENVIRONMENT: Compiled fixture; optional passive UDP

VALIDATION

C++ fixture compiled and tested

C++17 fixture compiled and ran against the pinned vendor headers on macOS arm64; live branch passed compiler syntax checking with the actual UDP declarations. A 100-row fixture fed the battery report. Linux vendor-library linking and robot UDP transport were not tested.

REQUIREMENTS

A C++17 compiler, CMake 3.16+, Git and Python 3.10+. On Ubuntu: build-essential, cmake, git and python3. macOS requires command-line developer tools and CMake for the offline build.

unitree_legged_sdk pinned to 4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1, the audited go1 branch README release 3.8.6. This is not SDK2 or AGIBOT GO-1.

Optional live link: Linux x86_64 or aarch64 with the matching vendor static library. The SDK README specifies Legged_sport >=1.36.0 and supported H0.1.7/H0.1.9 firmware >=0.1.35; confirm the delivered robot support contract.

Passive receive requires an already approved telemetry stream to this host and local port. The SDK exposes Recv/GetRecv, but this recipe does not assert that every Go1 firmware emits state without an established exchange.

CONFIGURATION

--target-ip = 192.168.123.161
Example SDK sport endpoint; verify the actual robot configuration.

--local-port = 8090
Local receive socket port; must match the already configured telemetry destination.

--target-port = 8082
Example peer endpoint from the audited high-level sample.

--seconds = 10
Bounded live capture duration. --samples controls fixture row count only.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-go1-udp-recorder. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-go1-udp-recorder"
  command -v git
  command -v cmake
  command -v c++
  mkdir -p vendor
  if [ ! -d vendor/unitree_legged_sdk/.git ]; then
    git clone https://github.com/unitreerobotics/unitree_legged_sdk.git vendor/unitree_legged_sdk
  fi
  [ -z "$(git -C vendor/unitree_legged_sdk status --porcelain --untracked-files=no)" ]
  git -C vendor/unitree_legged_sdk checkout --detach 4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1
  [ "$(git -C vendor/unitree_legged_sdk rev-parse HEAD)" = 4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1 ]
  cmake -S . -B build-mock -DENABLE_LIVE=OFF
  cmake --build build-mock --parallel 2
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-go1-udp-recorder"
  ./build-mock/go1_receive --self-test
  ./build-mock/go1_receive --mock --samples 100 > go1.csv
  python3 go1_battery.py --input go1.csv --output go1-health.json
  head -n 3 go1.csv
)

# OPTIONAL LINUX LIVE BUILD AND RECEIVE: uncomment only when an approved
# telemetry stream already targets this host/port. This tool never sends
# a command or handshake. Its passive mode may receive nothing on your firmware.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-go1-udp-recorder"
#   cmake -S . -B build-live -DENABLE_LIVE=ON
#   cmake --build build-live --parallel 2
#   ROBOT_IP=192.168.123.161
#   LOCAL_PORT=8090
#   TARGET_PORT=8082
#   ./build-live/go1_receive --live --target-ip "$ROBOT_IP" --local-port "$LOCAL_PORT" --target-port "$TARGET_PORT" --seconds 10 > go1-live.csv
#   python3 go1_battery.py --input go1-live.csv --output go1-live-health.json
# )

EXPECTED RESULT

The default CMake build does not link the UDP transport. Its self-test verifies actual vendor HighState/BmsState field compilation without opening a socket.

The mock run writes 100 CSV rows including mode, SOC, current, body height, velocity, 12 joint positions/temperatures and ten cell-voltage slots.

The live build counts successful receives and CRC errors, stops after ten seconds, and never calls Send, SetSend or InitCmdData. Zero received frames exit with status 2.

What is receive-only here

The offline binary compiles against comm.h and never links a transport. The optional Linux binary constructs UDP with explicit send/receive structure sizes, non-blocking receive mode and the chosen endpoints. It calls Recv and copies state only when the receive counter advances. There is no dummy HighCmd packet: even nominally empty commands can have firmware semantics, so this program does not send one.



Versioned data rather than guessed decoding

The program accesses the audited C++ HighState fields through the vendor header, avoiding a handwritten byte-offset parser. Legacy BmsState current is in mA and cell_vol entries are in mV. HighState has no LowState tick field, so each CSV record instead uses a local steady-clock arrival time. The first twelve motor slots are preserved numerically; the program does not infer a cross-vendor joint naming map.



TROUBLESHOOTING

No packets arrive in the live window.
Verify target address, local/target ports and an existing vendor-approved telemetry exchange. A passive receiver cannot make a request/response-only firmware stream. Do not substitute a walking or torque example just to trigger responses.

Linker reports a wrong-format Unitree library.
Use the Linux architecture matching the bundled library. CMake explicitly rejects other OS/architecture combinations for ENABLE_LIVE=ON; macOS supports the fixture-only target.

The SDK branch builds but the robot behaves differently from the README.
Stop treating the branch name as compatibility proof. Record delivered firmware, sport service and exact SDK revision; obtain the matching vendor contract before testing any command path.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-go1-versions

https://kamilszwed.com/courses/#/lesson/ut-go1-udp-contract

https://kamilszwed.com/courses/#/lesson/ut-go1-control-levels

SOURCES

Go1 SDK version contract
https://github.com/unitreerobotics/unitree_legged_sdk/blob/4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1/README.md
4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1

Go1 command and state structures
https://github.com/unitreerobotics/unitree_legged_sdk/blob/4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1/include/unitree_legged_sdk/comm.h
4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1

Go1 UDP interface
https://github.com/unitreerobotics/unitree_legged_sdk/blob/4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1/include/unitree_legged_sdk/udp.h
4539a6c10dfbc9781cea6fcb7d51bc6ddc6f71e1
