// Original receive-only Go1 telemetry tool. No UDP Send or SetSend calls.
#include <unitree_legged_sdk/comm.h>
#ifdef UNITREE_LIVE
#include <unitree_legged_sdk/udp.h>
#endif
#include <atomic>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
using namespace UNITREE_LEGGED_SDK;
volatile std::sig_atomic_t stop_requested=0;
void stop_handler(int){stop_requested=1;}

void header(){
  std::cout<<"received_s,mode,soc_percent,current_mA,body_height_m,vx_m_s,vy_m_s,yaw_rad_s";
  for(int i=0;i<12;i++)std::cout<<",q"<<i<<"_rad";
  for(int i=0;i<12;i++)std::cout<<",temperature"<<i;
  for(int i=0;i<10;i++)std::cout<<",cell"<<i<<"_mV";
  std::cout<<"\n";
}
void row(const HighState& s,double elapsed){
  std::cout<<std::fixed<<std::setprecision(6)<<elapsed<<','<<int(s.mode)<<','<<int(s.bms.SOC)<<','<<s.bms.current
    <<','<<s.bodyHeight<<','<<s.velocity[0]<<','<<s.velocity[1]<<','<<s.yawSpeed;
  for(int i=0;i<12;i++)std::cout<<','<<s.motorState[i].q;
  for(int i=0;i<12;i++)std::cout<<','<<int(s.motorState[i].temperature);
  for(auto cell:s.bms.cell_vol)std::cout<<','<<cell;
  std::cout<<'\n';
}
HighState fixture(int n){
  HighState s{};s.mode=0;s.bms.SOC=80;s.bms.current=-1000;s.bodyHeight=0.28f;
  for(int i=0;i<12;i++){s.motorState[i].q=0.02f*std::sin(n*0.02f+i*0.1f);s.motorState[i].temperature=30+i%3;}
  for(auto& cell:s.bms.cell_vol)cell=4000;
  return s;
}
int main(int argc,char** argv){
  try{
    bool live=false,self_test=false;int samples=100,local_port=8090,target_port=8082;double seconds=10;
    std::string address="192.168.123.161";
    for(int i=1;i<argc;i++){
      std::string a=argv[i];auto value=[&](){if(i+1>=argc)throw std::runtime_error("Missing value for "+a);return std::string(argv[++i]);};
      if(a=="--live")live=true;else if(a=="--mock")live=false;else if(a=="--self-test")self_test=true;
      else if(a=="--samples")samples=std::stoi(value());else if(a=="--seconds")seconds=std::stod(value());
      else if(a=="--local-port")local_port=std::stoi(value());else if(a=="--target-port")target_port=std::stoi(value());
      else if(a=="--target-ip")address=value();else throw std::runtime_error("Unknown argument: "+a);
    }
    if(samples<1||samples>1000000||!(seconds>0&&seconds<=3600)||local_port<1||local_port>65535||target_port<1||target_port>65535)
      throw std::runtime_error("Invalid duration, sample count or UDP port");
    if(self_test){auto s=fixture(1);if(s.bms.SOC!=80||s.bms.current!=-1000||s.bms.cell_vol[9]!=4000||s.motorState[11].temperature!=32)throw std::runtime_error("Fixture failed");std::cout<<"PASS: compiled against pinned HighState/BmsState fields; no socket opened\n";return 0;}
    if(!live){header();for(int i=0;i<samples;i++)row(fixture(i),i*0.02);std::cerr<<"Synthetic records: "<<samples<<"\n";return 0;}
#ifndef UNITREE_LIVE
    throw std::runtime_error("This binary contains only fixture mode. Build the Linux live target explicitly.");
#else
    std::signal(SIGINT,stop_handler);std::signal(SIGTERM,stop_handler);
    UDP receiver(static_cast<uint16_t>(local_port),address.c_str(),static_cast<uint16_t>(target_port),
                 sizeof(HighCmd),sizeof(HighState),false,RecvEnum::nonBlock);
    HighState state{};unsigned long long previous=receiver.udpState.RecvCount,records=0;
    auto start=std::chrono::steady_clock::now();header();
    while(!stop_requested){
      double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
      if(elapsed>=seconds)break;
      receiver.Recv();
      if(receiver.udpState.RecvCount>previous){
        previous=receiver.udpState.RecvCount;receiver.GetRecv(state);row(state,elapsed);records++;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    std::cerr<<"Received: "<<records<<", receive CRC errors: "<<receiver.udpState.RecvCRCError<<"\n";
    if(!records)std::cerr<<"No telemetry. This tool never sends a command/handshake; the approved stream must already target the configured host/port. Do not substitute a motion example to make it respond.\n";
    return records?0:2;
#endif
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
