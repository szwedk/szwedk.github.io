Generate a useful workstation and ROS report

A complete local inventory program that records platform, selected ROS settings, installed tool paths, and bounded diagnostic results without dumping your full environment.

PLATFORM: Linux & Python

ENVIRONMENT: Offline

VALIDATION

Locally tested

Executed on macOS with Python 3; valid JSON, missing-Linux-tool handling, and bounded subprocess collection verified. Linux network and ROS doctor branches need execution in the stated Linux/ROS environment.

REQUIREMENTS

Python 3.10+; Linux/macOS; optional ROS 2 Jazzy

Python 3.10 or later; no pip packages

Optional ros2 doctor requires an installed and sourced ROS environment

CONFIGURATION

--output = reports/workstation.json
Destination JSON file; parent directories are created.

--include-network = --include-network
Opt in to Linux interface and route collection.

--ros-doctor = --ros-doctor
Opt in to ros2 doctor with a 20-second command timeout.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/foundations-workstation-report. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/foundations-workstation-report"
  python3 --version
  python3 -m py_compile workstation_report.py
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/foundations-workstation-report"
  python3 workstation_report.py --output reports/workstation.json
  python3 -m json.tool reports/workstation.json
)

EXPECTED RESULT

A readable JSON report is created under reports/.

Missing tools appear as unavailable; they do not crash the report.

The default report does not include the full environment, hostname, interface list, or routes.

What the program actually proves

The inventory records facts about this process environment: operating-system family, architecture, Python version, selected ROS variables, and whether common commands can be resolved. It does not install tools, change a network, or validate robot control. An unavailable command is useful evidence because it narrows the next diagnostic step.



Read the subprocess result

Each optional command has a status, argument list, exit code where available, and separate captured output/error fields. The command runs as an argument list without a shell, so the program is not interpreting report values as shell syntax. Output is truncated to keep reports bounded, and a timeout is explicitly recorded.



Add network or ROS detail deliberately

To include interface addresses and routes on Linux, add --include-network. To run the ROS diagnostic report, add --ros-doctor. Those flags can collect private local addresses, so inspect the saved file before sharing it. They remain read-only checks; neither a clean doctor report nor a successful command lookup proves the application meets its task requirements.



TROUBLESHOOTING

ROS distribution says not sourced
Source the intended ROS setup in the same shell before running. An empty variable alone is not proof that ROS is uninstalled.

Optional doctor times out
The report records timeout instead of hanging forever. Inspect the underlying ROS environment separately; no successful diagnosis is implied.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/linux-diagnostics

https://kamilszwed.com/courses/#/lesson/ros-environment

SOURCES

ROS 2 Jazzy Ubuntu binary installation
https://github.com/ros2/ros2_documentation/blob/96a43b5659750b4fd8d3b956a17fdcb3073d16b8/source/Installation/Ubuntu-Install-Debs.rst
96a43b5659750b4fd8d3b956a17fdcb3073d16b8

Python subprocess
https://docs.python.org/3/library/subprocess.html
Primary documentation retrieved 2026-09-29
