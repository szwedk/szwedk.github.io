#!/usr/bin/env python3
"""Collect a bounded workstation inventory; never collect the full environment."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def command_result(argv, timeout=8):
    if not shutil.which(argv[0]):
        return {"status": "unavailable", "command": argv}
    try:
        result = subprocess.run(argv, capture_output=True, text=True,
                                timeout=timeout, check=False)
        return {"status": "ok" if result.returncode == 0 else "failed",
                "command": argv, "exit_code": result.returncode,
                "stdout": result.stdout[:12000], "stderr": result.stderr[:4000]}
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "command": argv, "timeout_s": timeout}
    except OSError as error:
        return {"status": "failed", "command": argv, "error": str(error)}


def collect(include_network=False, ros_doctor=False):
    report = {
        "schema": "robot-academy.workstation.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "platform": {"system": platform.system(), "release": platform.release(),
                     "architecture": platform.machine(), "python": platform.python_version()},
        "ros_environment": {key: os.environ.get(key) for key in
                            ("ROS_DISTRO", "RMW_IMPLEMENTATION", "ROS_DOMAIN_ID",
                             "ROS_AUTOMATIC_DISCOVERY_RANGE")},
        "executables": {name: shutil.which(name) for name in
                        ("bash", "git", "python3", "ros2", "colcon", "ip", "ping", "ssh", "rsync")},
        "git": command_result(["git", "--version"]),
        "scope": {"full_environment_collected": False,
                  "network_inventory_requested": include_network,
                  "ros_doctor_requested": ros_doctor},
    }
    release_file = Path("/etc/os-release")
    if release_file.exists():
        report["os_release"] = release_file.read_text(encoding="utf-8")[:6000]
    if include_network:
        report["network"] = {
            "addresses": command_result(["ip", "-brief", "address"]),
            "routes": command_result(["ip", "route"]),
        }
    if ros_doctor:
        report["ros_doctor"] = command_result(["ros2", "doctor", "--report"], timeout=20)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("reports/workstation.json"))
    parser.add_argument("--include-network", action="store_true",
                        help="Include local interface addresses and routes; review before sharing.")
    parser.add_argument("--ros-doctor", action="store_true",
                        help="Run ros2 doctor, which may include local network details.")
    args = parser.parse_args()
    report = collect(args.include_network, args.ros_doctor)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Report written: {args.output}")
    print(f"System: {report['platform']['system']} / {report['platform']['architecture']}")
    print(f"ROS distribution: {report['ros_environment']['ROS_DISTRO'] or 'not sourced'}")
    missing = [key for key, value in report["executables"].items() if value is None]
    print("Unavailable tools: " + (", ".join(missing) or "none"))
    print("A missing tool is recorded; this report does not install or reconfigure anything.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
