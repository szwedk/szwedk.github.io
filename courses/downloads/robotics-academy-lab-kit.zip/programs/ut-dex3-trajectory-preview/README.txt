Generate a bounded seven-joint Dex3 trajectory

Create a time-indexed CSV and SVG plot for a smooth, side-specific joint interpolation; inspect ranges and sample increments before any controller integration.

PLATFORM: Unitree Dex3

ENVIRONMENT: Offline trajectory generation

VALIDATION

Offline generation tested

Both side maps, interval assertions and sample counts passed. Left/right preview generation wrote CSV and SVG successfully. No physics, tactile contact or hardware motion was tested.

REQUIREMENTS

Python 3.10 or 3.11; standard library only.

Bounds are transcribed from the pinned SDK2 Dex3 example. They are a teaching reference for that contract, not a calibrated grasp or universal hand limit table.

CONFIGURATION

--side = right
Chooses one of the two explicit vendor example range tables.

--start / --end = 0.4 / 0.6
Fractions inside each joint interval, not absolute angles or normalized force.

--seconds / --hz = 4 / 50
Trajectory duration and sampling rate; both must be positive.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-dex3-trajectory-preview. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-dex3-trajectory-preview"
  python3 --version
  python3 -m venv .venv
  .venv/bin/python -m compileall -q .
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-dex3-trajectory-preview"
  .venv/bin/python dex3_preview.py --self-test
  .venv/bin/python dex3_preview.py --side left --seconds 4 --hz 50 --start 0.4 --end 0.6 --output dex3-left
  .venv/bin/python dex3_preview.py --side right --seconds 4 --hz 50 --start 0.4 --end 0.6 --output dex3-right
  head -n 3 dex3-left.csv
)

EXPECTED RESULT

Each four-second, 50 Hz preview contains 201 time samples for seven joints. Both CSV and standalone SVG are written for left and right sides.

Every generated joint value is asserted inside the selected side’s audited interval. The terminal prints the largest per-sample change for each joint.

The program has no SDK imports, sockets or publishers. It produces data for inspection; it cannot move a physical hand.

The interpolation equation

For normalized time u=t/T, the blend s=10u³−15u⁴+6u⁵ goes from zero to one with zero first and second derivatives at each endpoint. The program interpolates a fraction inside each joint’s interval using that blend. The start and end fractions apply to every joint, making the construction easy to inspect; they do not encode a human pose or a task-specific grasp.



What bounded means here

The same scalar fraction can produce positive or negative motion depending on the selected side’s interval. Every sample is checked against that interval and written in radians. The printed maximum increment helps estimate discrete velocity demands, but no physical rate or torque limit is asserted. Use the resulting file as an input to a simulator or a separately reviewed controller.



TROUBLESHOOTING

The right-hand values have different signs.
The two sides use different joint-coordinate intervals in the audited example. Copying left angles unchanged to the right is not a valid mirroring rule.

All angles are bounded but a planned grasp still collides.
Joint range checks do not evaluate finger-finger, object or palm collision, torque, force, cable routing or contact stability. Add a geometry/contact model before treating the path as a grasp.

The SVG looks smooth at a coarse sample rate.
The plot connects samples visually. Inspect the reported maximum step and raise --hz when studying discrete interpolation; an attractive line is not a timing or tracking guarantee.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-dex3-map

https://kamilszwed.com/courses/#/lesson/ut-dex3-retarget

https://kamilszwed.com/courses/#/lesson/ut-hand-grasp-capstone

SOURCES

Official Dex3 control example
https://github.com/unitreerobotics/unitree_sdk2/blob/63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36/example/g1/dex3/g1_dex3_example.cpp
63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36
