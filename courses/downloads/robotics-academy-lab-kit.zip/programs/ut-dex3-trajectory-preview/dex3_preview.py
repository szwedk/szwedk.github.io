"""Generate a bounded seven-joint interpolation and SVG; no robot transport."""
import argparse
import csv
import json
import math
from pathlib import Path
LIMITS={
 'left':([-1.05,-0.724,0,-1.57,-1.75,-1.57,-1.75],[1.05,1.05,1.75,0,0,0,0]),
 'right':([-1.05,-1.05,-1.75,0,0,0,0],[1.05,0.742,0,1.57,1.75,1.57,1.75])}
NAMES=['thumb_0','thumb_1','thumb_2','index_0','index_1','middle_0','middle_1']


def trajectory(side,seconds,hz,start_fraction,end_fraction):
    if seconds<=0 or hz<=0 or not 0<=start_fraction<=1 or not 0<=end_fraction<=1:
        raise ValueError('Positive timing and fractions inside [0,1] required')
    lo,hi=LIMITS[side];n=max(2,int(seconds*hz)+1);rows=[]
    for i in range(n):
        u=i/(n-1);s=10*u**3-15*u**4+6*u**5
        fraction=start_fraction+(end_fraction-start_fraction)*s
        rows.append([u*seconds]+[a+(b-a)*fraction for a,b in zip(lo,hi)])
    return rows


def write_svg(path,rows,seconds):
    colors=['#1d4ed8','#b45309','#047857','#be185d','#6d28d9','#0e7490','#475569']
    out=['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="650" viewBox="0 0 1000 650">',
         '<rect width="1000" height="650" fill="white"/><text x="40" y="35" font-family="sans-serif" font-size="22">Dex3 joint interpolation preview (radians)</text>',
         '<path d="M70 70V540H950" fill="none" stroke="#64748b"/>']
    for j,(name,color) in enumerate(zip(NAMES,colors)):
        points=' '.join(f'{70+880*r[0]/seconds:.2f},{305-110*r[j+1]:.2f}' for r in rows)
        out.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2"/>')
        out.append(f'<text x="{80+(j%4)*220}" y="{575+(j//4)*27}" fill="{color}" font-family="sans-serif" font-size="16">{name}</text>')
    out.append('</svg>');path.write_text('\n'.join(out))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--side',choices=list(LIMITS),default='left');p.add_argument('--seconds',type=float,default=4)
    p.add_argument('--hz',type=float,default=50);p.add_argument('--start',type=float,default=0.4);p.add_argument('--end',type=float,default=0.6)
    p.add_argument('--output',default='dex3-preview');p.add_argument('--self-test',action='store_true');a=p.parse_args()
    rows=trajectory(a.side,a.seconds,a.hz,a.start,a.end);lo,hi=LIMITS[a.side]
    assert all(l-1e-12<=v<=h+1e-12 for row in rows for v,l,h in zip(row[1:],lo,hi))
    if a.self_test:
        for side in LIMITS: assert len(trajectory(side,1,10,0.4,0.6))==11
        print('PASS: both side maps, endpoints, sample count and joint bounds');return
    prefix=Path(a.output)
    with prefix.with_suffix('.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['time_s']+NAMES);writer.writerows(rows)
    write_svg(prefix.with_suffix('.svg'),rows,a.seconds)
    maximum_steps=[max(abs(rows[i+1][j+1]-rows[i][j+1]) for i in range(len(rows)-1)) for j in range(7)]
    print(json.dumps(dict(side=a.side,samples=len(rows),maximum_joint_step_rad=maximum_steps,
                         note='A synchronized interpolation, not a calibrated grasp or hardware command.')))
if __name__=='__main__':main()
