# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ut-sdk2-environment"
cd "$HOME/robot-academy/ut-sdk2-environment"
cat > install_sdk2.sh <<'ACADEMY_FILE_0'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK2_REV=63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36
PYTHON_REV=814556d15970dd2ecf1c9984e845ca02ab07e206
CYCLONE_REV=9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd
if [[ "${1:---plan}" == --self-test ]]; then
  [[ ${#SDK2_REV} == 40 && ${#PYTHON_REV} == 40 && ${#CYCLONE_REV} == 40 ]]
  echo 'PASS: pinned revisions are defined; installer did not run.'
  exit 0
fi
if [[ "${1:---plan}" != --install ]]; then
  echo 'Plan: install Ubuntu build prerequisites; build CycloneDDS 0.10.2 and SDK2; create a local Python environment.'
  echo 'No robot program will be launched. Run: bash install_sdk2.sh --install'
  exit 0
fi
[[ $(uname -s) == Linux ]] || { echo 'Live SDK environment requires Linux; mock programs run without this installer.'; exit 2; }
source /etc/os-release
[[ $ID == ubuntu && $VERSION_ID == 22.04 ]] || { echo 'This recipe targets Ubuntu 22.04. Keep another distribution in a separate tested environment.'; exit 2; }
case $(uname -m) in x86_64|aarch64) ;; *) echo 'Unsupported architecture for this recipe'; exit 2;; esac
sudo apt-get update
sudo apt-get install -y git cmake build-essential python3-venv python3-dev libssl-dev
mkdir -p vendor
checkout() {
  local url=$1 directory=$2 revision=$3
  if [[ ! -d "$directory/.git" ]]; then git clone "$url" "$directory"; fi
  [[ -z $(git -C "$directory" status --porcelain --untracked-files=no) ]] || { echo "Refusing to change modified source: $directory"; return 2; }
  git -C "$directory" checkout --detach "$revision"
  [[ $(git -C "$directory" rev-parse HEAD) == "$revision" ]]
}
checkout https://github.com/eclipse-cyclonedds/cyclonedds.git vendor/cyclonedds "$CYCLONE_REV"
cmake -S vendor/cyclonedds -B vendor/cyclonedds-build -DCMAKE_INSTALL_PREFIX="$PWD/vendor/cyclonedds-install" -DBUILD_EXAMPLES=OFF
cmake --build vendor/cyclonedds-build --parallel 2
cmake --install vendor/cyclonedds-build
checkout https://github.com/unitreerobotics/unitree_sdk2.git vendor/unitree_sdk2 "$SDK2_REV"
cmake -S vendor/unitree_sdk2 -B vendor/sdk2-build -DCMAKE_INSTALL_PREFIX="$PWD/vendor/sdk2-install" -DBUILD_EXAMPLES=OFF
cmake --build vendor/sdk2-build --parallel 2
cmake --install vendor/sdk2-build
checkout https://github.com/unitreerobotics/unitree_sdk2_python.git vendor/unitree_sdk2_python "$PYTHON_REV"
python3 -m venv .venv
export CYCLONEDDS_HOME="$PWD/vendor/cyclonedds-install"
export LD_LIBRARY_PATH="$CYCLONEDDS_HOME/lib:${LD_LIBRARY_PATH:-}"
.venv/bin/python -m pip install 'numpy==1.26.4' 'opencv-python==4.10.0.84' 'cyclonedds==0.10.2'
.venv/bin/python -m pip install --no-deps -e vendor/unitree_sdk2_python
cat > activate-sdk.sh <<'ACTIVATE'
# Source this file from this recipe directory before live reads.
export CYCLONEDDS_HOME="$PWD/vendor/cyclonedds-install"
export LD_LIBRARY_PATH="$CYCLONEDDS_HOME/lib:${LD_LIBRARY_PATH:-}"
source .venv/bin/activate
ACTIVATE
.venv/bin/python -c 'from unitree_sdk2py.core.channel import ChannelSubscriber; print("SDK2 import passed; no DDS participant opened")'
.venv/bin/python -m pip freeze > environment-freeze.txt
printf 'SDK2=%s\nSDK2_PYTHON=%s\nCYCLONEDDS=%s\n' "$SDK2_REV" "$PYTHON_REV" "$CYCLONE_REV" > revisions.txt
echo 'Build complete. No robot example was executed.'
ACADEMY_FILE_0
printf '%s\n' 'Created 1 file(s) in ~/robot-academy/ut-sdk2-environment'
)
