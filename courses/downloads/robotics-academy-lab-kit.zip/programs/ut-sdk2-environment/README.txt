Build a pinned SDK2 environment

Inspect an exact installation plan, then build the C++ SDK and a private Python SDK environment without executing a robot example.

PLATFORM: Unitree G1

ENVIRONMENT: Offline plan; optional SDK build

VALIDATION

Plan and shell checks passed

bash syntax, non-mutating plan, pin length checks and upstream CMake option inspection passed. Full Ubuntu installation was not executed on this macOS host; no hardware was connected.

REQUIREMENTS

Offline path: Python 3.10 or 3.11 and a terminal. No SDK, ROS, robot or network is needed for synthetic data.

Optional SDK path: Ubuntu 22.04 x86_64/aarch64, Python 3.10, administrative access for build packages, an Ethernet interface, and the exact robot edition with supported development access.

Pinned SDK2 C++ 63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36; SDK2 Python 814556d15970dd2ecf1c9984e845ca02ab07e206; CycloneDDS 0.10.2 at 9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ut-sdk2-environment. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
  set -e
  cd "$HOME/robot-academy/ut-sdk2-environment"
  bash -n install_sdk2.sh
)

3. RUN

(
  set -e
  cd "$HOME/robot-academy/ut-sdk2-environment"
  bash install_sdk2.sh --self-test
  bash install_sdk2.sh --plan
)

# OPTIONAL INSTALL on Ubuntu 22.04. Uncomment this scoped block.
# (
#   set -e
#   cd "$HOME/robot-academy/ut-sdk2-environment"
#   bash install_sdk2.sh --install
#   cat revisions.txt
# )

EXPECTED RESULT

The default run prints the three-revision pin check and an installation plan. It does not install software, open DDS, or connect to a robot.

The optional installation writes local vendor source/build/install directories, .venv, activate-sdk.sh, revisions.txt and environment-freeze.txt.

C++ BUILD_EXAMPLES=OFF prevents the vendor example executables from being built. The final Python check imports ChannelSubscriber without creating a participant.

Why three repositories are pinned

The C++ SDK, Python wrapper and DDS runtime have separate release histories. Pinning all three makes the transport layer reproducible. The script checks out full commit hashes in detached state; a future upstream main branch update cannot silently change this build. OS security packages remain those supplied by the configured Ubuntu repositories, and their resolved Python counterparts are recorded in environment-freeze.txt.



What the build actually does

CycloneDDS supplies the native C library used by its Python binding. SDK2 C++ distributes architecture-specific libraries and headers; this installation stage exposes them through a local CMake prefix. The Python SDK is installed editable from its pinned checkout so source inspection corresponds to the running code. No globally installed Unitree package is replaced. Run this installer inside a particular reader recipe when you want that reader to acquire its own live environment.



TROUBLESHOOTING

The installer refuses a distribution or architecture.
Use its stated Ubuntu 22.04 x86_64/aarch64 environment. Keep the offline plan and Python mock recipes on other operating systems; do not remove the check and assume an untested platform is supported.

A checkout refuses modified source.
Save your modifications separately and start this recipe in a clean directory. The installer deliberately avoids replacing edited SDK files.

pip cannot build cyclonedds.
Read the first compiler error and confirm the native CycloneDDS build finished under vendor/cyclonedds-install. CYCLONEDDS_HOME must point to that prefix before installing the Python binding.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ut-g1-build

https://kamilszwed.com/courses/#/lesson/ut-g1-dds

SOURCES

SDK2 C++ build and installation
https://github.com/unitreerobotics/unitree_sdk2/blob/63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36/README.md
63096d0ac0c5d2dec9d6e0c22cd5233410ca2f36

SDK2 Python installation
https://github.com/unitreerobotics/unitree_sdk2_python/blob/814556d15970dd2ecf1c9984e845ca02ab07e206/README.md
814556d15970dd2ecf1c9984e845ca02ab07e206

CycloneDDS 0.10.2 native runtime
https://github.com/eclipse-cyclonedds/cyclonedds/tree/9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd
9995905bce6c4cf9f740d6438bbf7fcfd1c83dfd
