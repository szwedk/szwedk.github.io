Request one supervised D1 forward pulse

Exercise a no-motion dry run and a fault-injected SDK mock, then use the exact high-level move API for a manually enabled short forward request with zero-command cleanup.

PLATFORM: AGIBOT D1 Ultra

ENVIRONMENT: Supervised hardware

VALIDATION

Offline checks passed; hardware/ROS/GPU untested

C++17 mock compiled; dry path creates no SDK; missing acknowledgment rejected; timed movement mock and connection-failure cleanup both send five zero requests. C++ syntax checked against pinned vendor header without D1_MOCK; Linux native shared-library link/runtime untested Verified on macOS ARM64, Python 3.11.6 / NumPy 2.2.3 / h5py 3.16.0 where required. Linux installation, ROS runtime, physical robot/hand and real GPU inference were not executed.

REQUIREMENTS

Offline: C++17 compiler and bash

Device: Linux x86_64/aarch64, pinned SDK and verified network

Experienced supervisor, cleared test area, stable standing robot and independent device stop procedure

This program never stands the robot up; last_ctrl_mode 1 and battery ≥30% are additional course gates

CONFIGURATION

--execute = Add manually after dry-run review
Without this flag, no SDK object is created.

--operator-ready = Add manually with --execute
Confirms stable physical stand, clearance and independently available stopping procedure.

--seconds = 0.5
Course movement limit is greater than zero and no more than one second.

--speed = 0.1
Forward m/s, limited to 0.05–0.15.

1. CREATE FILES

The web page supplies create-files.sh. Review it, then run it with Bash to write the program into ~/robot-academy/ag-d1-bounded-move. The source files are also included directly. Re-running the creator replaces those teaching files.

2. SET UP

(
set -eo pipefail
mkdir -p "$HOME/robot-academy/ag-d1-bounded-move"
cd "$HOME/robot-academy/ag-d1-bounded-move"
command -v c++ >/dev/null
bash build.sh mock
)

3. RUN

(
set -eo pipefail
cd "$HOME/robot-academy/ag-d1-bounded-move"
./d1_move_mock
# This next command operates only the compiled synthetic SDK adapter:
./d1_move_mock --execute --operator-ready --seconds 0.15
# Deliberately fail the mock connection; the nonzero status is expected.
if D1_MOCK_FAIL_AFTER=4 ./d1_move_mock --execute --operator-ready --seconds 0.5; then
  echo 'Unexpected success in fault test' >&2
  exit 1
fi

# Optional Linux build, no connection or motion:
# bash prepare_sdk.sh
# After the operator checks the physical robot and stop procedure, manually
# uncomment this command AND supply both explicit acknowledgment flags:
# ./d1_move_hardware --local-ip "$D1_LOCAL_IP" --robot-ip "$D1_ROBOT_IP" --seconds 0.5 --speed 0.1 --execute --operator-ready
)

EXPECTED RESULT

Default run prints a plan and constructs no SDK object.

Mock execution prints forward requests followed by five MOCK move 0 0 0 lines.

Fault test exits unsuccessfully after connection loss but still prints five zero requests.

Hardware path requires both --execute and --operator-ready; it rejects unverified addresses, unsuitable reported mode and low battery.

What the high-level call means

The actual native signature is move(vx, vy, yaw_rate), and the official interactive example stops its timed movement using move(0,0,0). This recipe uses the same operation with a lower course-selected forward bound: 0.05–0.15 m/s for no more than one second. The loop checks connection and battery before each request. A nonzero return code aborts. There is no standUp call, mode transition, jump or low-level torque publisher.



Cleanup is a behavior to test

A small C++ RAII object sends five zero requests when the movement scope exits, including an exception or handled SIGINT/SIGTERM. Its existence is verified with a deliberate connection-failure mock. Zero messages are best-effort software requests, not an independent stop: a frozen/killed host, failed network or robot-side fault can prevent delivery. The physical operator must already know the device stop procedure. The native initialization call is outside the timed movement interval and its blocking behavior has not been hardware measured.



TROUBLESHOOTING

Gate failed before any movement
Inspect connection, battery and the SDK last mode; the script requires a physically confirmed stable stand and mode 1. Do not add an automatic stand command to bypass the gate.

Stop send failed or robot continues moving
Use the independent device stop procedure immediately. Software zero cleanup cannot guarantee delivery over a failed transport.

RELATED LESSONS

https://kamilszwed.com/courses/#/lesson/ag-d1-network

https://kamilszwed.com/courses/#/lesson/ag-d1-telemetry

https://kamilszwed.com/courses/#/lesson/ag-d1-low-level

SOURCES

D1 ZSL-1 C++ high-level header
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/include/zsl-1/highlevel.h
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 SDK known failure modes
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/docs/faq.md
b5fe0a86094507238944ad118721376a98615ac0; 2026-08-14T09:46:09Z

D1 high-level Python example
https://github.com/AgibotTech/agibot_D1_Edu-Ultra/blob/b5fe0a86094507238944ad118721376a98615ac0/demo/zsl-1/python/examples/highlevel_demo_Interactive.py
b5fe0a86094507238944ad118721376a98615ac0
