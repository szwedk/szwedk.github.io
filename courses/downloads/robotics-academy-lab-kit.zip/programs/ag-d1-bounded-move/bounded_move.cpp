#include "d1_transport.hpp"
#include <chrono>
#include <cmath>
#include <csignal>
#include <iostream>
#include <stdexcept>
#include <thread>
using Clock=std::chrono::steady_clock;
static volatile std::sig_atomic_t running=1;
void stop_signal(int){running=0;}
// Best-effort cleanup, NOT an independent emergency stop. A killed/frozen host or
// failed network cannot guarantee delivery. Use the actual device stop procedure.
class ZeroOnExit {
    mc_sdk::zsl_1::HighLevel& sdk_;
public:
    explicit ZeroOnExit(mc_sdk::zsl_1::HighLevel& sdk):sdk_(sdk){}
    ~ZeroOnExit(){
        for(int i=0;i<5;++i){try{auto code=sdk_.move(0,0,0);std::cerr<<"stop result="<<code<<'\n';}catch(...){std::cerr<<"stop send failed\n";}
            std::this_thread::sleep_for(std::chrono::milliseconds(20));}
    }
};
int main(int argc,char** argv){
    try{
        bool execute=false,ready=false;double seconds=.5,speed=.1;int port=43988;std::string local,robot;
        for(int i=1;i<argc;++i){std::string k=argv[i];
            if(k=="--execute"){execute=true;continue;}if(k=="--operator-ready"){ready=true;continue;}
            if(i+1>=argc)throw std::runtime_error("Missing value for "+k);
            std::string v=argv[++i];
            if(k=="--seconds")seconds=std::stod(v);else if(k=="--speed")speed=std::stod(v);
            else if(k=="--local-ip")local=v;else if(k=="--robot-ip")robot=v;
            else if(k=="--local-port")port=std::stoi(v);else throw std::runtime_error("Unknown option "+k);
        }
        if(!std::isfinite(speed)||speed<.05||speed>.15||!std::isfinite(seconds)||seconds<=0||seconds>1)
            throw std::runtime_error("Course bounds: forward speed 0.05..0.15 m/s; duration (0,1] seconds");
        if(port<1024||port>65535)throw std::runtime_error("Invalid local port");
        if(!execute){std::cout<<"DRY RUN: request forward "<<speed<<" m/s for "<<seconds<<" s, then five zero requests. No SDK object constructed.\n";return 0;}
        if(!ready)throw std::runtime_error("--execute requires --operator-ready after physical clearance, stable stand, battery and independent-stop checks");
#ifdef D1_MOCK
        local="127.0.0.1";robot="127.0.0.1";std::cerr<<"SYNTHETIC SDK MOCK; no hardware\n";
#else
        if(local.empty()||robot.empty())throw std::runtime_error("Provide actual --local-ip and --robot-ip; no guessed addresses are used");
#endif
        std::signal(SIGINT,stop_signal);std::signal(SIGTERM,stop_signal);
        mc_sdk::zsl_1::HighLevel sdk;sdk.initRobot(local,port,robot);
        // Mode is the last executed state, not proof of current mechanical stability.
        // Physical standing confirmation is required in addition to this software gate.
        if(!sdk.checkConnect()||sdk.getCurrentCtrlmode()!=1||sdk.getBatteryPower()<30)
            throw std::runtime_error("Gate failed: connection, stand/hello mode or course battery minimum 30%");
        ZeroOnExit stop(sdk);auto begin=Clock::now();auto next=begin;unsigned sent=0;
        while(running&&std::chrono::duration<double>(Clock::now()-begin).count()<seconds){
            if(!sdk.checkConnect()||sdk.getBatteryPower()<30)throw std::runtime_error("Connection/battery gate lost");
            auto code=sdk.move(static_cast<float>(speed),0,0);
            if(code!=0)throw std::runtime_error("Move rejected: "+std::to_string(code));
            ++sent;next+=std::chrono::milliseconds(50);std::this_thread::sleep_until(next);
        }
        std::cout<<"Sent "<<sent<<" forward requests. Cleanup now sends zero. Observe the robot before any further action.\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
