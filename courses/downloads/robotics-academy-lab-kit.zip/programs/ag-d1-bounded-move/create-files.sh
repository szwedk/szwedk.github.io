# Run in Bash on your Linux development computer.
# This creates teaching files; review existing files before replacing them.
( set -eu
mkdir -p "$HOME/robot-academy/ag-d1-bounded-move"
cd "$HOME/robot-academy/ag-d1-bounded-move"
cat > bounded_move.cpp <<'ACADEMY_FILE_0'
#include "d1_transport.hpp"
#include <chrono>
#include <cmath>
#include <csignal>
#include <iostream>
#include <stdexcept>
#include <thread>
using Clock=std::chrono::steady_clock;
static volatile std::sig_atomic_t running=1;
void stop_signal(int){running=0;}
// Best-effort cleanup, NOT an independent emergency stop. A killed/frozen host or
// failed network cannot guarantee delivery. Use the actual device stop procedure.
class ZeroOnExit {
    mc_sdk::zsl_1::HighLevel& sdk_;
public:
    explicit ZeroOnExit(mc_sdk::zsl_1::HighLevel& sdk):sdk_(sdk){}
    ~ZeroOnExit(){
        for(int i=0;i<5;++i){try{auto code=sdk_.move(0,0,0);std::cerr<<"stop result="<<code<<'\n';}catch(...){std::cerr<<"stop send failed\n";}
            std::this_thread::sleep_for(std::chrono::milliseconds(20));}
    }
};
int main(int argc,char** argv){
    try{
        bool execute=false,ready=false;double seconds=.5,speed=.1;int port=43988;std::string local,robot;
        for(int i=1;i<argc;++i){std::string k=argv[i];
            if(k=="--execute"){execute=true;continue;}if(k=="--operator-ready"){ready=true;continue;}
            if(i+1>=argc)throw std::runtime_error("Missing value for "+k);
            std::string v=argv[++i];
            if(k=="--seconds")seconds=std::stod(v);else if(k=="--speed")speed=std::stod(v);
            else if(k=="--local-ip")local=v;else if(k=="--robot-ip")robot=v;
            else if(k=="--local-port")port=std::stoi(v);else throw std::runtime_error("Unknown option "+k);
        }
        if(!std::isfinite(speed)||speed<.05||speed>.15||!std::isfinite(seconds)||seconds<=0||seconds>1)
            throw std::runtime_error("Course bounds: forward speed 0.05..0.15 m/s; duration (0,1] seconds");
        if(port<1024||port>65535)throw std::runtime_error("Invalid local port");
        if(!execute){std::cout<<"DRY RUN: request forward "<<speed<<" m/s for "<<seconds<<" s, then five zero requests. No SDK object constructed.\n";return 0;}
        if(!ready)throw std::runtime_error("--execute requires --operator-ready after physical clearance, stable stand, battery and independent-stop checks");
#ifdef D1_MOCK
        local="127.0.0.1";robot="127.0.0.1";std::cerr<<"SYNTHETIC SDK MOCK; no hardware\n";
#else
        if(local.empty()||robot.empty())throw std::runtime_error("Provide actual --local-ip and --robot-ip; no guessed addresses are used");
#endif
        std::signal(SIGINT,stop_signal);std::signal(SIGTERM,stop_signal);
        mc_sdk::zsl_1::HighLevel sdk;sdk.initRobot(local,port,robot);
        // Mode is the last executed state, not proof of current mechanical stability.
        // Physical standing confirmation is required in addition to this software gate.
        if(!sdk.checkConnect()||sdk.getCurrentCtrlmode()!=1||sdk.getBatteryPower()<30)
            throw std::runtime_error("Gate failed: connection, stand/hello mode or course battery minimum 30%");
        ZeroOnExit stop(sdk);auto begin=Clock::now();auto next=begin;unsigned sent=0;
        while(running&&std::chrono::duration<double>(Clock::now()-begin).count()<seconds){
            if(!sdk.checkConnect()||sdk.getBatteryPower()<30)throw std::runtime_error("Connection/battery gate lost");
            auto code=sdk.move(static_cast<float>(speed),0,0);
            if(code!=0)throw std::runtime_error("Move rejected: "+std::to_string(code));
            ++sent;next+=std::chrono::milliseconds(50);std::this_thread::sleep_until(next);
        }
        std::cout<<"Sent "<<sent<<" forward requests. Cleanup now sends zero. Observe the robot before any further action.\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
ACADEMY_FILE_0
cat > d1_transport.hpp <<'ACADEMY_FILE_1'
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#ifdef D1_MOCK
#include <cstdlib>
#include <iostream>
namespace mc_sdk { namespace zsl_1 {
class HighLevel {
    unsigned checks_=0;
public:
    void initRobot(const std::string&,int,const std::string&) {}
    bool checkConnect() { ++checks_;const char* n=std::getenv("D1_MOCK_FAIL_AFTER");return !n || checks_<static_cast<unsigned>(std::stoul(n)); }
    std::vector<float> getQuaternion(){return {1,0,0,0};}
    std::vector<float> getRPY(){return {0,0,0};}
    std::vector<float> getBodyAcc(){return {0,0,9.81f};}
    std::vector<float> getBodyGyro(){return {0,0,0};}
    std::vector<float> getBodyVelocity(){return {0,0,0};}
    std::vector<float> getLegAbadJoint(){return {.01f,.02f,.03f,.04f};}
    std::vector<float> getLegHipJoint(){return {.11f,.12f,.13f,.14f};}
    std::vector<float> getLegKneeJoint(){return {.21f,.22f,.23f,.24f};}
    uint32_t getBatteryPower(){return 80;}
    uint32_t getCurrentCtrlmode(){return 1;}
    uint32_t move(float x,float y,float yaw){std::cerr<<"MOCK move "<<x<<" "<<y<<" "<<yaw<<"\n";return 0;}
};
}}
#else
#include <zsl-1/highlevel.h>
#endif
ACADEMY_FILE_1
cat > build.sh <<'ACADEMY_FILE_2'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
case "${1:-mock}" in
mock) c++ -std=c++17 -O2 -Wall -Wextra -pthread -DD1_MOCK bounded_move.cpp -o d1_move_mock ;;
hardware)
  : "${D1_SDK_DIR:?Set D1_SDK_DIR to the pinned official SDK checkout}"
  arch=$(uname -m)
  case "$arch" in x86_64|aarch64) ;; *) printf 'Unsupported Linux architecture: %s\n' "$arch" >&2;exit 2;; esac
  test "$(uname -s)" = Linux || { echo 'Hardware build requires Linux' >&2;exit 2; }
  libdir="$D1_SDK_DIR/lib/zsl-1/$arch"
  c++ -std=c++17 -O2 -Wall -Wextra -pthread bounded_move.cpp -I"$D1_SDK_DIR/include" \
    "$libdir/libmc_sdk_zsl_1_${arch}.so" -Wl,-rpath,"$libdir" -o d1_move_hardware
  ;;
*) echo 'Usage: bash build.sh mock|hardware' >&2;exit 2;;
esac
ACADEMY_FILE_2
cat > prepare_sdk.sh <<'ACADEMY_FILE_3'
#!/usr/bin/env bash
# Download the pinned headers/libraries only. Does not connect to the robot.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d agibot_D1_Edu-Ultra ]; then
  git clone https://github.com/AgibotTech/agibot_D1_Edu-Ultra.git agibot_D1_Edu-Ultra
  git -C agibot_D1_Edu-Ultra checkout --detach b5fe0a86094507238944ad118721376a98615ac0
fi
test "$(git -C agibot_D1_Edu-Ultra rev-parse HEAD)" = b5fe0a86094507238944ad118721376a98615ac0 || { echo 'Existing SDK differs from course pin.' >&2;exit 2; }
export D1_SDK_DIR="$PWD/agibot_D1_Edu-Ultra"
bash build.sh hardware
ACADEMY_FILE_3
printf '%s\n' 'Created 4 file(s) in ~/robot-academy/ag-d1-bounded-move'
)
